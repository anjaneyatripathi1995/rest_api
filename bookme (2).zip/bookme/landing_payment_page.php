<?php   
    include("include/config.php");
    $booking_id = $_REQUEST['booking_id'];
    $amount = $_REQUEST['amount'];
?>
    <!DOCTYPE html>
    <html>
    <head>
        <style>.button {background-color: #4CAF50;border: none;color: white;padding: 15px 32px;text-align: center;text-decoration: none;font-size: 18px;margin: 20px auto;cursor: pointer;
        display: block;width: 115px;font-weight: 600;}
        .button2 {background-color: #008CBA;} /* Blue */
        .button3 {background-color: #f44336;} /* Red */ 
        .button4 {background-color: #e7e7e7; color: black;} /* Gray */ 
        .button5 {background-color: #555555;} /* Black */
        </style>
        </head>
        <body>
            <div class="col-sm-6" style="margin-top: 150px;">
            <a class="button" href="<?php echo BASE_URL?>paypal_payment.php?booking_id=<?php echo $booking_id ?>&amount=<?php echo $amount ?>">Paypal</a>
            <a class="button button2" href="<?php echo BASE_URL?>google_pay.php?booking_id=<?php echo $booking_id ?>&amount=<?php echo $amount ?>">Google Pay</a>
            <!--<a class="button button3" href="javascript:void(0)">Apple Pay</a>-->
            </div>
    </body>
    
    </html>
