<?php
    include("include/config.php");?>
    <!DOCTYPE html>
    <html lang="en">
        <body>
            <form action="https://www.paypal.com/cgi-bin/webscr" method="post" id="paypalForm" name="member_signup">
                <!--input type="hidden" name="business" value="tibet.innovations@gmail.com"-->
                <input type="hidden" name="business" value="cw@bookme.agency">
                <input type="hidden" name="cmd" value="_xclick">
                <input type="hidden" name="item_name" value="Gift">
                <input type="hidden" name="item_number" id="item_number" value="<?php echo $_REQUEST['booking_id'] ?>">
                <input type="hidden" name="amount" id="paypalAmount" value="<?php echo $_REQUEST['amount'] ?>">
                <input type="hidden" name="currency_code" value="GBP">
                <input type="hidden" name="rm" value="2">
                <input type='hidden' name='cancel_return' value='<?php echo BASE_URL?>paypal_failure.php'>
                <input type='hidden' name='return' value='<?php echo BASE_URL?>paypal_success.php'>
            </form>
        </body>
    
    </html>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script type="text/javascript">
        $('document').ready(function() {
            $("#paypalForm").submit();
        });
    </script>