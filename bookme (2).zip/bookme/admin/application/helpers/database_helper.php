<?php 
    if (!defined('BASEPATH')) exit('No direct script access allowed');
    
    // if ( ! function_exists('test_method')){
    //     function getFieldWhere($filed,$tbl,$where,$id){
    //     $connection = connect_db();
    //     $statement =  "SELECT $filed AS field FROM $tbl WHERE  $where = '".$id."'";
    //     $result = $connection->query($statement);
    //     if($result->num_rows > 0){
    //         $row = $result->fetch_assoc();
    //         return (stripslashes($row['field']));   
    //     }
    //     else{
    //         return false;
    //     }
    // }   
    // }
    
    // function getFieldWhere($id){
    //     $CI =& get_instance();
    //     $CI->load->model('Usermodel');
    //     $result =  $CI->Usermodel->get_product_by_cat($id);
    //     return $result;
    // }


    
?>