<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Adminmodel extends  CI_Model{
    

public function getFieldWhere($filed,$tbl,$where,$id){
    $this->db->select("$filed AS field FROM $tbl WHERE  $where = '".$id."'");
    $query = $this->db->get();
    if($query->num_rows() > 0 ){
         $row = $query->row();
         return (stripslashes($row->field));
    }
    else{
        return false;
    }
    
}

/**********************Admin  ANALYTICS Model starts here*************************/
  public function fetch_analytics_data(){
      $this->db->select('*');
      $this->db->from('tbl_category');
      $this->db->where('status','1');
      $category_data = $this->db->get();
      $category = $category_data->num_rows();
      
      $this->db->select('*');
      $this->db->from('tbl_artist');
      $this->db->where('status','1');
      $artist_data = $this->db->get();
      $artist = $artist_data->num_rows();
      
      
      $this->db->select('*');
      $this->db->from('tbl_venue');
      $this->db->where('status','1');
      $venue_data = $this->db->get();
      $venue = $venue_data->num_rows();
      
      
      $this->db->select('*');
      $this->db->from('tbl_guest');
      $this->db->where('status','1');
      $guest_data = $this->db->get();
      $guest = $guest_data->num_rows();
      
      $analytics = array(
          'category'=>$category,
          'artist'=>$artist,
          'venue'=>$venue,
          'guest'=>$guest
          );
     if($analytics){
          return $analytics; 
      }
     else{
            return false;
     }
   }
   
   public function fetch_today_earning(){
      $today_date = date('Y-m-d');
      $this->db->SELECT("sum(quote_price) as total ");  
      $this->db->FROM('tbl_booking'); 
      $this->db->WHERE("transaction_id != 'NULL'");
      $this->db->where('(DATE(transaction_date)="'.$today_date.'")');
      $query = $this->db->get();
      if ($query->num_rows() > 0) {
           return $result = $query->row();
      }
      else{
        return false;
      }
   }
   
   public function fetch_yearly_earning(){
      $today_date = date('Y-m-d');
      $this->db->SELECT("sum(quote_price) as total ");  
      $this->db->FROM('tbl_booking'); 
      $this->db->WHERE("transaction_id != 'NULL'");
      $this->db->where('(Year(transaction_date)="'.$today_date.'")');
      $query = $this->db->get();
      if ($query->num_rows() > 0) {
           return $result = $query->row();
      }
      else{
        return false;
      }
   }
   
   public function fetch_monthly_earning(){
      $this->db->SELECT("*");  
      $this->db->FROM('tbl_booking'); 
      $this->db->WHERE("transaction_id != 'NULL'");
      $query = $this->db->get();
      if ($query->num_rows() > 0) {
           return $result = $query->result();
      }
      else{
        return false;
      }
   }
  


/**********************Admin Category ANALYTICS Model starts here*************************/


/**********************Admin Details Model starts here*************************/

private function verifyHashedPassword($plainPassword, $hashedPassword){
return password_verify($plainPassword, $hashedPassword) ? true : false;
}

public function admin_login_validation($adminemail,$password){
    $this->db->where('admin_email', strtolower($adminemail));  
    $query = $this->db->get('tbl_admin'); 
    $admindetails = $query->result();
        if(!empty($admindetails)){  
            if($password === $admindetails[0]->password){
            return $this->read_admin_information($adminemail);
            } 
            else{
            return false;
            }
        } 
        else{ 
            return false;       
            } 

         }


    /*********************Admin details Model Starts Here**************************/

public function read_admin_information($adminemail) {
    $condition = "admin_email =" . "'" . $adminemail . "'";
    $this->db->select('*');
    $this->db->from('tbl_admin');
    $this->db->where($condition);
    $this->db->limit(1);
    $query = $this->db->get();
    if ($query->num_rows() == 1) {
    return $row = $query->row();
    } else {
    return false;
    }
}

var $admin_columnport = array('name', 'email',null, null, null);  
function makeadmin_query()  
{  
    $this->db->select("*");  
    $this->db->from('tbl_admin');  
    if(isset($_POST["search"]["value"]))  
    {  
    $this->db->like("admin_name", $_POST["search"]["value"]);  
    }
    if(isset($_POST["search"]["value"]))  
    {  
    $this->db->like("admin_email", $_POST["search"]["value"]);  
    }  
    if(isset($_POST["order"]))  
    {  
    $this->db->order_by($this->admin_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
    }  
    else  
    {  
    $this->db->order_by('id', 'DESC');  
    }  
    }  
    public function fetch_all_admin_details_model(){  
    $this->makeadmin_query();  
    if($_POST["length"] != -1)  
    {  
    $this->db->limit($_POST['length'], $_POST['start']);  
    }  
    $query = $this->db->get();  
    return $query->result();  
    }  
    public function get_filtered_admindata(){  
    $this->makeadmin_query();  
    $query = $this->db->get();  
    return $query->num_rows();  
    }       
    public function get_all_admindata()  
    {  
    $this->db->select("*");  
    $this->db->from('tbl_admin');  
    return $this->db->count_all_results();  
    } 
    
    public function get_filtered_paymentdata(){  
    $this->makeadmin_query();  
    $query = $this->db->get();  
    return $query->num_rows();  
    }
    
    public function update_admin($pid, $data) {  
    $this->db->where("id", $pid);  
    $this->db->update("tbl_admin", $data); 
    if($this->db->affected_rows() > 0){
    return true;
    }else{
    return false;
    } 
   }    
/***********************Admin Details Model Ends here***************************/


    

/**********************Categories Listing Model Starts Here*****************/
    
public function fetch_all_category_listing_model(){ 
 $this->makeport_category_listing_query();  
 if($_POST["length"] != -1)  
 {  
  $this->db->limit($_POST['length'], $_POST['start']);  
}  
$query = $this->db->get();  
return $query->result();  
}


var $category_listing_columnport = array(null,'category_name','added_at',null,null);  
function makeport_category_listing_query(){  
  $this->db->select("*");  
  $this->db->from('tbl_category');  
  if(isset($_POST["search"]["value"]))  
  {  
    $this->db->like("category_name", $_POST["search"]["value"]);
    $this->db->like("category_slug", $_POST["search"]["value"]); 
  }  
  if(isset($_POST["order"])){  
    $this->db->order_by($this->category_listing_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
  }  
  else  
  {  
    $this->db->order_by('id', 'AESC');  
  }  
}

public function get_all_category_listing_model(){  
 $this->db->select("*");  
 $this->db->from('tbl_category');  
 return $this->db->count_all_results();  
} 

public function get_filtered_category_listing_model(){  
 $this->makeport_category_listing_query();  
 $query = $this->db->get();  
 return $query->num_rows();  
}


public function save_admin_data($data){
    $this->db->insert('tbl_admin',$data);
    if($this->db->affected_rows() > 0){
    return true;
  }else{
    return false;
  }
}

public function insert_category_listing_data_model($table, $data){
  $this->db->insert($table, $data);
  if($this->db->affected_rows() > 0){
    return true;
  }else{
    return false;
  }
}

public function update_category_listing_data_model($data,$id){
    $this->db->where('id',$id);
    $this->db->update("tbl_category", $data);
    if($this->db->affected_rows() > 0){
        return true;
    }
    else{
        return false;
    }
    
}

public function fetch_single_category_listing_model($id){
    $this->db->select('*');
    $this->db->from('tbl_category');
    $this->db->where('id',$id);
    $query = $this->db->get();
    return $query->row();
}

public function update_category_listing_status($proid, $data){
     $this->db->where("id", $proid);  
     $this->db->update("tbl_category", $data); 
     if($this->db->affected_rows() > 0){
      return true;
    }
    else{
      return false;
    } 
}

 public function delete_category_listing_model($proid){
  $this->db->where("id", $proid);  
   $query=$this->db->delete('tbl_category');
   if($query){
     return true;
    }else{
     return false;
    } 
 }
    
    
/********************Categories Model Ends Here*******************************/


/**********************artist Listing Model Starts Here*****************/
    
    public function fetch_all_artist_listing_model(){  
      $this->makeport_artist_listing_query();  
      if($_POST["length"] != -1)  
      {  
        $this->db->limit($_POST['length'], $_POST['start']);  
      }  
      $query = $this->db->get();
      return $query->result();  
    }

    var $artist_listing_columnport = array(); 
     
    function makeport_artist_listing_query(){  
      $this->db->select("*");  
      $this->db->from('tbl_artist'); 
      $this->db->where('tbl_artist.delete_status',0);
      $this->db->select("(SELECT SUM(quote_price) as total_price FROM tbl_booking WHERE tbl_booking.artist_id = tbl_artist.id AND DATE_FORMAT(tbl_booking.booking_date, '%Y-%m') = '".date('Y-m')."' GROUP BY artist_id) AS month_price, 
      (SELECT SUM(quote_price) as total_price FROM tbl_booking WHERE tbl_booking.artist_id = tbl_artist.id AND DATE_FORMAT(tbl_booking.booking_date, '%Y') = '".date('Y')."' GROUP BY artist_id) AS year_price, 
      (SELECT COUNT(*) as total_booking FROM tbl_booking WHERE tbl_booking.artist_id = tbl_artist.id AND status in (0,3,5) GROUP BY artist_id) AS total_booking_taken, 
      (SELECT COUNT(*) as total_canceled FROM tbl_booking WHERE tbl_booking.artist_id = tbl_artist.id AND status in (7,9) GROUP BY artist_id) AS total_booking_canceled", false); 
      if(isset($_POST["search"]["value"])){ 
          $this->db->group_start();
        $this->db->or_like("artist_urn", $_POST["search"]["value"]);
        $this->db->or_like("artist_name", $_POST["search"]["value"]);
        $this->db->or_like("artist_email", $_POST["search"]["value"]); 
        $this->db->or_like("artist_contact", $_POST["search"]["value"]); 
        $this->db->or_like("building_number", $_POST["search"]["value"]); 
        $this->db->or_like("street_number", $_POST["search"]["value"]);
        $this->db->or_like("town", $_POST["search"]["value"]);  
        $this->db->or_like("city", $_POST["search"]["value"]); 
        $this->db->or_like("post_code", $_POST["search"]["value"]); 
        $this->db->group_end();
      }  
      if(isset($_POST["order"])){  
        $this->db->order_by($this->artist_listing_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
      }  
      else  
      {  
        $this->db->order_by('id', 'DESC');  
      }  
    }

    public function get_artist_rating($artist_id){
      $this->db->select("tbl_artist_reviews.*, tbl_artist.artist_name, tbl_venue.venue_name, .tbl_guest.username as guest_name", false);  
      $this->db->from('tbl_artist_reviews');  
      $this->db->join('tbl_artist', 'tbl_artist.id=tbl_artist_reviews.artist_id', 'left');  
      $this->db->join('tbl_venue', 'tbl_venue.id=tbl_artist_reviews.venue_id', 'left');  
      $this->db->join('tbl_guest', 'tbl_guest.id=tbl_artist_reviews.guest_id', 'left');
      $this->db->where("tbl_artist_reviews.artist_id", $artist_id); 
      $query = $this->db->get();
      return $query->result();
    }

    public function delete_artist_rating_model($rating){
        $this->db->where("id", $rating);  
        $query=$this->db->delete('tbl_artist_reviews');
        if($query){
          return true;
        }else{
          return false;
        } 
    }

    public function revise_artist_rating_model($artist_id){
      $this->db->select("tbl_artist_reviews.*", false);  
      $this->db->from('tbl_artist_reviews');
      $this->db->where("tbl_artist_reviews.artist_id", $artist_id); 
      $query = $this->db->get();
      $rows = $query->num_rows();
      if($rows > 0){
        $ratings = $query->result();
        $total_rating = 0;
        foreach($ratings as $rating){
          $total_rating += ($rating->rating + $rating->rating_2 + $rating->rating_3)/3;
        }
        $avg_rating = ($total_rating/count($ratings));
        $avg_rating = round($avg_rating, 2);
        $this->db->update('tbl_artist', ['rating' => $avg_rating], ['id' => $artist_id]);
      }
  }
    
    public function get_all_artist_listing_model(){  
     $this->db->select("*");  
     $this->db->from('tbl_artist');  
     return $this->db->count_all_results();  
    } 
    
    public function get_filtered_artist_listing_model(){  
     $this->makeport_artist_listing_query();  
     $query = $this->db->get();  
     return $query->num_rows();  
    }
    
    public function delete_artist_listing_model($proid){
        $this->db->where("id", $proid);  
        $query=$this->db->update('tbl_artist',['deleted_at' => date('Y-m-d H:i:s'),'delete_status'=>1]);
       if($query){
         return true;
        }else{
         return false;
        } 
    }
    
    public function delete_venue_listing_model($proid){
        $this->db->where("id", $proid);  
        $query=$this->db->update('tbl_venue',['deleted_at' => date('Y-m-d H:i:s'),'delete_status'=>1]);
       if($query){
         return true;
        }else{
         return false;
        } 
    }

    public function delete_guest_listing_model($proid){
        $this->db->where("id", $proid);  
        $query=$this->db->update('tbl_guest',['deleted_at' => date('Y-m-d H:i:s'),'delete_status'=>1]);
       if($query){
         return true;
        }else{
         return false;
        } 
    }
    
    public function update_artist_listing_status($proid, $data){
         $this->db->where("id", $proid);  
         $this->db->update("tbl_artist", $data); 
         if($this->db->affected_rows() > 0){
          return true;
        }
        else{
          return false;
        } 
    }
    
    
/********************artist listing Model Ends Here*******************************/

/**********************Artist By Rating Model Starts Here*****************/
    
        public function fetch_all_artist_by_rating_model(){  
         $this->makeport_artist_by_rating_query();  
         if($_POST["length"] != -1)  
         {  
          $this->db->limit($_POST['length'], $_POST['start']);  
        }  
        $query = $this->db->get();  
        //  echo $this->db->last_query();
        // die;
        return $query->result();  
        }
        var $artist_by_rating_columnport = array(null,'artist_name','artist_email','artist_contact','rating','artist_price','building_number',
        'street_number','town','city','post_code');  
        function makeport_artist_by_rating_query(){  
          $this->db->select("*");  
          $this->db->from('tbl_artist');
          $this->db->WHERE("rating != 'NULL'");
          //$this->db->order_by("rating", "DESC");
          if(isset($_POST["search"]["value"])){  
            $this->db->like("artist_name", $_POST["search"]["value"]);
            $this->db->like("artist_email", $_POST["search"]["value"]);
            $this->db->like("artist_contact", $_POST["search"]["value"]); 
            $this->db->like("rating", $_POST["search"]["value"]); 
            $this->db->like("artist_price", $_POST["search"]["value"]);
            $this->db->like("building_number", $_POST["search"]["value"]); 
            $this->db->like("street_number", $_POST["search"]["value"]); 
            $this->db->like("town", $_POST["search"]["value"]); 
            $this->db->like("city", $_POST["search"]["value"]); 
            $this->db->like("post_code", $_POST["search"]["value"]);
          }  
          if(isset($_POST["order"])){  
            $this->db->order_by($this->artist_by_rating_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
          }  
          else  
          {  
            $this->db->order_by('id', 'DESC');  
          }  
        }
        
        public function get_all_artist_by_rating_model(){  
          $this->db->select("*");  
          $this->db->from('tbl_artist');
          $this->db->WHERE("rating != 'NULL'");  
         return $this->db->count_all_results();  
        } 
        
        public function get_filtered_artist_by_rating_model(){  
         $this->makeport_artist_by_rating_query();  
         $query = $this->db->get();  
         return $query->num_rows();  
        }
/********************Artist By Rating Model Ends Here*******************************/

/**********************Artist By Compeleted Booking Model Starts Here*****************/
    
        public function fetch_all_artist_completed_performance_model(){  
            $this->makeport_artist_completed_performance_query();  
            if($_POST["length"] != -1)  
            {  
              $this->db->limit($_POST['length'], $_POST['start']);  
            }  
            $query = $this->db->get();
            // echo $this->db->last_query();
            // die;
            return $query->result();  
            }
        var $artist_completed_performance_columnport = array(null,'artist_name','artist_urn','artist_email','artist_contact','rating','artist_price','building_number',
        'street_number','town','city','post_code');
        function makeport_artist_completed_performance_query(){
          // $this->db->SELECT("tbl_artist.*,tbl_booking.*,tbl_booking.status AS booking_status");
          $this->db->SELECT("tbl_artist.id,tbl_artist.artist_urn,tbl_artist.artist_name,tbl_artist.artist_email,tbl_artist.artist_contact,tbl_artist.rating,tbl_artist.artist_bio,
          tbl_artist.artist_price,tbl_artist.artist_travel,tbl_artist.building_number,tbl_artist.street_number,tbl_artist.town,tbl_artist.city,tbl_artist.post_code,
          tbl_booking.booking_id,tbl_booking.booking_date,tbl_booking.c_date,tbl_booking.status AS booking_status");  
          $this->db->FROM("tbl_artist");
          $this->db->join("tbl_booking","tbl_artist.id = tbl_booking.artist_id",'left');
          $this->db->WHERE("tbl_booking.status = 5");
          if(isset($_POST["search"]["value"]))  
          {  
            // $this->db->like("tbl_artist.artist_name", $_POST["search"]["value"]);
            // $this->db->like("tbl_artist.artist_contact", $_POST["search"]["value"]); 
            // $this->db->like("tbl_artist.artist_price", $_POST["search"]["value"]);  
            // $this->db->like("tbl_artist.artist_urn", $_POST["search"]["value"]); 
            // $this->db->like("tbl_artist.street_number", $_POST["search"]["value"]); 
            // $this->db->like("town", $_POST["search"]["value"]); 
            // $this->db->like("city", $_POST["search"]["value"]); 
            // $this->db->like("post_code", $_POST["search"]["value"]);
          }  
          if(isset($_POST["order"])){  
            $this->db->order_by($this->artist_completed_performance_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
          }  
          else  
          {  
            $this->db->order_by('id', 'DESC');  
          }  
        }
        
        public function get_all_artist_completed_performance_model(){ 
        $this->db->SELECT("tbl_artist.id,tbl_artist.artist_urn,tbl_artist.artist_name,tbl_artist.artist_email,tbl_artist.artist_contact,tbl_artist.rating,tbl_artist.artist_bio,
          tbl_artist.artist_price,tbl_artist.artist_travel,tbl_artist.building_number,tbl_artist.street_number,tbl_artist.town,tbl_artist.city,tbl_artist.post_code,
          tbl_booking.booking_id,tbl_booking.booking_date,tbl_booking.c_date,tbl_booking.status AS booking_status");  
          $this->db->FROM("tbl_artist");
          $this->db->join("tbl_booking","tbl_artist.id = tbl_booking.artist_id",'left');
          $this->db->WHERE("tbl_booking.status = 5");
         return $this->db->count_all_results();  
        }
        
        public function get_filtered_artist_completed_performance_model(){  
         $this->makeport_artist_completed_performance_query();  
         $query = $this->db->get();  
         return $query->num_rows();
        }
/********************Artist By Compeleted Booking Model Ends Here*******************************/  


/**********************Artist Payment details Model Starts Here*****************/        
        public function fetch_payment_data(){  
         $this->makeport_payment_data_query();  
         if($_POST["length"] != -1)  
         {  
          $this->db->limit($_POST['length'], $_POST['start']);  
        }  
        $query = $this->db->get();
        // echo $this->db->query();
        // die;
        return $query->result();  
        }
        
        
        
        var $artist_payment_data_columnport = array(null,'artist_name','artist_urn','venue_name');  
        function makeport_payment_data_query(){
            $this->db->select('tbl_booking.booking_id as booking_table_id,tbl_booking.booking_id as booking_added_at,
            tbl_booking.booking_id,tbl_booking.transaction_id,tbl_booking.payment_method, tbl_booking.booking_date,tbl_booking.status,
            tbl_artist.artist_name,tbl_artist.artist_urn,tbl_venue.venue_name');
            $this->db->from('tbl_booking');
            $this->db->join("tbl_artist","tbl_booking.artist_id = tbl_artist.id");
            $this->db->join("tbl_venue","tbl_venue.id = tbl_booking.venue_id");
            $this->db->where("tbl_booking.transaction_id !='NULL'");
          if(isset($_POST["search"]["value"])){  
            //$this->db->like("booking_id", $_POST["search"]["value"]);
            //$this->db->like("artist_name", $_POST["search"]["value"]); 
            //$this->db->like("artist_urn", $_POST["search"]["value"]);  
            //$this->db->like("building_number", $_POST["search"]["value"]); 
            //$this->db->like("street_number", $_POST["search"]["value"]); 
            //$this->db->like("town", $_POST["search"]["value"]); 
            //$this->db->like("city", $_POST["search"]["value"]); 
            //$this->db->like("post_code", $_POST["search"]["value"]);
          }  
          if(isset($_POST["order"])){  
            $this->db->order_by($this->artist_payment_data_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
          }  
          else  
          {  
            $this->db->order_by('tbl_booking.id', 'DESC');  
          }  
        }
        
        public function get_all_paymentdata(){ 
          $this->db->select("*");  
          $this->db->from('tbl_booking');
          $this->db->where("tbl_booking.transaction_id !='NULL'");
          // and tbl_booking.status ='6'
          return $this->db->count_all_results(); 
        } 
        
         
        /*public function fetch_single_product_listing_model($artist_id){
        $this->db->select('*');
        $this->db->from('tbl_booking');
        $this->db->where('artist_id',$artist_id);
        $query = $this->db->get();
        return $query->result();
      }*/
        
        
        // public function fetch_payment_data(){
        //     $this->db->select('tbl_booking.booking_id,tbl_booking.transaction_id, tbl_booking.payment_method, tbl_booking.booking_date, tbl_artist.artist_name, 
        //     tbl_venue.venue_name');
        //     $this->db->from('tbl_booking');
        //     $this->db->join("tbl_artist","tbl_booking.artist_id = tbl_artist.id");
        //     $this->db->join("tbl_venue","tbl_venue.id = tbl_booking.venue_id");
        //     $query = $this->db->get();
        //     return $query->result();
        // }
        
        /*public function get_all_paymentdata()  
        {  
        $this->db->select("*");  
        $this->db->from('tbl_booking');  
        return $this->db->count_all_results();  
        } */
        
        /*public function get_filtered_artist_completed_performance_model(){  
         $this->makeport_artist_completed_performance_query();  
         $query = $this->db->get();  
         return $query->num_rows();  
        }*/

/**********************Artist Payment Model Ends Here*****************/


/**********************artist analysis report Model Starts Here*****************/
    
        public function fetch_all_artist_analysis_listing_model(){  
         $this->makeport_artist_analysis_query();  
         if($_POST["length"] != -1)  
         {  
          $this->db->limit($_POST['length'], $_POST['start']);  
        }  
        $query = $this->db->get();
        // echo $this->db->last_query();
        // die;
        return $query->result();  
        }
        var $artist_analysis_columnport = array(null,'artist_name','artist_contact','artist_price','building_number',
        'street_number','town','city','post_code');  
        function makeport_artist_analysis_query(){
          $this->db->select("*");
          $this->db->from('tbl_artist');
          if(isset($_POST["search"]["value"]))  
          {  
            $this->db->like("artist_name", $_POST["search"]["value"]);
            $this->db->like("artist_contact", $_POST["search"]["value"]); 
            $this->db->like("artist_price", $_POST["search"]["value"]);  
            $this->db->like("building_number", $_POST["search"]["value"]); 
            $this->db->like("street_number", $_POST["search"]["value"]); 
            $this->db->like("town", $_POST["search"]["value"]); 
            $this->db->like("city", $_POST["search"]["value"]); 
            $this->db->like("post_code", $_POST["search"]["value"]);
          }  
          if(isset($_POST["order"])){  
            $this->db->order_by($this->artist_analysis_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
          }  
          else  
          {  
            $this->db->order_by('id', 'DESC');  
          }  
        }
        
        public function get_all_artist_analysis_model(){ 
          $this->db->select("*");  
          $this->db->from('tbl_artist');
          return $this->db->count_all_results();  
        } 
        
        public function get_filtered_artist_analysis_model(){  
         $this->makeport_artist_analysis_query();  
         $query = $this->db->get();  
         return $query->num_rows();
        }
         
        public function fetch_single_product_listing_model($artist_id){
        $this->db->select('*');
        $this->db->from('tbl_booking');
        $this->db->where('artist_id',$artist_id);
        $query = $this->db->get();
        return $query->result();
      }
/********************artist analysis report Model Ends Here*******************************/



    /**********************venue Listing Model Starts Here*****************/
        
    public function fetch_all_venue_listing_model(){  
     $this->makeport_venue_listing_query();  
     if($_POST["length"] != -1)  
     {  
      $this->db->limit($_POST['length'], $_POST['start']);  
    }  
    $query = $this->db->get();  
    return $query->result();  
    }
    
    
    var $venue_listing_columnport = array(null,null,null,null,null,null,null);  
    function makeport_venue_listing_query(){  
      $this->db->select("*");
      $this->db->select("(SELECT SUM(quote_price) as total_price FROM tbl_booking WHERE tbl_booking.venue_id = tbl_venue.id AND DATE_FORMAT(tbl_booking.booking_date, '%Y-%m') = '".date('Y-m')."' GROUP BY venue_id) AS month_price, 
      (SELECT SUM(quote_price) as total_price FROM tbl_booking WHERE tbl_booking.venue_id = tbl_venue.id AND DATE_FORMAT(tbl_booking.booking_date, '%Y') = '".date('Y')."' GROUP BY venue_id) AS year_price, 
      (SELECT COUNT(*) as total_booking FROM tbl_booking WHERE tbl_booking.venue_id = tbl_venue.id AND status in (0,3,5) GROUP BY venue_id) AS total_booking_taken, 
      (SELECT COUNT(*) as total_canceled FROM tbl_booking WHERE tbl_booking.venue_id = tbl_venue.id AND status in (7,9) GROUP BY venue_id) AS total_booking_canceled", false);   
      $this->db->from('tbl_venue');  
      $this->db->where('tbl_venue.delete_status',0);
      if(isset($_POST["search"]["value"]))  
      {  
          $this->db->group_start();
        $this->db->like("venue_urn", $_POST["search"]["value"]);
        $this->db->or_like("venue_name", $_POST["search"]["value"]); 
        $this->db->or_like("email", $_POST["search"]["value"]);
        $this->db->or_like("contact_no", $_POST["search"]["value"]); 
        $this->db->or_like("rating", $_POST["search"]["value"]); 
        $this->db->or_like("venue_bio", $_POST["search"]["value"]);
        $this->db->or_like("venue_manager_name", $_POST["search"]["value"]);
        $this->db->or_like("manager_contact_no", $_POST["search"]["value"]);
        $this->db->or_like("city", $_POST["search"]["value"]);
        $this->db->or_like("building_number", $_POST["search"]["value"]);
        $this->db->or_like("street_number", $_POST["search"]["value"]);
        $this->db->or_like("town", $_POST["search"]["value"]);
        $this->db->group_end();
      }  
      if(isset($_POST["order"])){  
        $this->db->order_by($this->venue_listing_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
      }  
      else  
      {  
        $this->db->order_by('id', 'DESC');  
      }  
    }
    
    public function get_all_venue_listing_model(){  
     $this->db->select("*");  
     $this->db->from('tbl_venue');  
     return $this->db->count_all_results();  
    } 
    
    public function get_filtered_venue_listing_model(){  
     $this->makeport_venue_listing_query();  
     $query = $this->db->get();  
     return $query->num_rows();  
    }
    
    public function update_venue_listing_status($proid, $data){
         $this->db->where("id", $proid);  
         $this->db->update("tbl_venue", $data); 
         if($this->db->affected_rows() > 0){
          return true;
        }
        else{
          return false;
        } 
    }
        
    /********************venue listing Model Ends Here*******************************/
    
    /**********************Venue By rating Model Starts Here*****************/
            
        public function fetch_all_venue_by_rating_model(){  
         $this->makeport_venue_by_rating_query();  
         if($_POST["length"] != -1)  
         {  
          $this->db->limit($_POST['length'], $_POST['start']);  
        }  
        $query = $this->db->get();  
        return $query->result();  
        }
        
        
        var $venue_by_rating_columnport = array(null,'venue_name','email','contact_no',null);  
        function makeport_venue_by_rating_query(){  
          $this->db->select("*");  
          $this->db->from('tbl_venue');
          $this->db->WHERE("rating != 'NULL'");
          $this->db->order_by("rating", "DESC");
          if(isset($_POST["search"]["value"]))  
          {  
            $this->db->like("venue_name", $_POST["search"]["value"]);
            $this->db->or_like("email", $_POST["search"]["value"]); 
            $this->db->or_like("contact_no", $_POST["search"]["value"]); 
          }  
          if(isset($_POST["order"])){  
            $this->db->order_by($this->venue_by_rating_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
          }  
          else  
          {  
            $this->db->order_by('id', 'DESC');  
          }  
        }
        
        public function get_all_venue_by_rating_model(){  
          $this->db->select("*");  
          $this->db->from('tbl_venue');
          $this->db->WHERE("rating != 'NULL'");
          $this->db->order_by("rating", "DESC");  
         return $this->db->count_all_results();  
        } 
        
        public function get_filtered_venue_by_rating_model(){  
         $this->makeport_venue_by_rating_query();  
         $query = $this->db->get();  
         return $query->num_rows();  
        }
        
        
        public function insert_venue_by_rating_data_model($table, $data){
          $this->db->insert($table, $data);
          if($this->db->affected_rows() > 0){
            return true;
          }else{
            return false;
          }
        }
        
        public function update_venue_by_rating_data_model($data,$id){
            $this->db->where('id',$id);
            $this->db->update("tbl_venue", $data);
            if($this->db->affected_rows() > 0){
                return true;
            }
            else{
                return false;
            }
            
        }
        
        public function fetch_single_venue_by_rating_model($id){
            $this->db->select('*');
            $this->db->from('tbl_venue');
            $this->db->where('id',$id);
            $query = $this->db->get();
            return $query->row();
        }
        
        public function update_venue_by_rating_status($proid, $data){
             $this->db->where("id", $proid);  
             $this->db->update("tbl_venue", $data); 
             if($this->db->affected_rows() > 0){
              return true;
            }
            else{
              return false;
            } 
        }
        
         public function delete_venue_by_rating_model($proid){
          $this->db->where("id", $proid);  
           $query=$this->db->delete('tbl_venue');
           if($query){
             return true;
            }else{
             return false;
            } 
         }
            
            
    /********************Venue By rating Model Ends Here*******************************/


    /**********************guest Listing Model Starts Here*****************/
        
    public function fetch_all_guest_listing_model(){  
     $this->makeport_guest_listing_query();  
     if($_POST["length"] != -1)  
     {  
      $this->db->limit($_POST['length'], $_POST['start']);  
    }  
    $query = $this->db->get();  
    return $query->result();  
    }


        var $guest_listing_columnport = array(null,null,null,null,null,null,null,null,null);  
        function makeport_guest_listing_query(){  
          $this->db->select("*");
          $this->db->select("(SELECT SUM(quote_price) as total_price FROM tbl_booking WHERE tbl_booking.guest_id = tbl_guest.id AND DATE_FORMAT(tbl_booking.booking_date, '%Y-%m') = '".date('Y-m')."' GROUP BY guest_id) AS month_price, 
          (SELECT SUM(quote_price) as total_price FROM tbl_booking WHERE tbl_booking.guest_id = tbl_guest.id AND DATE_FORMAT(tbl_booking.booking_date, '%Y') = '".date('Y')."' GROUP BY guest_id) AS year_price, 
          (SELECT COUNT(*) as total_booking FROM tbl_booking WHERE tbl_booking.guest_id = tbl_guest.id AND status in (0,3,5) GROUP BY guest_id) AS total_booking_taken, 
          (SELECT COUNT(*) as total_canceled FROM tbl_booking WHERE tbl_booking.guest_id = tbl_guest.id AND status in (7,9) GROUP BY guest_id) AS total_booking_canceled", false);    
          $this->db->from('tbl_guest');  
          $this->db->where('tbl_guest.delete_status',0);
          if(isset($_POST["search"]["value"]))  
          { 
            $this->db->group_start();
            $this->db->like("guest_urn", $_POST["search"]["value"]);
            $this->db->or_like("username", $_POST["search"]["value"]);
            $this->db->or_like("manager_contact_email", $_POST["search"]["value"]);
            $this->db->or_like("manager_contact_no", $_POST["search"]["value"]); 
            $this->db->or_like("rating", $_POST["search"]["value"]);
            $this->db->or_like("guest_bio", $_POST["search"]["value"]); 
            $this->db->or_like("manager_name", $_POST["search"]["value"]); 
            $this->db->or_like("contact_no", $_POST["search"]["value"]); 
            $this->db->or_like("city", $_POST["search"]["value"]); 
            $this->db->or_like("building_number", $_POST["search"]["value"]); 
            $this->db->or_like("street_number", $_POST["search"]["value"]); 
            $this->db->or_like("town", $_POST["search"]["value"]); 
            $this->db->group_end(); 
          }  
          if(isset($_POST["order"])){  
            $this->db->order_by($this->guest_listing_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
          }  
          else  
          {  
            $this->db->order_by('id', 'DESC');  
          }  
        }
        
        public function get_all_guest_listing_model(){  
         $this->db->select("*");  
         $this->db->from('tbl_guest');  
         return $this->db->count_all_results();  
        } 
        
        public function get_filtered_guest_listing_model(){  
         $this->makeport_guest_listing_query();  
         $query = $this->db->get();  
         return $query->num_rows();  
        }
        
        public function update_guest_listing_status($proid, $data){
         $this->db->where("id", $proid);  
         $this->db->update("tbl_guest", $data); 
         if($this->db->affected_rows() > 0){
          return true;
        }
        else{
          return false;
        } 
       }



/********************guest listing Model Ends Here*******************************/

/**********************booking Listing Model Starts Here*****************/
    
public function fetch_all_booking_listing_model(){  
 $this->makeport_booking_listing_query();  
 if($_POST["length"] != -1)  
 {  
  $this->db->limit($_POST['length'], $_POST['start']);  
}  
$query = $this->db->get();  
return $query->result();  
}


var $booking_listing_columnport = array('category');  
function makeport_booking_listing_query(){  
  $this->db->select("*");  
  $this->db->from('tbl_booking');
  if(isset($_POST['u']) && isset($_POST['i']) && isset($_POST['type'])){
    switch($_POST['u']){
      case 'a':
        $this->db->where('artist_id', $_POST['i']);
        if($_POST['type'] == 'taken'){
          $this->db->where_in('status', [0,3,5]);
        }elseif($_POST['type'] == 'canceled'){
          $this->db->where_in('status', [7,9]);
        }
      break;
      case 'v':
        $this->db->where('venue_id', $_POST['i']);
        if($_POST['type'] == 'taken'){
          $this->db->where_in('status', [0,3,5]);
        }elseif($_POST['type'] == 'canceled'){
          $this->db->where_in('status', [7,9]);
        }
      break;
      case 'g':
        $this->db->where('guest_id', $_POST['i']);
        if($_POST['type'] == 'taken'){
          $this->db->where_in('status', [0,3,5]);
        }elseif($_POST['type'] == 'canceled'){
          $this->db->where_in('status', [7,9]);
        }
      break;
    }
  } 

  if(isset($_POST["search"]["value"]))  
  {  
    $this->db->like("booking_id", $_POST["search"]["value"]);
  }  
  if(isset($_POST["order"])){  
    $this->db->order_by($this->booking_listing_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
  }  
  else  
  {  
    $this->db->order_by('id', 'DESC');  
  }  
}

public function get_all_booking_listing_model(){  
 $this->db->select("*");  
 $this->db->from('tbl_booking');  
 return $this->db->count_all_results();  
} 

public function get_filtered_booking_listing_model(){  
 $this->makeport_booking_listing_query();  
 $query = $this->db->get();  
 return $query->num_rows();  
}


public function insert_booking_listing_data_model($table, $data){
  $this->db->insert($table, $data);
  if($this->db->affected_rows() > 0){
    return true;
  }else{
    return false;
  }
}

public function update_booking_listing_data_model($data,$id){
    $this->db->where('id',$id);
    $this->db->update("tbl_booking", $data);
    if($this->db->affected_rows() > 0){
        return true;
    }
    else{
        return false;
    }
    
}

public function fetch_single_booking_listing_model($id){
    $this->db->select('*');
    $this->db->from('tbl_booking');
    $this->db->where('id',$id);
    $query = $this->db->get();
    return $query->row();
}

public function update_booking_listing_status($proid, $data){
     $this->db->where("id", $proid);  
     $this->db->update("tbl_booking", $data); 
     if($this->db->affected_rows() > 0){
      return true;
    }
    else{
      return false;
    } 
}

 public function delete_booking_listing_model($proid){
  $this->db->where("id", $proid);  
   $query=$this->db->delete('tbl_booking');
   if($query){
     return true;
    }else{
     return false;
    } 
 }

 public function fetch_booking_details($booking_id){
  $this->db->select('*');
  $this->db->from('tbl_booking');
  $this->db->where('booking_id',$booking_id);
  $this->db->join('tbl_artist', 'tbl_booking.artist_id=tbl_artist.id', 'left');
  $this->db->join('tbl_venue', 'tbl_booking.venue_id=tbl_venue.id', 'left');
  $this->db->join('tbl_guest', 'tbl_booking.guest_id=tbl_guest.id', 'left');
  $this->db->select('tbl_booking.*, tbl_artist.artist_name, tbl_venue.venue_name, tbl_guest.username');
  $query = $this->db->get();
  return $query->row();
}
    
    
/********************booking listing Model Ends Here*******************************/

/**********************Completed booking Listing Model Starts Here*****************/
    
    public function fetch_all_completed_booking_listing_model(){  
     $this->makeport_completed_booking_listing_query();  
     if($_POST["length"] != -1)  
     {  
      $this->db->limit($_POST['length'], $_POST['start']);  
     }  
     $query = $this->db->get(); 
     return $query->result();  
    }
    
    
    var $completed_booking_listing_columnport = array(null,'booking_id','category');  
    function makeport_completed_booking_listing_query(){  
      $this->db->SELECT("*");  
      $this->db->FROM('tbl_booking'); 
      $this->db->WHERE("status >= '5' and(artist_paid_status != '1' OR artist_paid_status is null) and (issue_status != '1' OR issue_status is null)");
      if(isset($_POST["search"]["value"]))  
      {  
        $this->db->like("booking_id", $_POST["search"]["value"]);
        $this->db->like("category", $_POST["search"]["value"]);
      }  
      if(isset($_POST["order"])){  
        $this->db->order_by($this->completed_booking_listing_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
      }  
      else  
      {  
        $this->db->order_by('id', 'DESC');  
      }  
    }
    
    public function get_all_completed_booking_listing_model(){  
     $this->db->SELECT("*");  
     $this->db->FROM('tbl_booking'); 
     $this->db->WHERE("status >= '5' and(artist_paid_status != '1' OR artist_paid_status is null) and (issue_status != '1' OR issue_status is null)");   
     return $this->db->count_all_results();  
    } 
    
    public function get_filtered_completed_booking_listing_model(){  
     $this->makeport_completed_booking_listing_query();  
     $query = $this->db->get();  
     return $query->num_rows();  
    }
    
    
    public function insert_completed_booking_listing_data_model($table, $data){
      $this->db->insert($table, $data);
      if($this->db->affected_rows() > 0){
        return true;
      }else{
        return false;
      }
    }
    
    public function update_completed_booking_listing_data_model($data,$id){
        $this->db->where('id',$id);
        $this->db->update("tbl_booking", $data);
        if($this->db->affected_rows() > 0){
            return true;
        }
        else{
            return false;
        }
        
    }
    
    public function fetch_single_completed_booking_listing_model($id){
        $this->db->select('*');
        $this->db->from('tbl_booking');
        $this->db->where('id',$id);
        $query = $this->db->get();
        return $query->row();
    }
    
    public function update_completed_booking_listing_status($proid, $data){
         $this->db->where("id", $proid);  
         $this->db->update("tbl_booking", $data); 
         if($this->db->affected_rows() > 0){
          return true;
        }
        else{
          return false;
        } 
    }
    
     public function delete_completed_booking_listing_model($proid){
      $this->db->where("id", $proid);  
       $query=$this->db->delete('tbl_booking');
       if($query){
         return true;
        }else{
         return false;
        } 
     } 
     
     
    
/********************Completed booking listing Model Ends Here*******************************/

/**********************Completed booking within 24 hours Listing Model Starts Here*****************/
    
    public function fetch_all_completed_booking_within_24hours_listing_model(){  
     $this->makeport_completed_booking_within_24hours_listing_query();  
     if($_POST["length"] != -1)  
     {  
      $this->db->limit($_POST['length'], $_POST['start']);  
     }  
     $query = $this->db->get(); 
     return $query->result();  
    }
    
    
    var $completed_booking_within_24hours_listing_columnport = array(null,'booking_id','category');  
    function makeport_completed_booking_within_24hours_listing_query(){  
      $today_date = date('Y-m-d');
      $this->db->SELECT("*");  
      $this->db->FROM('tbl_booking');
      $this->db->where("status >= 5 AND (issue_status != '1' OR issue_status is null) AND (artist_paid_status != '1' OR artist_paid_status is null) AND (booking_date like '$today_date')");
      if(isset($_POST["search"]["value"]))  
      {  
        $this->db->like("booking_id", $_POST["search"]["value"]);
        $this->db->like("category", $_POST["search"]["value"]);
      }  
      if(isset($_POST["order"])){  
        $this->db->order_by($this->completed_booking_within_24hours_listing_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
      }  
      else  
      {  
        $this->db->order_by('id', 'DESC');  
      }  
    }
    
    public function get_all_completed_booking_within_24hours_listing_model(){ 
     $today_date = date('Y-m-d');
     $this->db->SELECT("*");  
     $this->db->FROM('tbl_booking'); 
     $this->db->where("status >= 5 AND (issue_status != '1' OR issue_status is null) AND (artist_paid_status != '1' OR artist_paid_status is null) AND (booking_date like '$today_date')");
     return $this->db->count_all_results();  
    } 
    
    public function get_filtered_completed_booking_within_24hours_listing_model(){
     $this->makeport_completed_booking_within_24hours_listing_query(); 
     $query = $this->db->get();  
     return $query->num_rows();  
    }
    
    
/********************Completed booking within 24 hours listing Model Ends Here*******************************/


/**********************Completed booking Listing Model Starts Here*****************/
    
    public function fetch_all_already_paid_artist_listing_model(){  
     $this->makeport_already_paid_artist_listing_query();  
     if($_POST["length"] != -1)  
     {  
      $this->db->limit($_POST['length'], $_POST['start']);  
     }  
     $query = $this->db->get(); 
     return $query->result();  
    }
    
    
    var $already_paid_artist_listing_columnport = array(null,'booking_id','category');  
    function makeport_already_paid_artist_listing_query(){  
      $this->db->SELECT("*");  
      $this->db->FROM('tbl_booking'); 
      $this->db->WHERE("artist_paid_status = '1'");
      if(isset($_POST["search"]["value"]))  
      {  
        $this->db->like("booking_id", $_POST["search"]["value"]);
        $this->db->like("category", $_POST["search"]["value"]);
      }  
      if(isset($_POST["order"])){  
        $this->db->order_by($this->already_paid_artist_listing_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
      }  
      else  
      {  
        $this->db->order_by('id', 'DESC');  
      }  
    }
    
    public function get_all_already_paid_artist_listing_model(){  
     $this->db->SELECT("*");  
     $this->db->FROM('tbl_booking'); 
     $this->db->WHERE("artist_paid_status = '1'");   
     return $this->db->count_all_results();  
    } 
    
    public function get_filtered_already_paid_artist_listing_model(){  
     $this->makeport_already_paid_artist_listing_query();  
     $query = $this->db->get();  
     return $query->num_rows();  
    }
/********************Completed booking listing Model Ends Here*******************************/


/**********************venue Without booking Listing Model Starts Here*****************/
    
    public function fetch_all_venue_without_booking_listing_model(){  
     $this->makeport_venue_without_booking_listing_query();  
     if($_POST["length"] != -1){  
      $this->db->limit($_POST['length'], $_POST['start']);  
    }  
    $query = $this->db->get();  
    return $query->result();  
    }
    var $venue_without_booking_listing_columnport = array(null,'venue_name','email','contact_no',null,null,null); 

    function makeport_venue_without_booking_listing_query(){  
      $this->db->SELECT("t1.*");
      $this->db->FROM("tbl_venue t1");
      $this->db->JOIN("tbl_booking t2",'t2.venue_id = t1.id','LEFT');
      $this->db->WHERE("t2.venue_id IS NULL");
      
      //$this->db->SELECT("t1.* FROM tbl_venue t1 LEFT JOIN tbl_booking t2 ON t2.venue_id = t1.id WHERE t2.venue_id IS NULL");
      //$this->db->FROM("tbl_venue");
      //$this->db->WHERE("id NOT IN (SELECT venue_id FROM tbl_booking GROUP BY venue_id)");
      if(isset($_POST["search"]["value"]))  
      {  
        // $this->db->like("venue_name", $_POST["search"]["value"]);
        // $this->db->like("email", $_POST["search"]["value"]); 
        // $this->db->like("contact_no", $_POST["search"]["value"]); 
      }  
      if(isset($_POST["order"])){  
        $this->db->order_by($this->venue_without_booking_listing_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
      }  
      else  
      {  
        $this->db->order_by('id', 'DESC');  
      }  
    }

    public function get_all_venue_without_booking_listing_model(){  
        $this->db->SELECT("t1.*");
        $this->db->FROM("tbl_venue t1");
        $this->db->JOIN("tbl_booking t2",'t2.venue_id = t1.id','LEFT');
        $this->db->WHERE("t2.venue_id IS NULL");
       return $this->db->count_all_results();  
    } 

    public function get_filtered_venue_without_booking_listing_model(){  
     $this->makeport_venue_without_booking_listing_query();  
     $query = $this->db->get();  
     return $query->num_rows();  
    }
    
/********************venue Without booking listing Model Ends Here*******************************/

/**********************Venue having problem with artist in booking Listing Model Starts Here*****************/
    
    public function fetch_all_venue_problem_with_artist_booking_listing_model(){ 
 
     $this->makeport_venue_problem_with_artist_booking_listing_query();  
     if($this->input->post('length') != -1)  
     {  
      $this->db->limit($this->input->post('length'), $this->input->post('start'));  
    }  
    $query = $this->db->get(); 
    // echo $this->db->last_query();
    // die;
    return $query->result();  
    }
    
    
    var $venue_problem_with_artist_booking_listing_columnport = array(null,'artist_name','artist_email','artist_contact','email','venue_name','contact_no');  
    function makeport_venue_problem_with_artist_booking_listing_query(){  
      $this->db->SELECT("tbl_booking.id,tbl_booking.issue_status,tbl_booking.venue_id,tbl_booking.booking_id,tbl_booking.issue_with_artist,tbl_booking.booking_date,
      tbl_booking.start_time,tbl_booking.end_time,tbl_booking.c_date,tbl_artist.artist_name,tbl_artist.artist_email,tbl_artist.artist_contact,
      tbl_venue.email,tbl_venue.venue_name,tbl_venue.contact_no"); 
      $this->db->FROM('tbl_booking');
      $this->db->join('tbl_artist','tbl_booking.artist_id = tbl_artist.id','left');
      $this->db->join('tbl_venue','tbl_booking.venue_id = tbl_venue.id','left');
      $this->db->WHERE('tbl_booking.issue_status','1');
      if(isset($_POST["search"]["value"]))  
      {  
        $this->db->like("artist_name", $_POST["search"]["value"]);
        $this->db->like("artist_email", $_POST["search"]["value"]); 
        $this->db->like("artist_contact", $_POST["search"]["value"]); 
        $this->db->like("venue_name", $_POST["search"]["value"]); 
        $this->db->like("email", $_POST["search"]["value"]); 
        $this->db->like("contact_no", $_POST["search"]["value"]); 
      }  
      if(isset($_POST["order"])){  
        $this->db->order_by($this->makeport_venue_problem_with_artist_booking_listing_query_columnport[$_POST['order']['0']['column']], $_POST['order']['0']['dir']); 
      }  
      else  
      {  
        $this->db->order_by('id', 'DESC');  
      }  
    }

    public function get_all_venue_problem_with_artist_listing_model(){  
      $this->db->SELECT("*"); 
      $this->db->FROM('tbl_booking');
      $this->db->WHERE('issue_status','1'); 
      return $this->db->count_all_results();  
    } 

    public function get_filtered_venue_problem_with_artist_listing_model(){  
     $this->makeport_venue_problem_with_artist_booking_listing_query();  
     $query = $this->db->get();  
     return $query->num_rows();  
    }
    public function update_venue_problem_with_artist_booking_listing_status($proid, $data){
         $this->db->where("id", $proid);  
         $this->db->update("tbl_booking", $data); 
         if($this->db->affected_rows() > 0){
          return true;
        }
        else{
          return false;
        } 
    }

    
/********************venue having problem with artist in booking listing Model Ends Here*******************************/



 }
?>