    <!-- The core Firebase JS SDK is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/7.8.2/firebase-app.js"></script>
    
    <!-- TODO: Add SDKs for Firebase products that you want to use
         https://firebase.google.com/docs/web/setup#available-libraries -->
    
    <script>
      // Your web app's Firebase configuration
      var firebaseConfig = {
        apiKey: "AIzaSyCn9QSchZsYD796x0Wsy0GhYzlSLD1q8FA",
        authDomain: "chatsockettesting.firebaseapp.com",
        databaseURL: "https://chatsockettesting.firebaseio.com",
        projectId: "chatsockettesting",
        storageBucket: "chatsockettesting.appspot.com",
        messagingSenderId: "527652198748",
        appId: "1:527652198748:web:5e9f4b5b23a55f92558999"
      };
      // Initialize Firebase
      firebase.initializeApp(firebaseConfig);
    //   var messagesRef = firebase.database().ref('chatsockettesting');
    //   console.log(messagesRef);
      
    </script>

    <!--<script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-app.js"></script>-->
    <script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-database.js"></script>
    
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url('admin/admin_details') ?>">Home</a>
                            </li>

                            <li class="breadcrumb-item active">guest Listing
                            </li>
                        </ol>
                    </div>
                </div>
                <h3 class="content-header-title mb-0">guest Listing</h3>
            </div>

        </div>
        <div class="content-body">
            <!-- Zero configuration table -->
            <section id="configuration">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">guest Listing</h4>

                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <div class="row">
                                        <!--<div class="col-lg-12">-->
                                        <!--    <button class="btn btn-primary float-right btn-sm mb-3" data-toggle="modal" data-target="#successModal">Add New</button>-->
                                        <!--</div>-->
                                    </div>
                                    
                                    <table id="guestTable" class="table table-striped table-bordered zero-configuration" width="100%">
                                        <thead>
                                            <tr>
                                                <th>S.NO</th
                                                <th>Artist Name</th>
                                                <th>Venue Name</th>
                                                <th>Guest  Name</th>
                                                <th>Message</th>
                                                <th>Status</th>
                                                <th>Added date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>

                                    </table>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


        </div>
    </div>
</div>

<script type="text/javascript">
    
	var dataTable = $('#guestTable').DataTable({  
		"processing":true,
		"responsive": true,
		"language": {
			processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> '
		},
		dom: 'Blftip',
        select: true,
        buttons: [
         
        {extend: 'excel',
        footer: 'true',
        text: 'Excel', },
         
        {extend: 'pdf',
        footer: 'true',
        text: 'pdf',
        orientation: 'landscape', },
         
        'print',
             
        {extend: 'excel',
        text: 'Selected Excel',
        footer: 'true',
        exportOptions: {
        modifier: {
        selected: true
                }
            }
        },
        {
        extend: 'pdf',
        footer: 'true',
        orientation: 'landscape',
        text: 'Selected PDF',
        exportOptions: {
        modifier: {
        selected: true
                        }
                    }
                }
        ],
		"serverSide":true,
		"order":[],  
		"ajax":{  
			url:"<?php echo base_url('admin/fetch_all_venue_problem_with_artist_booking'); ?>",  
			type:"POST"  
		},
	});
</script>
