<style>
    #user_type{
        margin: 6px 0px 0px 20px;
    }
</style>
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2">
            <div class="row breadcrumbs-top">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?= base_url('admin/admin_details') ?>">Home</a>
                  </li>
                  
                  <li class="breadcrumb-item active">Admin Details
                  </li>
                </ol>
              </div>
            </div>
            <h3 class="content-header-title mb-0">Admin Details</h3>
          </div>
          
        </div>
        <div class="content-body"><!-- Zero configuration table -->
        <section id="configuration">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Admin Management</h4>

                        </div>
                        <div class="card-content collapse show">
						<?php 
							if($this->session->flashdata('success_msg')){
								?><p class="alert alert-success"><?php echo $this->session->flashdata('success_msg'); ?></p><?php 
							}
						?>
                            <div class="card-body card-dashboard">
                                <form method="post" action="<?= base_url()?>admin/add_user/<?php echo @$id; ?>">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Email</label>
                                                <input type="email" value="<?php echo @$admindata->admin_email; ?>" name="admin_email" class="form-control">
                                            </div>    
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Username</label>
                                                <input type="text" name="admin_name" value="<?php echo @$admindata->admin_name; ?>" class="form-control">
                                            </div>    
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Password</label>
                                                <input type="password" value="<?php echo @$admindata->password; ?>" name="admin_password" class="form-control">
                                            </div>    
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-froup" style="margin: 35px 0px 0px -15px;">
                                              <input type="checkbox" name="user_type" id="user_type" value="1" <?php if(isset($id) && !empty($id)){ if(@$admindata->user_type==1){ echo 'checked'; } ?><?php }else{ ?>checked <?php } ?>>
                                              <label for="Admin">Admin</label>
                                              <input type="checkbox" name="user_type" id="user_type" <?php if(@$admindata->user_type==2){ echo 'checked'; } ?> value="2">
                                              <label for="User">User</label>
                                            </div>    
                                        </div>
                                        
                                    </div>
                                    <div class="row" style="margin-top:10px">
                                        <div class="col-md-6">
                                            <input type="submit" name="submit" value="Save" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<!--/ Zero configuration table -->

<!--/ Language - Comma decimal place table -->

        </div>
      </div>
    </div>



