<!DOCTYPE html>
<html lang="en">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title>Bookme Admin</title>

    <link rel="icon" type="image/png" href="">

    <!----CKEDITOR ---------------------------------------------------------------->
    <script src="https://cdn.ckeditor.com/4.11.3/standard/ckeditor.js"></script>

    <!---Included in all pages---->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="<?=base_url()?>assets/admin/js/datatables.min.js"></script>
    <!--<script src="<?= base_url() ?>assets/admin/js/datatable-basic.js"></script>-->
    <!----Include in all page must be in header to give datatable functionality---->

    <!---Fonts links--->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i%7COpen+Sans:300,300i,400,400i,600,600i,700,700i" rel="stylesheet">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css" integrity="sha384-UHRtZLI+pbxtHCWp1t77Bi1L4ZtiqrqD80Kn4Z8NTSRyMA2Fd33n5dQ8lWUE00s/" crossorigin="anonymous">

    <!-- BEGIN VENDOR CSS-->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin/css/vendors.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin/css/jquery-jvectormap-2.0.3.css">
    <!-- BEGIN STACK CSS-->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin/css/app.css">
    <!-- END STACK CSS-->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin/css/datatables.min.css">
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin/css/core/vertical-menu.css">
    <!--Wirte your own CSS-->
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin/css/style.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/admin/css/style.min.css">
    <!-- END Custom CSS-->
</head>

<body class="vertical-layout vertical-menu 2-columns   menu-expanded fixed-navbar" data-open="click" data-menu="vertical-menu" data-col="2-columns">
    <!-- fixed-top-->
    <nav class="header-navbar navbar-expand-md navbar navbar-with-menu fixed-top navbar-semi-dark navbar-shadow">
        <div class="navbar-wrapper">
            <div class="navbar-header">
                <ul class="nav navbar-nav flex-row">
                    <li class="nav-item mobile-menu d-md-none mr-auto">
                        <a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu font-large-1"></i>
                     </a>
                    </li>
                    <li class="nav-item"><a class="navbar-brand" href="<?= base_url('') ?>">
                     <img style="width:20%;filter: brightness(0) invert(1);margin: 0 70px;" class="brand-logo" alt="logo" src="<?=base_url()?>assets/admin/images/logo.png">
                     </a>
                    </li>
                    <li class="nav-item d-md-none">
                        <a class="nav-link open-navbar-container" data-toggle="collapse" data-target="#navbar-mobile">
                            <i class="fa fa-ellipsis-v"></i></a>
                    </li>
                </ul>
            </div>
            <div class="navbar-container content">
                <div class="collapse navbar-collapse" id="navbar-mobile">
                    <ul class="nav navbar-nav mr-auto float-left">
                        <li class="nav-item d-none d-md-block"><a class="nav-link nav-menu-main menu-toggle hidden-xs" href="#"><i class="ft-menu"></i></a></li>
                        <li class="nav-item nav-search">
                            <a class="nav-link nav-link-search" href="#"><i class="ficon ft-search"></i></a>
                            <div class="search-input">
                                <input class="input" type="text" placeholder="Explore Your Search...">
                            </div>
                        </li>
                    </ul>
                    <ul class="nav navbar-nav float-right">
                        <li class="dropdown dropdown-user nav-item">
                            <a class="dropdown-toggle nav-link dropdown-user-link" href="#" data-toggle="dropdown">
                                <span class="avatar avatar-online"><img src="<?=base_url()?>assets/admin/images/avatar-s-1.png" alt="avatar"><i></i></span>
                                <span class="user-name"><?php echo($this->session->userdata('adminname'));?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <!--<a class="dropdown-item" href="user-profile.html"><i class="ft-user"></i> Edit Profile</a>-->
                                <!--<div class="dropdown-divider"></div>-->
                                <a class="dropdown-item" href="<?= base_url('logout') ?>"><i class="ft-power"></i>Logout</a>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>
    <div class="main-menu menu-fixed menu-dark menu-accordion menu-shadow" data-scroll-to-active="true">
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
                <li class=" navigation-header"><span>General</span><i class=" ft-minus" data-toggle="tooltip" data-placement="right" data-original-title="General"></i>
                </li>
              <?php if($this->session->userdata('user_type')==1){ ?>
                <li class="<?php echo ($this->uri->segment(1) == 'admin_details' || $this->uri->segment(1) == 'admin_details' )?'active':'' ?>">
                    <a class="has-arrow" href="<?= base_url('admin_details') ?>">
                      <i class="fa fa-user"></i>
                      <span class="mini-click-non">Admin Users</span>
                   </a>
                </li>
			  <?php } ?>
                <li class="<?php echo ( $this->uri->segment(1) == 'insert_category' )?'open active':'' ?>">
                    <a href="javascript:void(0)">
                        <i class="fa fa-list-alt"></i>
                        <span class="menu-title" data-i18n="">Categories</span>
                    </a>
                    <ul class="menu-content">
                        <li class="<?php echo ( $this->uri->segment(1) == 'insert_category' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('insert_category') ?>">Category</a>
                        </li>
                    </ul>
                </li>
                
                <li class="<?php if( $this->uri->segment(1) == 'artist_listing' || $this->uri->segment(1) == 'artist_listing'){ echo 'open active' ; } ?>">
                    <a href="javascript:void(0)">
                        <i class="fa fa-users"></i><span class="menu-title" data-i18n=""> Artist</span>
                    </a>
                    <ul class="menu-content">

                        <li class="<?php echo ( $this->uri->segment(1) == 'artist_listing' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('artist_listing') ?>">Artist Listing</a>
                        </li>
                        
                        <li class="<?php echo ( $this->uri->segment(1) == 'artist_by_rating' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('artist_by_rating') ?>">Artist By Rating</a>
                        </li>
                        
                        <li class="<?php echo ( $this->uri->segment(1) == 'artist_completed_performance' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('artist_completed_performance') ?>">Artist Completed Performance</a>
                        </li>
                        
                        <li class="<?php echo ( $this->uri->segment(1) == 'artist_analysis_report' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('artist_analysis_report') ?>">Artist Analysis</a>
                        </li>
                        
                    </ul>
                </li>
                
                <li class="<?php echo ( $this->uri->segment(1) == 'venue_listing' )?'open active':'' ?>">
                    <a href="javascript:void(0)">
                        <i class="fa fa-users"></i>
                        <span class="menu-title" data-i18n=""> Venue</span>
                    </a>
                    <ul class="menu-content">
                        <li class="<?php echo ( $this->uri->segment(1) == 'venue_listing' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('venue_listing') ?>">Venue Listing</a>
                        </li>
                        
                        <li class="<?php echo ( $this->uri->segment(1) == 'venue_by_rating' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('venue_by_rating') ?>">Venue By Rating</a>
                        </li>
                        
                        <li class="<?php echo ( $this->uri->segment(1) == 'venue_without_booking_listing' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('venue_without_booking_listing') ?>">Venue Without Booking</a>
                        </li>
                        
                        <li class="<?php echo ( $this->uri->segment(1) == 'venue_analysis_report' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('venue_analysis_report') ?>">Venue Analysis Report</a>
                        </li>
                        
                    </ul>
                </li>
                
                <li class="<?php echo ( $this->uri->segment(1) == 'guest_listing' )?'open active':'' ?>">
                    <a href="javascript:void(0)">
                        <i class="fa fa-users"></i><span class="menu-title" data-i18n=""> Guest</span>
                    </a>
                    <ul class="menu-content">

                        <li class="<?php echo ( $this->uri->segment(1) == 'guest_listing' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('guest_listing') ?>">Guest Listing</a>
                        </li>
                        
                    </ul>
                </li>
                
                <li class="<?php echo ( $this->uri->segment(1) == 'booking_listing' || $this->uri->segment(1) == 'venue_problem_with_artist_listing')?'open active':'' ?>">
                    <a href="javascript:void(0)">
                        <i class="fas fa-ticket-alt"></i><span class="menu-title" data-i18n=""> Bookings</span>
                    </a>
                    <ul class="menu-content">

                        <li class="<?php echo ( $this->uri->segment(1) == 'booking_listing' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('booking_listing') ?>">Booking Listing</a>
                        </li>
                        
                        <li class="<?php echo ( $this->uri->segment(1) == 'venue_problem_with_artist_listing' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('venue_problem_with_artist_listing') ?>">Problem With Artist</a>
                        </li>
                        
                        <li class="<?php echo ( $this->uri->segment(1) == 'already_paid_artist_bookings_listing' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('already_paid_artist_bookings_listing') ?>">Artist paid for Bookings</a>
                        </li>
                        
                        <li class="<?php echo ( $this->uri->segment(1) == 'completed_booking_listing' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('completed_booking_listing') ?>">Completed Booking Listing</a>
                        </li>
                        
                        <li class="<?php echo ( $this->uri->segment(1) == 'latest_completed_booking_listing' )?'active':'' ?>">
                            <a class="menu-item" href="<?= base_url('latest_completed_booking_listing') ?>">Latest Completed Booking Listing</a>
                        </li>
                        
                    </ul>
                </li>
                
                <?php 
                    if($this->session->userdata('user_type') == '1'){?>
                        <li class="<?php echo ($this->uri->segment(1) == 'payment_details')?'active':'' ?>">
                            <a class="has-arrow" href="<?= base_url('payment_details') ?>">
                              <i class="fa fa-user"></i>
                              <span class="mini-click-non">Payment Details</span>
                           </a>
                        </li>     
                <?php } ?>
                
                <?php 
                    if($this->session->userdata('user_type') == '1'){?>
                        <li class="<?php echo ($this->uri->segment(1) == 'chat_listing_data')?'active':'' ?>">
                            <a class="has-arrow" href="<?= base_url('chat_listing_data') ?>">
                              <i class="fa fa-comment"></i>
                              <span class="mini-click-non">Chat Listing</span>
                           </a>
                    </li>   
                <?php } ?>
                
            </ul>
        </div>
    </div>