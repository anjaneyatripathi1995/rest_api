<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url('admin/admin_details') ?>">Home</a>
                            </li>
<li class="breadcrumb-item"><a href="<?= base_url('admin/booking_listing') ?>">booking Listing </a>
                            </li>
                            <li class="breadcrumb-item active">booking View 
                            </li>
                        </ol>
                    </div>
                </div>
                <h3 class="content-header-title mb-0">booking View</h3>
            </div>

        </div>
        <div class="content-body">
            <!-- Zero configuration table -->
            <section id="configuration">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">

                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <div class="row">
                                        <!--<div class="col-lg-12">-->
                                        <!--    <button class="btn btn-primary float-right btn-sm mb-3" data-toggle="modal" data-target="#successModal">Add New</button>-->
                                        <!--</div>-->
                                    </div>
									<?php 
									$step=0;
										$status = $booking->status; 
										
										if($status == 5){
											$step=6;
										}else if($status == 6 || $status == 4){
											$step=2;
										}else if($status ==3  ){
											$step=2;
										}
										else if($status == 7 || $status == 9){ //decline 
											$step=6;
										}else if($status ==8  ){
											$step=7;
										}else if($status ==1 || $status ==2 ){
											$step=1;
										}
										if($status !=0 && $status!=1 && $status!=2){
											if($booking->issue_status ==2 ){
												$step=5;
											}else if($booking->issue_status ==1 ){
												$step=4;
											}
										}
										
										
									?>
									<div class="time-line-section">
    <div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
        <section class="cd-horizontal-timeline">
			<div class="timeline">
				<div class="events-wrapper">
					<div class="events">
					
				
						<ul>
							<li><a href="#" data-date="01/01/2005" <?php if($step>=0){ ?>class="selected" <?php } ?>><p>Booking Create</p></a></li>
							<li><a href="#" data-date="01/01/2007" <?php if($step>=1){ ?>class="selected" <?php } ?>><p>Quote send</p></a></li>
							<li><a href="#" data-date="01/01/2011" <?php if($step>=2){ ?>class="selected" <?php } ?>><p>Decline</p></a></li>
							<li><a href="#" data-date="01/01/2012" <?php if($step>=3){ ?>class="selected" <?php } ?>><p>Accept</p></a></li>
							<li><a href="#" data-date="01/01/2013" <?php if($step>=4){ ?>class="selected" <?php } ?>><p>Raise Dispute</p></a></li>
							<li><a href="#" data-date="01/01/2014" <?php if($step>=5){ ?>class="selected" <?php } ?>><p>Solve Dispute</p></a></li>
							<li><a href="#" data-date="01/01/2015" <?php if($step>=6){ ?>class="selected" <?php } ?>><p><?php if($status ==8 || $status==9){ ?> Cancel<?php }else{ ?>Complete <?php } ?></p></a></li>
							<li><a href="#" data-date="01/01/2016" <?php if($step>=7){ ?>class="selected" <?php } ?>><p>Rating Done</p></a></li>
							
						</ul>
						<span class="filling-line" aria-hidden="true"></span>
					</div> 
				</div> 
			</div>
		</section>
        
        </div>
        
        </div>
    </div>
    </div>
	
									
                                   <div class="row">
									<div class="col-sm-12"><strong>Booking Details </strong></div>
								   </div>
                                    <table class="table table-striped table-bordered zero-configuration" width="100%">
                                        <thead>
                                            <tr><td>Booking ID</td><td><?php echo $booking->booking_id;?></td></tr>
                                            <tr><td>Artist Name</td><td><?php if($booking->artist_id != ''){
																		  echo $this->Adminmodel->getFieldWhere('artist_name','tbl_artist','id',$booking->artist_id);
																		}?></td></tr>
											<tr><td>Venue Name</td><td><?php  if($booking->venue_id != ''){
           echo $this->Adminmodel->getFieldWhere('venue_name','tbl_venue','id',$booking->venue_id);
        } ?></td></tr>
		 <tr><td>Guest Name</td><td><?php if($booking->guest_id != ''){
            echo  $this->Adminmodel->getFieldWhere('username','tbl_guest','id',$booking->guest_id);
        }?></td></tr>
		<tr><td>Category</td><td><?php echo $booking->category;?></td></tr>
		<tr><td>Room Name</td><td><?php echo $booking->room_name;?></td></tr>
		<tr><td>Description</td><td><?php echo $booking->description;?></td></tr>
		<tr><td>Equipment</td><td><?php echo $booking->equipment;?></td></tr>
		<tr><td>Address </td><td><?php echo $booking->address;?></td></tr>
		<tr><td>Building No </td><td><?php echo $booking->building_number;?></td></tr>
		<tr><td>Street Address  </td><td><?php echo $booking->street_address;?></td></tr>
		<tr><td>Town  </td><td><?php echo $booking->town;?></td></tr>
		<tr><td>City  </td><td><?php echo $booking->city;?></td></tr>
		<tr><td>Postal Code  </td><td><?php echo $booking->post_code;?></td></tr>
		<tr><td>Quote Price  </td><td><?php echo $booking->quote_price;?></td></tr>
		<tr><td>Issue Status </td><td><?php if($booking->issue_status==1){ echo 'Issue Persist'; }else{ echo 'Issue Resolved '; } ?></td></tr>
		<tr><td>Artist Paid Status</td><td><?php if($booking->artist_paid_status==1){ echo 'Paid';}else{ echo 'Not Paid';}?></td></tr>
		<tr><td>Resion of cancel </td><td><?php echo $booking->reason_of_cancel;?></td></tr>
		<tr><td>Issue with artist </td><td><?php echo $booking->issue_with_artist;?></td></tr>
		<tr><td>Resolution  </td><td><?php echo $booking->resolution_action_text;?></td></tr>
		<tr><td>Transation ID  </td><td><?php echo $booking->transaction_id;?></td></tr>
		<tr><td>Payment Method  </td><td><?php echo $booking->payment_method;?></td></tr>
		<tr><td>Transation Date   </td><td><?php echo $booking->transaction_date;?></td></tr>
		<tr><td>Performance Date</td><td><?php echo $booking->booking_date;?></td></tr>
		<tr><td>Start Time</td><td><?php echo $booking->start_time;?></td></tr>
		<tr><td>End Time</td><td><?php echo $booking->end_time;?></td></tr>
		<tr><td>Added Date</td><td><?php echo date('d-M-Y, h:i:s A', strtotime($booking->c_date)); ?></td></tr>
                                        </thead>
                                        <tbody>

                                        </tbody>

                                    </table>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--/ Zero configuration table -->

            <!--/ Language - Comma decimal place table -->

        </div>
    </div>
</div>

 <!--<div class="modal fade" id="successModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">-->
 <!--       <div class="modal-dialog modal-success" role="document">-->
 <!--           <div class="modal-content">-->
 <!--               <div class="modal-header">-->
 <!--                   <h4 class="modal-title" id="modal-title">Add New Data</h4>-->
 <!--                   <button type="button" class="close" data-dismiss="modal" aria-label="Close">-->
 <!--                       <span aria-hidden="true">×</span>-->
 <!--                   </button>-->
 <!--               </div>-->
 <!--               <div class="card-body">-->
 <!--                   <form method="post" id="type_of_listing_frm" enctype="multipart/form-data">-->
                        
 <!--                       <div class="form-group">-->
 <!--                           <label for="name">booking Name</label>-->
 <!--                           <input type="text" id="booking_name" name="booking_name" class="form-control">-->
 <!--                       </div>-->
                        

 <!--                       <input type="hidden" name="taction" id="action" value="">-->
 <!--                       <input type="hidden" name="id" id="id" value="">-->
 <!--                      <button type="submit" class="btn btn-success" id="type_of_listing_btn">Submit</button>-->
 <!--                      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
                       
 <!--                   </form>-->
    
 <!--               </div>-->
 <!--           </div>-->
 <!--       </div>-->
 <!--   </div>-->




<script type="text/javascript">
    
	var dataTable = $('#bookingTable').DataTable({  
		"processing":true,
		"responsive": true,
		"language": {
			processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> '
		},
		dom: 'Blftip',
        select: true,
        buttons: [
         
        {extend: 'excel',
        footer: 'true',
        text: 'Excel', },
         
        {extend: 'pdf',
        footer: 'true',
        text: 'pdf',
        orientation: 'landscape', },
         
        'print',
             
        {extend: 'excel',
        text: 'Selected Excel',
        footer: 'true',
        exportOptions: {
        modifier: {
        selected: true
                }
            }
        },
        {
        extend: 'pdf',
        footer: 'true',
        orientation: 'landscape',
        text: 'Selected PDF',
        exportOptions: {
        modifier: {
        selected: true
                        }
                    }
                }
        ],
		"serverSide":true,
		"order":[],  
		"ajax":{  
			url:"<?php echo base_url('admin/fetch_all_booking'); ?>",  
			type:"POST"  
		},
		"lengthMenu": [[10, 25, 50, -1], [10, 25, 50, "All"]],
		 
		"columnDefs":[  
		{  
			"targets":[0,1,2,3,4,5,6,7],  
			"orderable":false,  
		},  
		],  
	});



	$(document).on('click', '.hide_booking_listing', function(){  
		var id = $(this).attr("mainid");  
		if(confirm("Are you sure you want to hide this?")){  
			$.ajax({  
				url:"<?php echo base_url(); ?>admin/hide_booking_listing",  
				method:"POST",  
				data:{id:id, status:'2'},
				dataType:"json",   
				success:function(data){  
					if(data['error']){
						alert(data.error);
					}else{
						alert(data.success);
					}  
					dataTable.ajax.reload();      
				}  
			});  
		} else {  
			return false;       
		}  
	});

	$(document).on('click', '.activate_booking_listing', function(){  
		var id = $(this).attr("mainid");  
		if(confirm("Are you sure you Activate this?")){  
			$.ajax({  
				url:"<?php echo base_url(); ?>admin/unhide_booking_listing",  
				method:"POST",  
				data:{id:id, status:'1'},
				dataType:"json",   
				success:function(data){  
					if(data['error']){
						alert(data.error);
					}else{
						alert(data.success);
					}  
					dataTable.ajax.reload();      
				}  
			});  
		} else {  
			return false;       
		}  
	});
	
	$(document).on('click','.delete_booking_listing',function(event){
	    event.preventDefault();
	    var id= $(this).attr("mainid");
	    if(confirm("Are you sure you Delete this?")){
	        $.ajax({
	            url:"<?php echo base_url(); ?>admin/delete_booking_listing",
	            method: "POST",
	            data:{id:id},
	            dataType:"json",
	            success:function(data){  
					if(data['error']){
						alert(data.error);
					}else{
						alert(data.success);
					}  
					dataTable.ajax.reload();  
				} 
	        });
	    }
	    else {  
			return false;       
		}
	});
	
   //INSERT NEW DATA
   $(document).on('submit', '#type_of_listing_frm', function(event) {
        event.preventDefault();
        var booking_name = $('#booking_name').val().trim();
        if (booking_name != '') {
            $.ajax({
                url: "<?php echo base_url() .'admin/insert_booking_listing_data'?>",
                method: 'POST',
                data: new FormData(this),
                contentType: false,
                processData: false,
                dataType: 'JSON',
                beforeSend: function() {
                    $("#type_of_listing_btn").html('Please Wait...');
                    $('input[type=text],button[type=submit]', 'textarea').prop('disabled', true);
                },
                success: function(data) {
                    $("#type_of_listing_btn").html('Submit');
                    $('input[type=text],button[type=submit]', 'textarea').prop('disabled', false);
                    if (data['error']) {
                        alert(data.error);
                    } else {
                        $('#type_of_listing_frm')[0].reset();
                        alert(data.success);
                        $('#successModal').modal('hide');
                        dataTable.ajax.reload();
                    }
                }
            });
            
        } else {
                 alert('Fields are Required');
        }
    });
    
        //EDIT DATA
      $(document).on('click', '.edit_booking_listing', function(){  
         var id= $(this).attr("mainid");
         $(".modal-title").html("Update Details"); 
            $.ajax({
              url:"<?php echo base_url(); ?>admin/fetch_single_booking_listing",  
              method:"POST",  
              data:{id:id,taction:'update_product'},  
              dataType:"json",  
              success:function(data) { 
                $('#successModal').modal('show');
                $('#booking_name').val(data.booking_name);
                $('#id').val(id);
                $('#action').val('update_product');
              }  
            })  
          });
</script>

<style>





.section-2 .col-md-3{
  border:1px solid #ddd;
  padding: 10px 20px;
}
.section-2 .col-md-9{
  border:1px solid #ddd;
  padding: 10px 20px;
  border-left: none;
}







.cd-horizontal-timeline .timeline {
  position: relative;
  height: 100px;
  width: 90%;
  max-width: 1000px;
  margin: 0 auto;
}
.cd-horizontal-timeline .events-wrapper {
  position: relative;
  height: 100%;


}
.section-2{
    margin: 100px 0px;
}
.time-line-section{
    margin: 100px 0px;
}
.cd-horizontal-timeline .events {

  position: absolute;
  z-index: 1;
  left: 0;

  height: 7px;
  
  background: #dfdfdf;
  -webkit-transition: -webkit-transform 0.4s;
  -moz-transition: -moz-transform 0.4s;
  transition: transform 0.4s;
    
}
.cd-horizontal-timeline .filling-line {
  
  position: absolute;
  z-index: 1;
  left: 0;
  top: 0;
  height: 100%;
  width: 100%;
  background-color: #fd8204;
  -webkit-transform: scaleX(0);
  -moz-transform: scaleX(0);
  -ms-transform: scaleX(0);
  -o-transform: scaleX(0);
  transform: scaleX(0);
  -webkit-transform-origin: left center;
  -moz-transform-origin: left center;
  -ms-transform-origin: left center;
  -o-transform-origin: left center;
  transform-origin: left center;
  -webkit-transition: -webkit-transform 0.3s;
  -moz-transition: -moz-transform 0.3s;
  transition: transform 0.3s;
    
}
.cd-horizontal-timeline .events a {
  position: absolute;
  bottom: 0;
  z-index: 2;
  text-align: center;
  font-size: 1.3rem;
  padding-bottom: 15px; 
  color: #383838;
  /* fix bug on Safari - text flickering while timeline translates */
  -webkit-transform: translateZ(0);
  -moz-transform: translateZ(0);
  -ms-transform: translateZ(0);
  -o-transform: translateZ(0);
  transform: translateZ(0);
    left:360px;
}
.cd-horizontal-timeline .events a::after {
  /* this is used to create the event spot */
  content: '';
  position: absolute;
  left: 50%;
  right: auto;
  -webkit-transform: translateX(-50%);
  -moz-transform: translateX(-50%);
  -ms-transform: translateX(-50%);
  -o-transform: translateX(-50%);
  transform: translateX(-50%);
  bottom: -18px;
  height: 40px;
  width: 40px;
  
  border: 2px solid #fd8204;
  background-color: #f8f8f8;
  -webkit-transition: background-color 0.3s, border-color 0.3s;
  -moz-transition: background-color 0.3s, border-color 0.3s;
  transition: background-color 0.3s, border-color 0.3s;
}
.no-touch .cd-horizontal-timeline .events a:hover::after {
  background-color: #085796;
  border-color: #085796;
}
.cd-horizontal-timeline .events a.selected {
  pointer-events: none;
}
.cd-horizontal-timeline .events a.selected::after {
  background-color: orange;
  border-color: orange;
}



.cd-timeline-navigation a:hover {
  border: 2px solid #005695;
  color: #005695;
}


.events ul li{
    list-style: none;
}
.events ul li p{
         position: absolute;
    transform: rotate(-57deg);
    
    margin-left: -60px;
    margin-top: 60px;
}













</style>
<script>
jQuery(document).ready(function($){
	var timelines = $('.cd-horizontal-timeline'),
		eventsMinDistance = 60;

	(timelines.length > 0) && initTimeline(timelines);

	function initTimeline(timelines) {
		timelines.each(function(){
			var timeline = $(this),
				timelineComponents = {};
			//cache timeline components 
			timelineComponents['timelineWrapper'] = timeline.find('.events-wrapper');
			timelineComponents['eventsWrapper'] = timelineComponents['timelineWrapper'].children('.events');
			timelineComponents['fillingLine'] = timelineComponents['eventsWrapper'].children('.filling-line');
			timelineComponents['timelineEvents'] = timelineComponents['eventsWrapper'].find('a');
			timelineComponents['timelineDates'] = parseDate(timelineComponents['timelineEvents']);
			timelineComponents['eventsMinLapse'] = minLapse(timelineComponents['timelineDates']);
			timelineComponents['timelineNavigation'] = timeline.find('.cd-timeline-navigation');
			timelineComponents['eventsContent'] = timeline.children('.events-content');

			//assign a left postion to the single events along the timeline
			setDatePosition(timelineComponents, eventsMinDistance);
			//assign a width to the timeline
			var timelineTotWidth = setTimelineWidth(timelineComponents, eventsMinDistance);
			//the timeline has been initialize - show it
			timeline.addClass('loaded');

			//detect click on the next arrow
			timelineComponents['timelineNavigation'].on('click', '.next', function(event){
				event.preventDefault();
				updateSlide(timelineComponents, timelineTotWidth, 'next');
			});
			//detect click on the prev arrow
			timelineComponents['timelineNavigation'].on('click', '.prev', function(event){
				event.preventDefault();
				updateSlide(timelineComponents, timelineTotWidth, 'prev');
			});
			//detect click on the a single event - show new event content
			/*timelineComponents['eventsWrapper'].on('click', 'a', function(event){ 
				event.preventDefault();
				timelineComponents['timelineEvents'].removeClass('selected');
				$(this).addClass('selected');
				updateOlderEvents($(this));
				updateFilling($(this), timelineComponents['fillingLine'], timelineTotWidth);
				updateVisibleContent($(this), timelineComponents['eventsContent']);
			});*/

			//on swipe, show next/prev event content
			timelineComponents['eventsContent'].on('swipeleft', function(){
				var mq = checkMQ();
				( mq == 'mobile' ) && showNewContent(timelineComponents, timelineTotWidth, 'next');
			});
			timelineComponents['eventsContent'].on('swiperight', function(){
				var mq = checkMQ();
				( mq == 'mobile' ) && showNewContent(timelineComponents, timelineTotWidth, 'prev');
			});

			//keyboard navigation
			$(document).keyup(function(event){
				if(event.which=='37' && elementInViewport(timeline.get(0)) ) {
					showNewContent(timelineComponents, timelineTotWidth, 'prev');
				} else if( event.which=='39' && elementInViewport(timeline.get(0))) {
					showNewContent(timelineComponents, timelineTotWidth, 'next');
				}
			});
		});
	}

	function updateSlide(timelineComponents, timelineTotWidth, string) {
		//retrieve translateX value of timelineComponents['eventsWrapper']
		var translateValue = getTranslateValue(timelineComponents['eventsWrapper']),
			wrapperWidth = Number(timelineComponents['timelineWrapper'].css('width').replace('px', ''));
		//translate the timeline to the left('next')/right('prev') 
		(string == 'next') 
			? translateTimeline(timelineComponents, translateValue - wrapperWidth + eventsMinDistance, wrapperWidth - timelineTotWidth)
			: translateTimeline(timelineComponents, translateValue + wrapperWidth - eventsMinDistance);
	}

	function showNewContent(timelineComponents, timelineTotWidth, string) {
		//go from one event to the next/previous one
		var visibleContent =  timelineComponents['eventsContent'].find('.selected'),
			newContent = ( string == 'next' ) ? visibleContent.next() : visibleContent.prev();

		if ( newContent.length > 0 ) { //if there's a next/prev event - show it
			var selectedDate = timelineComponents['eventsWrapper'].find('.selected'),
				newEvent = ( string == 'next' ) ? selectedDate.parent('li').next('li').children('a') : selectedDate.parent('li').prev('li').children('a');
			
			updateFilling(newEvent, timelineComponents['fillingLine'], timelineTotWidth);
			updateVisibleContent(newEvent, timelineComponents['eventsContent']);
			newEvent.addClass('selected');
			selectedDate.removeClass('selected');
			updateOlderEvents(newEvent);
			updateTimelinePosition(string, newEvent, timelineComponents, timelineTotWidth);
		}
	}

	function updateTimelinePosition(string, event, timelineComponents, timelineTotWidth) {
		//translate timeline to the left/right according to the position of the selected event
		var eventStyle = window.getComputedStyle(event.get(0), null),
			eventLeft = Number(eventStyle.getPropertyValue("left").replace('px', '')),
			timelineWidth = Number(timelineComponents['timelineWrapper'].css('width').replace('px', '')),
			timelineTotWidth = Number(timelineComponents['eventsWrapper'].css('width').replace('px', ''));
		var timelineTranslate = getTranslateValue(timelineComponents['eventsWrapper']);

        if( (string == 'next' && eventLeft > timelineWidth - timelineTranslate) || (string == 'prev' && eventLeft < - timelineTranslate) ) {
        	translateTimeline(timelineComponents, - eventLeft + timelineWidth/2, timelineWidth - timelineTotWidth);
        }
	}

	function translateTimeline(timelineComponents, value, totWidth) {
		var eventsWrapper = timelineComponents['eventsWrapper'].get(0);
		value = (value > 0) ? 0 : value; //only negative translate value
		value = ( !(typeof totWidth === 'undefined') &&  value < totWidth ) ? totWidth : value; //do not translate more than timeline width
		setTransformValue(eventsWrapper, 'translateX', value+'px');
		//update navigation arrows visibility
		(value == 0 ) ? timelineComponents['timelineNavigation'].find('.prev').addClass('inactive') : timelineComponents['timelineNavigation'].find('.prev').removeClass('inactive');
		(value == totWidth ) ? timelineComponents['timelineNavigation'].find('.next').addClass('inactive') : timelineComponents['timelineNavigation'].find('.next').removeClass('inactive');
	}

	function updateFilling(selectedEvent, filling, totWidth) {
		//change .filling-line length according to the selected event
		var eventStyle = window.getComputedStyle(selectedEvent.get(0), null),
			eventLeft = eventStyle.getPropertyValue("left"),
			eventWidth = eventStyle.getPropertyValue("width");
		eventLeft = Number(eventLeft.replace('px', '')) + Number(eventWidth.replace('px', ''))/2;
		var scaleValue = eventLeft/totWidth;
		setTransformValue(filling.get(0), 'scaleX', scaleValue);
	}

	function setDatePosition(timelineComponents, min) {
		for (i = 0; i < timelineComponents['timelineDates'].length; i++) { 
		    var distance = daydiff(timelineComponents['timelineDates'][0], timelineComponents['timelineDates'][i]),
		    	distanceNorm = Math.round(distance/timelineComponents['eventsMinLapse']) + 2;
		    timelineComponents['timelineEvents'].eq(i).css('left', distanceNorm*min+'px');
		}
	}

	function setTimelineWidth(timelineComponents, width) {
		var timeSpan = daydiff(timelineComponents['timelineDates'][0], timelineComponents['timelineDates'][timelineComponents['timelineDates'].length-1]),
			timeSpanNorm = timeSpan/timelineComponents['eventsMinLapse'],
			timeSpanNorm = Math.round(timeSpanNorm) + 4,
			totalWidth = timeSpanNorm*width;
		timelineComponents['eventsWrapper'].css('width', totalWidth+'px');
		updateFilling(timelineComponents['timelineEvents'].eq(0), timelineComponents['fillingLine'], totalWidth);
	
		return totalWidth;
	}

	function updateVisibleContent(event, eventsContent) {
		var eventDate = event.data('date'),
			visibleContent = eventsContent.find('.selected'),
			selectedContent = eventsContent.find('[data-date="'+ eventDate +'"]'),
			selectedContentHeight = selectedContent.height();

		if (selectedContent.index() > visibleContent.index()) {
			var classEnetering = 'selected enter-right',
				classLeaving = 'leave-left';
		} else {
			var classEnetering = 'selected enter-left',
				classLeaving = 'leave-right';
		}

		selectedContent.attr('class', classEnetering);
		visibleContent.attr('class', classLeaving).one('webkitAnimationEnd oanimationend msAnimationEnd animationend', function(){
			visibleContent.removeClass('leave-right leave-left');
			selectedContent.removeClass('enter-left enter-right');
		});
		eventsContent.css('height', selectedContentHeight+'px');
	}

	function updateOlderEvents(event) {
		event.parent('li').prevAll('li').children('a').addClass('older-event').end().end().nextAll('li').children('a').removeClass('older-event');
	}

	function getTranslateValue(timeline) {
		var timelineStyle = window.getComputedStyle(timeline.get(0), null),
			timelineTranslate = timelineStyle.getPropertyValue("-webkit-transform") ||
         		timelineStyle.getPropertyValue("-moz-transform") ||
         		timelineStyle.getPropertyValue("-ms-transform") ||
         		timelineStyle.getPropertyValue("-o-transform") ||
         		timelineStyle.getPropertyValue("transform");

        if( timelineTranslate.indexOf('(') >=0 ) {
        	var timelineTranslate = timelineTranslate.split('(')[1];
    		timelineTranslate = timelineTranslate.split(')')[0];
    		timelineTranslate = timelineTranslate.split(',');
    		var translateValue = timelineTranslate[4];
        } else {
        	var translateValue = 0;
        }

        return Number(translateValue);
	}

	function setTransformValue(element, property, value) {
		element.style["-webkit-transform"] = property+"("+value+")";
		element.style["-moz-transform"] = property+"("+value+")";
		element.style["-ms-transform"] = property+"("+value+")";
		element.style["-o-transform"] = property+"("+value+")";
		element.style["transform"] = property+"("+value+")";
	}

	//based on http://stackoverflow.com/questions/542938/how-do-i-get-the-number-of-days-between-two-dates-in-javascript
	function parseDate(events) {
		var dateArrays = [];
		events.each(function(){
			var dateComp = $(this).data('date').split('/'),
				newDate = new Date(dateComp[2], dateComp[1]-1, dateComp[0]);
			dateArrays.push(newDate);
		});
	    return dateArrays;
	}

	function parseDate2(events) {
		var dateArrays = [];
		events.each(function(){
			var singleDate = $(this),
				dateComp = singleDate.data('date').split('T');
			if( dateComp.length > 1 ) { //both DD/MM/YEAR and time are provided
				var dayComp = dateComp[0].split('/'),
					timeComp = dateComp[1].split(':');
			} else if( dateComp[0].indexOf(':') >=0 ) { //only time is provide
				var dayComp = ["2000", "0", "0"],
					timeComp = dateComp[0].split(':');
			} else { //only DD/MM/YEAR
				var dayComp = dateComp[0].split('/'),
					timeComp = ["0", "0"];
			}
			var	newDate = new Date(dayComp[2], dayComp[1]-1, dayComp[0], timeComp[0], timeComp[1]);
			dateArrays.push(newDate);
		});
	    return dateArrays;
	}

	function daydiff(first, second) {
	    return Math.round((second-first));
	}

	function minLapse(dates) {
		//determine the minimum distance among events
		var dateDistances = [];
		for (i = 1; i < dates.length; i++) { 
		    var distance = daydiff(dates[i-1], dates[i]);
		    dateDistances.push(distance);
		}
		return Math.min.apply(null, dateDistances);
	}

	/*
		How to tell if a DOM element is visible in the current viewport?
		http://stackoverflow.com/questions/123999/how-to-tell-if-a-dom-element-is-visible-in-the-current-viewport
	*/
	function elementInViewport(el) { 
		var top = el.offsetTop;
		var left = el.offsetLeft;
		var width = el.offsetWidth;
		var height = el.offsetHeight;

		while(el.offsetParent) {
		    el = el.offsetParent;
		    top += el.offsetTop;
		    left += el.offsetLeft;
		}

		return (
		    top < (window.pageYOffset + window.innerHeight) &&
		    left < (window.pageXOffset + window.innerWidth) &&
		    (top + height) > window.pageYOffset &&
		    (left + width) > window.pageXOffset
		);
	}

	function checkMQ() {
		//check if mobile or desktop device
		return window.getComputedStyle(document.querySelector('.cd-horizontal-timeline'), '::before').getPropertyValue('content').replace(/'/g, "").replace(/"/g, "");
	}
});
</script>