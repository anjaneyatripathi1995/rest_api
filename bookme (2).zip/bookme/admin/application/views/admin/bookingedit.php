<style>
    #user_type{
        margin: 6px 0px 0px 20px;
    }
</style>
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2">
            <div class="row breadcrumbs-top">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
					<?php if(empty($repage)){
						?><a href="<?= base_url('admin/booking_listing') ?>">Home</a><?php 
					}else{
					?><a href="<?= base_url($repage) ?>">Home</a><?php 	
					}
				  ?>
                  </li>
                  <li class="breadcrumb-item active">Edit Booking
                  </li>
                </ol>
              </div>
            </div>
            <h3 class="content-header-title mb-0">Edit Booking</h3>
          </div>
          
        </div>
        <div class="content-body"><!-- Zero configuration table -->
        <section id="configuration">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Edit Booking</h4>

                        </div>
                        <div class="card-content collapse show">
						
						<?php 
							if($this->session->flashdata('success_msg')){
								?><div class="col-sm-12"><p class="alert alert-success"><?php echo $this->session->flashdata('success_msg'); ?></p></div><?php 
							}
							if($this->session->flashdata('error_msg')){
								?><div class="col-sm-12"><p class="alert alert-danger"><?php echo $this->session->flashdata('error_msg'); ?></p></div><?php 
							}
						?>
                            <div class="card-body card-dashboard">
                                <form method="post" action="<?= base_url()?>admin/editbooking/<?php echo @$id; ?>/<?php echo @$repage; ?>">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Artist </label>
												<select class="form-control" name="artist_id">
													<option value="">Select Artist </option>
													<?php $all = $this->db->get('tbl_artist'); 
													if($all->num_rows()>0){
														foreach($all->result() as $key=>$val){
															?><option <?php if($val->id==@$admindata->artist_id){ ?>selected<?php } ?> value="<?php echo $val->id; ?>"><?php echo $val->user_name; ?></option><?php 
														}
													}
													?>
												</select>
                                            </div>    
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Venue </label>
                                                <select class="form-control" name="venue_id">
													<option disabled selected>Select Venue </option>
													<?php $all = $this->db->get('tbl_venue'); 
													if($all->num_rows()>0){
														foreach($all->result() as $key=>$val){
															?><option <?php if($val->id==@$admindata->venue_id){ ?>selected<?php } ?> value="<?php echo $val->id; ?>"><?php echo $val->venue_name.'('.$val->username.')'; ?></option><?php 
														}
													}
													?>
												</select>
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Guest</label>
                                                <select class="form-control" name="guest_id">
													<option value="">Select Guest </option>
													<?php $all = $this->db->get('tbl_guest'); 
													if($all->num_rows()>0){
														foreach($all->result() as $key=>$val){
															?><option <?php if($val->id==@$admindata->guest_id){ ?>selected<?php } ?> value="<?php echo $val->id; ?>"><?php echo $val->username; ?></option><?php 
														}
													}
													?>
												</select>
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Room Name</label>
                                                <select class="form-control" name="room_id">
													<option value="">Select Room </option>
													<?php $all = $this->db->get('tbl_room_detailing'); 
													if($all->num_rows()>0){
														foreach($all->result() as $key=>$val){
															?><option <?php if($val->id==@$admindata->room_id){ ?>selected<?php } ?> value="<?php echo $val->id; ?>"><?php echo $val->room_name.'(ID'.$val->id.')'; ?></option><?php 
														}
													}
													?>
												</select>
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Category </label>
                                                <input type="text" value="<?php echo @$admindata->category; ?>" name="category" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Booking Date </label>
                                                <input type="text" value="<?php echo @$admindata->booking_date; ?>" name="booking_date" id="booking_date" placeholder="Booking Date" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Description </label>
                                                <input type="text" value="<?php echo @$admindata->description; ?>" name="description" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Equipment </label>
                                                <input type="text" value="<?php echo @$admindata->equipment; ?>" name="equipment" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Address </label>
                                                <input type="text" value="<?php echo @$admindata->address; ?>" name="address" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Building No </label>
                                                <input type="text" value="<?php echo @$admindata->building_number; ?>" name="building_number" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Street Address  </label>
                                                <input type="number" value="<?php echo @$admindata->street_address; ?>" name="street_address" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Town </label>
                                                <input type="text" value="<?php echo @$admindata->town; ?>" name="town" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>City </label>
                                                <input type="text" value="<?php echo @$admindata->city; ?>" name="city" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Postal Code </label>
                                                 <input type="text" value="<?php echo @$admindata->post_code; ?>" name="post_code" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Start Time  </label>
                                                <input type="number" value="<?php echo @$admindata->start_time; ?>" name="start_time" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>End Time </label>
                                                <input type="text" value="<?php echo @$admindata->end_time; ?>" name="end_time" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Quote Price</label>
                                                <input type="text" value="<?php echo @$admindata->quote_price; ?>" name="quote_price" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Status </label>
                                                <select class="form-control" name="status">
													<option <?php if(@$admindata->status==0){?>selected="selected"<?php } ?> value="0">Booking Place  </option>
													<option <?php if(@$admindata->status==1){?>selected="selected"<?php } ?> value="1">Quote Send  </option>
													<option <?php if(@$admindata->status==2){?>selected="selected"<?php } ?> value="2">Counter Offer   </option>
													<option <?php if(@$admindata->status==3){?>selected="selected"<?php } ?> value="3">Accept   </option>
													<option <?php if(@$admindata->status==4){?>selected="selected"<?php } ?> value="4">Decline   </option>
													<option <?php if(@$admindata->status==5){?>selected="selected"<?php } ?> value="5">Complete   </option>
													<option <?php if(@$admindata->status==6){?>selected="selected"<?php } ?> value="6">Payment Done   </option>
													<option <?php if(@$admindata->status==7){?>selected="selected"<?php } ?> value="7">Booking Cancel by artist </option>
													<option <?php if(@$admindata->status==8){?>selected="selected"<?php } ?> value="8">Rating Done </option>
													<option <?php if(@$admindata->status==9){?>selected="selected"<?php } ?> value="9">Booking cancel by guest/venue </option>
												</select>
                                            </div>    
                                        </div>
										
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Issue Status </label>
                                                <select class="form-control" name="issue_status">
													<option  value="0">Select issue status </option>
													<option <?php if(@$admindata->issue_status==1){?>selected="selected"<?php } ?> value="1">Issue Persist  </option>
													<option <?php if(@$admindata->issue_status==2){?>selected="selected"<?php } ?> value="2">Issue Resolved   </option>
												</select>
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Artist Paid  </label>
                                                <select class="form-control" name="artist_paid_status">
													<option  value="0">Select artist paid  </option>
													<option <?php if(@$admindata->artist_paid_status==1){?>selected="selected"<?php } ?> value="1">Paid Artist  </option>
												</select>
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Resion of cancel  </label>
                                                <input type="text" value="<?php echo @$admindata->reason_of_cancel; ?>" name="reason_of_cancel" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Issue with artist   </label>
                                                <input type="text" value="<?php echo @$admindata->issue_with_artist; ?>" name="issue_with_artist" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Resolution action text  </label>
                                                <input type="text" value="<?php echo @$admindata->resolution_action_text; ?>" name="resolution_action_text" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Payment method </label>
                                                <input type="text" value="<?php echo @$admindata->payment_method; ?>" name="payment_method" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Transation Date </label>
                                                <input type="text" value="<?php echo @$admindata->transaction_date; ?>" name="transaction_date" id="transaction_date" class="form-control">
                                            </div>    
                                        </div>
										<input type="hidden" value="<?php echo @$admindata->booking_id; ?>" name="booking_id">
                                    </div>
                                    <div class="row" style="margin-top:10px">
                                        <div class="col-md-6">
                                            <input type="submit" name="submit" value="Save" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<!--/ Zero configuration table -->

<!--/ Language - Comma decimal place table -->

        </div>
      </div>
    </div>



