<style>
    .media .media-body span{
    line-height: 40px;
    font-size: 16PX;
    font-weight: 600;
}
</style>
<!--<script type="text/javascript" src="js/jquery.min.js"></script>-->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.3/Chart.min.js"></script>
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a>
                            </li>

                            <li class="breadcrumb-item active">Dashboard Analytics
                            </li>
                        </ol>
                    </div>
                </div>
                <h3 class="content-header-title mb-0">Analytics</h3>
            </div>

        </div>
        <div class="content-body">
            <!--stats-->
            <div class="row">
                <div class="col-xl-3 col-lg-6 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body text-left w-100">
                                        <h2 class="success">
                                            <?php
                                            $width = 0;
                                                if(!empty($fetch_analytics_data)){
                                                    echo $fetch_analytics_data['category'];
                                                    $width = ($fetch_analytics_data['category']/200)*100;
                                                }
                                                
                                            ?>
                                            
                                        </h2>
                                        <span>TOTAL CATEGORIES</span>
                                    </div>
                                    <div class="media-right media-middle">
                                        <i class="icon-social-dropbox danger font-large-2 float-right"></i>
                                    </div>
                                </div>
                                <div class="progress progress-sm mt-1 mb-0">
                                    <div class="progress-bar bg-danger" role="progressbar" style="width: <?= $width ?>%" aria-valuenow="<?= $width ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body text-left w-100">
                                        <h2 class="success">
                                            
                                            <?php
                                            $width = 0;
                                                if(!empty($fetch_analytics_data)){
                                                    echo $fetch_analytics_data['artist'];
                                                    $width = ($fetch_analytics_data['artist']/200)*100;
                                                }
                                            ?>
                                            
                                        </h2>
                                        <span>TOTAL ARTIST</span>
                                    </div>
                                    <div class="media-right media-middle">
                                        <i class="icon-user-follow danger font-large-2 float-right"></i>
                                    </div>
                                </div>
                                <div class="progress progress-sm mt-1 mb-0">
                                    <div class="progress-bar bg-danger" role="progressbar" style="width: <?= $width ?>%" aria-valuenow="<?= $width ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body text-left w-100">
                                        <h2 class="success">
                                            
                                            <?php
                                            $width = 0;
                                                if(!empty($fetch_analytics_data)){
                                                    echo $fetch_analytics_data['venue'];
                                                    $width = ($fetch_analytics_data['venue']/200)*100;
                                                }
                                            ?>
                                            
                                        </h2>
                                        <span>TOTAL VENUE</span>
                                    </div>
                                    <div class="media-right media-middle">
                                        <i class="icon-user-follow danger font-large-2 float-right"></i>
                                    </div>
                                </div>
                                <div class="progress progress-sm mt-1 mb-0">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: <?= $width ?>%" aria-valuenow="<?= $width ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-6 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body text-left w-100">
                                        <h2 class="success">
                                            <?php
                                            $width = 0;
                                                if(!empty($fetch_analytics_data)){
                                                    echo $fetch_analytics_data['guest'];
                                                    $width = ($fetch_analytics_data['guest']/200)*100;
                                                }
                                            ?>
                                            
                                        </h2>
                                        <span>TOTAL GUEST</span>
                                    </div>
                                    <div class="media-right media-middle">
                                        <i class="icon-user-follow danger font-large-2 float-right"></i>
                                    </div>
                                </div>
                                <div class="progress progress-sm mt-1 mb-0">
                                    <div class="progress-bar bg-warning" role="progressbar" style="width: <?= $width ?>%" aria-valuenow="<?= $width ?>" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-lg-3 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body text-left w-100">
                                        <h2 class="success">
                                        <?php
                                            if(!empty($fetch_today_earning)){
                                                if($fetch_today_earning->total == ''){
                                                  echo '0';
                                                }
                                                else{
                                                 echo $fetch_today_earning->total;
                                                }
                                            }
                                        ?>
                                            
                                        </h2>
                                        <span>Business Generation Today</span>
                                    </div>
                                    <div class="media-right media-middle">
                                        <i class="fa fa-chart-bar danger font-large-2 float-right"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body text-left w-100">
                                        <h2 class="success">
                                        <?php
										 $today_date = date('Y-m-d');
										  $this->db->SELECT("sum(quote_price) as total ");  
										  $this->db->FROM('tbl_booking'); 
										  $this->db->WHERE("transaction_id != 'NULL'");
										 $this->db->where('(Month(transaction_date)="'.$today_date.'")');
										  $query = $this->db->get();
										  if ($query->num_rows() > 0) {
											   echo  round($result = $query->row()->total,2);
										  }
										  else{
											echo '0';
										  }
										  
                                           
                                        ?>
                                            
                                        </h2>
                                        <span>Business Generation Month</span>
                                    </div>
                                    <div class="media-right media-middle">
                                        <i class="fas fa-chart-bar danger font-large-2 float-right"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-3 col-lg-3 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body text-left w-100">
                                        <h2 class="success">
                                        <?php
                                            if(!empty($fetch_yearly_earning)){
                                                if($fetch_yearly_earning->total == ''){
                                                  echo '0';
                                                }
                                                else{
                                                 echo round($fetch_yearly_earning->total,4);
                                                }
                                            }
                                        ?>
                                            
                                        </h2>
                                        <span>Business Generation Yearly</span>
                                    </div>
                                    <div class="media-right media-middle">
                                        <i class="fas fa-chart-bar danger font-large-2 float-right"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				<div class="col-xl-3 col-lg-3 col-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body">
                                <div class="media">
                                    <div class="media-body text-left w-100">
                                        <h2 class="success">
                                        <?php
										 $today_date = date('Y-m-d');
										  $this->db->SELECT("sum(quote_price) as total ");  
										  $this->db->FROM('tbl_booking'); 
										  $this->db->WHERE("transaction_id != 'NULL'");
										 // $this->db->where('(Year(transaction_date)="'.$today_date.'")');
										  $query = $this->db->get();
										  if ($query->num_rows() > 0) {
											   echo  round($result = $query->row()->total,2);
										  }
										  else{
											echo '0';
										  }
										  
                                           
                                        ?>
                                            
                                        </h2>
                                        <span>Business Generation Total</span>
                                    </div>
                                    <div class="media-right media-middle">
                                        <i class="fas fa-chart-bar danger font-large-2 float-right"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                
                
            </div>
            <!--/stats-->
			
			<div class="row match-height">
                <div class="col-xl-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Booking Symmary</h4>
                            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                            
                        </div>
                        <div id="world-map-markers" class="height-330">
						<div class="row"><div class="col-sm-12">
                            <div class="table-responsive">
								<table class="table table-striped table-bordered ">
                                        <thead>
                                            <tr>
                                                <th>City</th>
                                                <th>Booking <br/>Done</th>
                                                <th>Quote<br/> Send</th>
                                                <th>Accept</th>
                                                <th>Decline</th>
                                                <th>Complete</th>
                                                <th>Payment <br/>Done</th>
                                                <th>Booking <br/>canceled by <br/>artist</th>
                                                <th>Rating <br/>Done</th>
                                                <th>Booking<br/> Canceled by <br/>guest/venue </th>
                                            </tr>
                                        </thead>
                                        <tbody>
										<?php 
										$q="SELECT * FROM tbl_booking WHERE 1=1 GROUP BY city ORDER BY city ASC";
										$query = $this->db->query($q);
										if($query->num_rows()>0){
											foreach($query->result() as $key=>$val){
												?>
												<tr>
													<th><?php echo ($val->city==''?'Unnown':$val->city); ?></th>
													<th><?php echo $this->db->query("SELECT id FROM tbl_booking WHERE city='".$val->city."' AND status='0'")->num_rows(); ?></th>
													<th><?php echo $this->db->query("SELECT id FROM tbl_booking WHERE city='".$val->city."' AND status='1'")->num_rows(); ?></th>
													<th><?php echo $this->db->query("SELECT id FROM tbl_booking WHERE city='".$val->city."' AND status='3'")->num_rows(); ?></th>
													<th><?php echo $this->db->query("SELECT id FROM tbl_booking WHERE city='".$val->city."' AND status='4'")->num_rows(); ?></th>
													<th><?php echo $this->db->query("SELECT id FROM tbl_booking WHERE city='".$val->city."' AND status='5'")->num_rows(); ?></th>
													<th><?php echo $this->db->query("SELECT id FROM tbl_booking WHERE city='".$val->city."' AND status='6'")->num_rows(); ?></th>
													<th><?php echo $this->db->query("SELECT id FROM tbl_booking WHERE city='".$val->city."' AND status='7'")->num_rows(); ?></th>
													<th><?php echo $this->db->query("SELECT id FROM tbl_booking WHERE city='".$val->city."' AND status='8'")->num_rows(); ?></th>
													<th><?php echo $this->db->query("SELECT id FROM tbl_booking WHERE city='".$val->city."' AND status='9'")->num_rows(); ?></th>
												</tr>
												<?php 
											}
										}
										?>
											 
                                        </tbody>

                                </table>
							</div>
							</div>
							</div>
						</div>
					</div>
				</div>
			</div>
            <!-- Audience by country & users visit-->

            
            <?php 
                if($this->session->userdata('user_type') == '1'){?>
                <div class="row">
                 <div class="col-xl-12 col-lg-12">
                    <div class="card">
                        <div class="card-content">
                            <div class="card-body sales-growth-chart">
                            <div class="panel-body">
                                <!--<input type ="text" id= "month_data" value="">-->
                                <div id="chart_area" style="width: 100%; height: 620px;">
                                      <div id="chart-container">
                                        <canvas id="graphCanvas"></canvas>
                                    </div>
                                </div>
                            </div>    
                            <!--<div id="monthly-sales" class="height-250" style="position: relative; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);height:900px">
                                    <svg height="900" version="1.1" width="100%" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" style="overflow: hidden; position: relative; left: -0.265625px; top: -0.6875px;">
                                        <desc style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Created with Raphaël 2.1.2</desc>
                                        <defs style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></defs>
                                        
                                        <text x="42.84375" y="300" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">0</tspan>
                                        </text>
                                        
                                        <path fill="none" stroke="#e4e7ed" d="M55.34375,211H7770.000" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path>
                                        
                                        <text x="42.84375" y="250" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">1000</tspan>
                                        </text>
                                        
                                        <path fill="none" stroke="#e4e7ed" d="M55.34375,164.5H770.000" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path>
                                        
                                        <text x="42.84375" y="200" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">2000</tspan>
                                        </text>
                                        
                                        <path fill="none" stroke="#e4e7ed" d="M55.34375,118H770.000" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path>
                                        
                                        <text x="42.84375" y="150" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">3000</tspan>
                                        </text>
                                        
                                        <path fill="none" stroke="#e4e7ed" d="M55.34375,71.5H770.000" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path>
                                        
                                        <text x="42.84375" y="100" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">4,000</tspan>
                                        </text>
                                        
                                        <path fill="none" stroke="#e4e7ed" d="M55.34375,71.5H770.000" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path>
                                        
                                        <text x="42.84375" y="50" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">5,000</tspan>
                                        </text>
                                        
                                        
                                        <path fill="none" stroke="#e4e7ed" d="M55.34375,71.5H770.000" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path>
                                        
                                        <text x="42.84375" y="25" text-anchor="end" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: end; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">6,000</tspan>
                                        </text>
                                        
                                       
                                            $total_month_sale_jan = 0;
                                            $total_month_sale_feb = 0;
                                            foreach($fetch_monthly_earning as $month_earning){
                                                $date=strtotime($month_earning->transaction_date);
                                                $month=date("m",$date);
                                                
                                                switch($month){
                                                    case "01":
                                                        //print_r($month_earning->quote_price);
                                                    $total_month_sale_jan = $total_month_sale_jan + $month_earning->quote_price;
                                                    $y = $total_month_sale_jan /1.73068019248;
                                                    case "02":
                                                    $total_month_sale_feb =  $total_month_sale_feb + $month_earning->quote_price;
                                                    $z = $total_month_sale_feb / 1.73068019248;
                                                }
                                            } 
                                
                                        
                                        <path fill="none" stroke="#e4e7ed" d="M55.34375,25H770.000" stroke-width="0.5" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);"></path>
                                        
                                            <rect x="62.203378125" y="<?php echo $y ?>" width="5.87968125" height="<?php echo $total_month_sale_jan ?>" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="62.203378125" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Jan</tspan>
                                            </text>
                                            
                                            
                                            <rect x="124.40675625" y="<?php echo $z ?>" width="5.87968125" height="<?php echo $total_month_sale_feb ?>" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="124.40675625" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Feb</tspan>
                                            </t<rect x="186.610134375" y="76.890000000056" width="5.87968125" height="133.072" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="186.610134375" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Mar</tspan>
                                            </text>
                                            
                                            
                                            <rect x="248.8135125" y="76.890000000056" width="5.87968125" height="133.072" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="248.8135125" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Apr</tspan>
                                            </text>
                                            
                                            
                                            <rect x="311.016890625" y="76.890000000056" width="5.87968125" height="133.072" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="311.016890625" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">May</tspan>
                                            </text>
                                            
                                            <rect x="373.22026875" y="76.890000000056" width="5.87968125" height="133.072" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="373.22026875" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Jun</tspan>
                                            </text>
                                            
                                            
                                            <rect x="435.423646875" y="76.890000000056" width="5.87968125" height="133.072" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="435.423646875" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">July</tspan>
                                            </text>
                                            
                                            <rect x="497.627025" y="76.890000000056" width="5.87968125" height="133.072" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="497.627025" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Aug</tspan>
                                            </text>
                                            
                                            
                                            <rect x="559.830403125" y="76.890000000056" width="5.87968125" height="133.072" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="559.830403125" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Sep</tspan>
                                            </text>
                                            
                                            
                                            <rect x="622.03378125" y="76.890000000056" width="5.87968125" height="133.072" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="622.03378125" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Oct</tspan>
                                            </text>
                                            
                                            <rect x="684.237159375" y="76.890000000056" width="5.87968125" height="133.072" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="684.237159375" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="4" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">NOV</tspan>
                                            </text>
                                            
                                            
                                            <rect x="746.4405375" y="76.890000000056" width="5.87968125" height="133.072" rx="0" ry="0" fill="#00b5b8" stroke="none" fill-opacity="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); fill-opacity: 1;"></rect>
                                            <text x="746.4405375" y="223.5" text-anchor="middle" font-family="sans-serif" font-size="12px" stroke="none" fill="#bfbfbf" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0); text-anchor: middle; font-family: sans-serif; font-size: 12px; font-weight: normal;" font-weight="normal" transform="matrix(1,0,0,1,0,7)">
                                            <tspan dy="1" style="-webkit-tap-highlight-color: rgba(0, 0, 0, 0);">Dec</tspan>
                                            </text>
                                            
                                        
                                    </svg>
                                    <div class="morris-hover morris-default-style" style="left: 18.7838px; top: 93px; display: none;">
                                        <div class="morris-hover-row-label">Jan</div>
                                        <div class="morris-hover-point" style="color: #00B5B8">
                                            Sales: 1,835
                                        </div>
                                    </div>
                                </div>-->
                                
                                
                                
                                
                                
                                
                            </div>
                        </div>
                        <div class="card-footer">
                            <div class="chart-title mb-1 text-center">
                                <h6>Total monthly Sales.</h6>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php } ?>

            <!-- Analytics map based session -->
            <div class="row">
                <div class="col-12">
                    <div class="card box-shadow-0">
                        <div class="card-content">
                            <div class="row">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- Analytics map based session -->
        </div>
    </div>
</div>

<script>
/*$(document).ready(function () {
    showGraph();
});*/


/*function showGraph(){
    {*/
        /*var data = $('#month_data').val();
        //$.post("",
        function (data)
        {
            console.log(data);
     
             var name = [];
            var marks = [];

            for (var i in data) {
                name.push(data[i].student_name);
                marks.push(data[i].marks);
            }

            var chartdata = {
                labels: name,
                datasets: [
                    {
                        label: 'Student Marks',
                        backgroundColor: '#49e2ff',
                        borderColor: '#46d5f1',
                        hoverBackgroundColor: '#CCCCCC',
                        hoverBorderColor: '#666666',
                        data: marks
                    }
                ]
            };

            var graphTarget = $("#graphCanvas");

            var barGraph = new Chart(graphTarget, {
                type: 'bar',
                data: chartdata
            });
        });
    }*/
/*}*/
</script>