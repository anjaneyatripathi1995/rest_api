    <!-- The core Firebase JS SDK is always required and must be listed first -->
    <!--<script src="https://www.gstatic.com/firebasejs/7.8.2/firebase-app.js"></script>-->
    
    <!-- TODO: Add SDKs for Firebase products that you want to use
         https://firebase.google.com/docs/web/setup#available-libraries -->
    
    <!-- The core Firebase JS SDK is always required and must be listed first -->
    <script src="https://www.gstatic.com/firebasejs/7.14.2/firebase-app.js"></script>

    <!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->
    <script src="https://www.gstatic.com/firebasejs/7.14.2/firebase-analytics.js"></script> 
     <script>
    //   // Your web app's Firebase configuration
    //   var firebaseConfig = {
    //     apiKey: "AIzaSyCn9QSchZsYD796x0Wsy0GhYzlSLD1q8FA",
    //     authDomain: "chatsockettesting.firebaseapp.com",
    //     databaseURL: "https://chatsockettesting.firebaseio.com",
    //     projectId: "chatsockettesting",
    //     storageBucket: "chatsockettesting.appspot.com",
    //     messagingSenderId: "527652198748",
    //     appId: "1:527652198748:web:5e9f4b5b23a55f92558999"
    //   };
    //   // Initialize Firebase
    //   firebase.initializeApp(firebaseConfig);
    // //   var messagesRef = firebase.database().ref('chatsockettesting');
    // //   console.log(messagesRef);
    
    
     // Your web app's Firebase configuration
      var firebaseConfig = {
        apiKey: "AIzaSyBkRqCzzYSFcxR_FGcpPN6dRG0fehoHHbs",
        authDomain: "bookme-824d3.firebaseapp.com",
        databaseURL: "https://bookme-824d3.firebaseio.com",
        projectId: "bookme-824d3",
        storageBucket: "bookme-824d3.appspot.com",
        messagingSenderId: "896772498249",
        appId: "1:896772498249:web:835e735684723174e87098",
        measurementId: "G-9G2PXBL3C1"
      };
      // Initialize Firebase
      firebase.initializeApp(firebaseConfig);
      firebase.analytics();
     </script>

    <!--<script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-app.js"></script>-->
    <script src="https://www.gstatic.com/firebasejs/7.6.1/firebase-database.js"></script>
    
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-2">
                <div class="row breadcrumbs-top">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?= base_url('admin/admin_details') ?>">Home</a>
                            </li>

                            <li class="breadcrumb-item active">Chat Listing
                            </li>
                        </ol>
                    </div>
                </div>
                <h3 class="content-header-title mb-0">Chat Listing</h3>
            </div>

        </div>
        <div class="content-body">
            <!-- Zero configuration table -->
            <section id="configuration">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Chat Listing</h4>

                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <div class="row">
                                        <!--<div class="col-lg-12">-->
                                        <!--    <button class="btn btn-primary float-right btn-sm mb-3" data-toggle="modal" data-target="#successModal">Add New</button>-->
                                        <!--</div>-->
                                    </div>
                                    
                                    <table id="guestTable" class="table table-striped table-bordered zero-configuration" width="100%">
                                        <thead>
                                            <tr>
                                                <th>S.NO</th>
                                                <th>Booking ID</th>
                                                <th>Artist Name</th>
                                                <th>Venue Name</th>
                                                <th>Guest  Name</th>
                                                <th>Date</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>

                                        </tbody>

                                    </table>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


        </div>
    </div>
</div>

<div id="chatModel" class="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Chat List</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
            <table class="table table-reponsive table-bordered">
                <thead>
                <tr>
                    <th>User</th>
                    <th>Message</th>
                    <th>date/time</th>
                </tr>
                </thead>
                <tbody class="chat-data">
                <tr>
                    <th colspan="3">Loading...</th>
                </tr>
                </tbody>
            </table>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">

    $(document).on('click', '.view-chat', function(){
        var booking = $(this).data('booking');
        $('.chat-data').html('<tr><th colspan="3">Loading...</th></tr>');
        $('#chatModel').modal('show');
        $.ajax({
        method: "POST",
        url: "<?php echo base_url('admin/fetch_chat_details'); ?>",
        data: { booking: booking }
        })
        .done(function( data ) {
            $('.chat-data').html(data)
        });
        
    });
    
	var dataTable = $('#guestTable').DataTable({  
		"processing":true,
		"responsive": true,
		"language": {
			processing: '<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i><span class="sr-only">Loading...</span> '
		},
		dom: 'Blftip',
        select: true,
        buttons: [
         
        {extend: 'excel',
        footer: 'true',
        text: 'Excel', },
         
        {extend: 'pdf',
        footer: 'true',
        text: 'pdf',
        orientation: 'landscape', },
         
        'print',
             
        {extend: 'excel',
        text: 'Selected Excel',
        footer: 'true',
        exportOptions: {
        modifier: {
        selected: true
                }
            }
        },
        {
        extend: 'pdf',
        footer: 'true',
        orientation: 'landscape',
        text: 'Selected PDF',
        exportOptions: {
        modifier: {
        selected: true
                        }
                    }
                }
        ],
		"serverSide":true,
		"order":[],  
		"ajax":{  
			url:"<?php echo base_url('admin/fetch_chat_listing'); ?>",  
			type:"POST"  
		},
	});
</script>
