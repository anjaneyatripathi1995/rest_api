<style>
    #user_type{
        margin: 6px 0px 0px 20px;
    }
</style>
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2">
            <div class="row breadcrumbs-top">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item">
					<?php if(empty($repage)){
						?><a href="<?= base_url('admin/artist_listing') ?>">Home</a><?php 
					}else{
					?><a href="<?= base_url($repage) ?>">Home</a><?php 	
					}
				  ?>
                  </li>
                  <li class="breadcrumb-item active">Artist Detail
                  </li>
                </ol>
              </div>
            </div>
            <h3 class="content-header-title mb-0">Artist Details</h3>
          </div>
          
        </div>
        <div class="content-body"><!-- Zero configuration table -->
        <section id="configuration">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Artist Management</h4>

                        </div>
                        <div class="card-content collapse show">
						
						<?php 
							if($this->session->flashdata('success_msg')){
								?><div class="col-sm-12"><p class="alert alert-success"><?php echo $this->session->flashdata('success_msg'); ?></p></div><?php 
							}
							if($this->session->flashdata('error_msg')){
								?><div class="col-sm-12"><p class="alert alert-danger"><?php echo $this->session->flashdata('error_msg'); ?></p></div><?php 
							}
						?>
                            <div class="card-body card-dashboard">
                                <form method="post" action="<?= base_url()?>admin/add_artist/<?php echo @$id; ?>/<?php echo @$repage; ?>">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Username</label>
                                                <input type="text" value="<?php echo @$admindata->user_name; ?>" name="user_name" class="form-control">
                                            </div>    
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Email</label>
                                                <input type="email" required="required" name="artist_email" value="<?php echo @$admindata->artist_email; ?>" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Password (Optional)</label>
                                                <input type="password" required="required" name="artist_password" value="" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Name</label>
                                                <input type="text" value="<?php echo @$admindata->artist_name; ?>" name="artist_name" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Address </label>
                                                <input type="text" value="<?php echo @$admindata->artist_address; ?>" name="artist_address" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Building Number  </label>
                                                <input type="text" value="<?php echo @$admindata->building_number; ?>" name="building_number" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Street Number </label>
                                                <input type="text" value="<?php echo @$admindata->street_number; ?>" name="street_number" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Town </label>
                                                <input type="text" value="<?php echo @$admindata->town; ?>" name="town" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>City </label>
                                                <input type="text" value="<?php echo @$admindata->city; ?>" name="city" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Postal Code </label>
                                                <input type="text" value="<?php echo @$admindata->post_code; ?>" name="post_code" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Age </label>
                                                <input type="number" value="<?php echo @$admindata->artist_age; ?>" name="artist_age" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Category Ids </label>
                                                <input type="text" value="<?php echo @$admindata->artist_cat_id; ?>" name="artist_cat_id" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Category Name </label>
                                                <input type="text" value="<?php echo @$admindata->artist_category; ?>" name="artist_category" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Bio</label>
                                                <textarea  name="artist_bio" class="form-control"><?php echo @$admindata->artist_bio; ?></textarea>
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Price  </label>
                                                <input type="number" value="<?php echo @$admindata->artist_price; ?>" name="artist_price" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Travel </label>
                                                <input type="text" value="<?php echo @$admindata->artist_travel; ?>" name="artist_travel" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Equipment</label>
                                                <input type="text" value="<?php echo @$admindata->artist_equipment; ?>" name="artist_equipment" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Video Link </label>
                                                <input type="text" value="<?php echo @$admindata->artist_video_link; ?>" name="artist_video_link" class="form-control">
                                            </div>    
                                        </div>
										
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Rating </label>
                                                <input type="text" value="<?php echo @$admindata->rating; ?>" name="rating" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Paypal Email </label>
                                                <input type="text" value="<?php echo @$admindata->paypal_email; ?>" name="paypal_email" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Account Name </label>
                                                <input type="text" value="<?php echo @$admindata->account_name; ?>" name="account_name" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Account Number </label>
                                                <input type="text" value="<?php echo @$admindata->account_number; ?>" name="account_number" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Bank Short Code </label>
                                                <input type="text" value="<?php echo @$admindata->bank_sort_code; ?>" name="bank_sort_code" class="form-control">
                                            </div>    
                                        </div>
										
                                        <div class="col-md-6">
                                            <div class="form-froup" style="margin: 35px 0px 0px -15px;">
											
											<label>Status </label>
                                              <input type="checkbox" name="status" id="user_type" value="1" <?php if(isset($id) && !empty($id)){ if(@$admindata->status==1){ echo 'checked'; } ?><?php }else{ ?>checked <?php } ?>>
                                              <label for="Admin">Active</label>
                                              <input type="checkbox" name="status" id="user_type" <?php if(@$admindata->status==2){ echo 'checked'; } ?> value="2">
                                              <label for="User">Inactive</label>
                                            </div>    
                                        </div>
                                        
                                    </div>
                                    <div class="row" style="margin-top:10px">
                                        <div class="col-md-6">
                                            <input type="submit" name="submit" value="Save" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<!--/ Zero configuration table -->

<!--/ Language - Comma decimal place table -->

        </div>
      </div>
    </div>



