<footer class="footer footer-static footer-light navbar-border">
      <p class="clearfix blue-grey lighten-2 text-sm-center mb-0 px-2"><span class="float-md-left d-block d-md-inline-block">Copyright  &copy; <?php echo date('Y')?> 
      <a class="text-bold-800 grey darken-2" href="#" target="_blank">Bookme</a>, All rights reserved. </span></p>
    </footer>
    

<script src="<?=base_url()?>assets/admin/js/vendors.min.js"></script>
<script src="<?=base_url()?>assets/admin/js/app-menu.js"></script>
<script src="<?=base_url()?>assets/admin/js/app.js"></script>
<!--<script src="<?= base_url() ?>assets/admin/js/dashboard-analytics.js"></script>-->
<script src="<?=base_url()?>assets/admin/js/raphael-min.js"></script>
<!--<script src="<?= base_url() ?>assets/admin/js/morris.min.js"></script>-->
<script src="<?=base_url()?>assets/admin/js/jquery-jvectormap-2.0.3.min.js"></script>
<script src="<?=base_url()?>assets/admin/js/jquery-jvectormap-world-mill.js"></script>
<script src="<?=base_url()?>assets/admin/js/visitor-data.js"></script>
<script src="<?=base_url()?>assets/admin/js/chart.min.js"></script>
<script src="<?=base_url()?>assets/admin/js/datatables.min.js"></script>

</body>    
</html>