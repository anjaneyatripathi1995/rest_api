<style>
    #user_type{
        margin: 6px 0px 0px 20px;
    }
</style>
    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-header row">
          <div class="content-header-left col-md-6 col-12 mb-2">
            <div class="row breadcrumbs-top">
              <div class="breadcrumb-wrapper col-12">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?= base_url('admin/guest_listing') ?>">Home</a>
                  </li>
                  
                  <li class="breadcrumb-item active">Guest Detail
                  </li>
                </ol>
              </div>
            </div>
            <h3 class="content-header-title mb-0">Guest Details</h3>
          </div>
          
        </div>
        <div class="content-body"><!-- Zero configuration table -->
        <section id="configuration">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">Guest Management</h4>

                        </div>
                        <div class="card-content collapse show">
						
						<?php 
							if($this->session->flashdata('success_msg')){
								?><div class="col-sm-12"><p class="alert alert-success"><?php echo $this->session->flashdata('success_msg'); ?></p></div><?php 
							}
							if($this->session->flashdata('error_msg')){
								?><div class="col-sm-12"><p class="alert alert-danger"><?php echo $this->session->flashdata('error_msg'); ?></p></div><?php 
							}
						?>
                            <div class="card-body card-dashboard">
                                <form method="post" action="<?= base_url()?>admin/add_guest/<?php echo @$id; ?>">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Username</label>
                                                <input type="text" value="<?php echo @$admindata->username; ?>" name="username" class="form-control">
                                            </div>    
                                        </div>
                                        <div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Email</label>
                                                <input type="email" required="required" name="email" value="<?php echo @$admindata->email; ?>" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Password (Optional)</label>
                                                <input type="password"  name="password" value="" class="form-control">
                                            </div>    
                                        </div>
										<input type="hidden" value="updatevenue" name="updatevenue"> 
										
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Contact No.</label>
                                                <input type="text" required="required" name="contact_no" value="<?php echo @$admindata->contact_no; ?>" class="form-control">
                                            </div>    
                                        </div>
										
										
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Building Number  </label>
                                                <input type="text" value="<?php echo @$admindata->building_number; ?>" name="building_number" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Street Number </label>
                                                <input type="text" value="<?php echo @$admindata->street_number; ?>" name="street_number" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Town </label>
                                                <input type="text" value="<?php echo @$admindata->town; ?>" name="town" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>City </label>
                                                <input type="text" value="<?php echo @$admindata->city; ?>" name="city" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Postal Code </label>
                                                <input type="text" value="<?php echo @$admindata->post_code; ?>" name="post_code" class="form-control">
                                            </div>    
                                        </div>
										
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Bio</label>
                                                <textarea  name="guest_bio" class="form-control"><?php echo @$admindata->guest_bio; ?></textarea>
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Manager Name </label>
                                                <input type="text" value="<?php echo @$admindata->manager_name; ?>" name="manager_name" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label> Manager Contact No</label>
                                                <input type="text" value="<?php echo @$admindata->manager_contact_no; ?>" name="manager_contact_no" class="form-control">
                                            </div>    
                                        </div>
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label> Manager Contact Email</label>
                                                <input type="email" value="<?php echo @$admindata->manager_contact_email; ?>" name="manager_contact_email" class="form-control">
                                            </div>    
                                        </div>
										
										
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Facility,Available </label>
                                                <input type="text" value="<?php echo @$admindata->facilities_available; ?>" name="facilities_available" class="form-control">
                                            </div>    
                                        </div>
										
										<div class="col-md-6">
                                            <div class="form-froup">
                                                <label>Rating  </label>
                                                <input type="text" value="<?php echo @$admindata->rating; ?>" name="rating" class="form-control">
                                            </div>    
                                        </div>
										
										
										
										
										
                                        <div class="col-md-6">
                                            <div class="form-froup" style="margin: 35px 0px 0px -15px;">
											
											<label>Status </label>
                                              <input type="checkbox" name="status" id="user_type" value="1" <?php if(isset($id) && !empty($id)){ if(@$admindata->status==1){ echo 'checked'; } ?><?php }else{ ?>checked <?php } ?>>
                                              <label for="Admin">Active</label>
                                              <input type="checkbox" name="status" id="user_type" <?php if(@$admindata->status==2){ echo 'checked'; } ?> value="2">
                                              <label for="User">Inactive</label>
                                            </div>    
                                        </div>
                                        
                                    </div>
                                    <div class="row" style="margin-top:10px">
                                        <div class="col-md-6">
                                            <input type="submit" name="submit" value="Save" class="btn btn-primary">
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
<!--/ Zero configuration table -->

<!--/ Language - Comma decimal place table -->

        </div>
      </div>
    </div>



