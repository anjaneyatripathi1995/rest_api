<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require __DIR__.'/../../vendor/autoload.php';
use Kreait\Firebase\Factory;
use Kreait\Firebase\ServiceAccount;

class Admin extends CI_Controller
{
    
    public function __construct()
    {
        parent::__construct();
		
        if (!$this->session->userdata('adminemail') || !$this->session->userdata('adminname') || !$this->session->userdata('adminid')) {
            redirect('adminlogin');
            exit();
        }
        $this->load->model('Adminmodel');
    }
    public function index(){
        $data['fetch_analytics_data'] = $this->Adminmodel->fetch_analytics_data();
        $data['fetch_today_earning'] = $this->Adminmodel->fetch_today_earning();
        $data['fetch_yearly_earning'] = $this->Adminmodel->fetch_yearly_earning();
        $data['fetch_monthly_earning'] = $this->Adminmodel->fetch_monthly_earning();
        $this->load->view('admin/header');
        $this->load->view('admin/dashboard',$data);
        $this->load->view('admin/footer');
    }

    public function logout(){
        $user_data = $this->session->all_userdata();
        foreach ($user_data as $key => $value) {
            if ($key != '__ci_last_regenerate'){
                $this->session->unset_userdata($key);
            }
        }
        $this->session->sess_destroy();
        return redirect('adminlogin');
    }  
    
    //------------------Make slug of string------------------
	function make_slug_of_string($string){
		$slug = preg_replace('/[^a-z0-9-]+/', '-', trim(strtolower($string)));
		return $slug;
	}
    
    /***************************Global Upload path*********************************/

    private function custom_image_upload_function($fieldname,$uploadpath){
            $config['upload_path']          = $uploadpath;
            $config['overwrite']            = TRUE;
            $config['allowed_types']        = 'jpg|png|jpeg';
            $config['max_size']             = 10240000;
            $config['max_width']            = 0;
            $config['max_height']           = 0;
            //$config['file_name']            = $finalfilename;

            $this->load->library('upload', $config);

            if ( ! $this->upload->do_upload($fieldname)){
                return '';
            }
            else{
                $image_data = $this->upload->data();
                return  $image_data['file_name'];
        }
    }

/********************** Global Upload path Ends Here***************************/
    
    
/*----------------------------------------------------------------------------*/
		
    private function custom_file_upload($finalfilename, $fieldname){
            $config['upload_path']          = './uploads/warehouse_image/';
            $config['overwrite']            = TRUE;
            $config['allowed_types']        = 'jpg|png|jpeg';
            $config['max_size']             = 10240000;
            $config['max_width']            = 0;
            $config['max_height']           = 0;
            $config['file_name']            = $finalfilename;

            $this->load->library('upload', $config);

            if ( ! $this->upload->do_upload($fieldname)){
                return $this->upload->display_errors();
            }
            else{
            return true;
        }
    }

/*
----------------------------------------------------------------



/**************************Admin Details***************************************/

public function admin_details(){
       $this->load->view('admin/header');
       $this->load->view('admin/admin_details');
       $this->load->view('admin/footer');
}

public function add_user($id=''){
    // print_r($this->input->post);
    // die;
    $pagedata = [];
	$pagedata['id']=$id;
    if($this->input->post('admin_name') != ''){
        $data = array(
            "admin_name" => $this->input->post('admin_name'),
            "admin_email" => $this->input->post('admin_email'),
            "user_type"=>$this->input->post("user_type"),
            "status" => 1
        );
		if(empty($id)){
			$data['password'] =  $this->input->post('admin_password');
			if($save_data = $this->Adminmodel->save_admin_data($data)){
				redirect('admin_details');
			}
		}else{
			if($this->input->post('admin_password')){
				$data['password'] =  $this->input->post('admin_password');
			}
			$this->db->update('tbl_admin',$data,['id'=>$id]);
			$this->session->set_flashdata('success_msg','Data has been modified success');
		}
    
    }
	
	if(!empty($id)){
		$admindata = $this->db->get_where('tbl_admin',['id'=>$id])->row();
		$pagedata['admindata'] = $admindata;
	}
    $this->load->view('admin/header');
    $this->load->view('admin/add_user',$pagedata);
    $this->load->view('admin/footer');
}

        public function payment_details(){
            $this->load->view('admin/header');
            $this->load->view('admin/payment_details');
            $this->load->view('admin/footer');
        }
        
        public function fetch_payment_details(){    
            $fetch_data = $this->Adminmodel->fetch_payment_data();  
            $data = array();
            $sn = 1;  
            foreach($fetch_data as $row){  
        
            if($row->status==='1'){
            $st = '<span class="badge badge-pill badge-primary">Active</span>';
            $bt = '<button type="button" name="hide_category" mainid="'.$row->booking_table_id.'" class="btn btn-danger btn-sm hide_category"><i class="fa fa-ban"></i></button>';
            } 
            else {
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            $bt = '<button type="button" name="activate_category" mainid="'.$row->booking_table_id.'" class="btn btn-info btn-sm activate_category"><i class="fa fa-thumbs-up"></i></button>';
            }
        
            $sub_array = array(); 
            $sub_array[] = $sn++;
            $sub_array[] = $row->artist_name;
            $sub_array[] = $row->artist_urn;
            $sub_array[] = $row->venue_name;
            $sub_array[] = $row->booking_date;
            $sub_array[] = $row->payment_method;
            $sub_array[] = $row->transaction_id;
            $sub_array[] = $row->booking_id;
            $sub_array[] = $st;  
            $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->booking_added_at));
            
            $sub_array[] = $bt;  
            $data[] = $sub_array;  
            }  
            $output = array(  
            "draw" =>     intval($this->input->post("draw")),  
            "recordsTotal"  => $this->Adminmodel->get_all_paymentdata(),  
            "recordsFiltered" => $this->Adminmodel->get_filtered_paymentdata(),  
            "data" => $data  
            );  
            echo json_encode($output);
            }
            
        /*public function fetch_payment_details(){
          $fetch_data = $this->Adminmodel->fetch_payment_data();
          $data = array();
          $sn = 1;
          foreach($fetch_data as $record){
             $sub_array = array();
             $sub_array[] = $sn++;
             $sub_array[] = $record->artist_name;
             $sub_array[] = $record->artist_urn;
             $sub_array[] = $record->venue_name;
             $sub_array[] = $record->booking_date;
             $sub_array[] = $record->payment_method;
             $sub_array[] = $record->transaction_id;
             $sub_array[] = $record->booking_id;
             $data[] = $sub_array;
          }
           
          $output = array(
              "draw" =>     intval($this->input->post("draw")),  
                "recordsTotal"  => $this->Adminmodel->get_all_paymentdata(),  
                "recordsFiltered" => $this->Adminmodel->get_filtered_paymentdata(),
              "data" => $data);
          echo json_encode($output);
        }*/


public function fetch_all_admin_details(){    
    $fetch_data = $this->Adminmodel->fetch_all_admin_details_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){  

    if($row->status==='1'){
    $st = '<span class="badge badge-pill badge-primary">Active</span>';
    $bt = '<button style="float:left;margin-right:2px;" type="button" name="hide_category" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_category"><i class="fa fa-ban"></i></button>';
    } 
    else {
    $st = '<span class="badge badge-pill badge-danger">InActive</span>';
    $bt = '<button style="float:left;margin-right:2px;" type="button" name="activate_category" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_category"><i class="fa fa-thumbs-up"></i></button>';
    }
    
    if($row->user_type==='1'){
        $user_type = 'Admin';
    }
    else{
        $user_type = 'User';
    }

    $sub_array = array(); 
    $sub_array[] = $sn++;
    $sub_array[] = $row->admin_name;
    $sub_array[] = $row->admin_email;
    $sub_array[] = $user_type;
    $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->added_at));
    $sub_array[] = $st;  
    $sub_array[] = $bt;  
	if($this->session->userdata('user_type')==1){
    $sub_array[] = ' <a class="btn btn-info btn-sm" href="'.site_url('admin/add_user/'.$row->id).'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </a>';  
	}else{
		$sub_array[]='';
	}
      
    $data[] = $sub_array;  
    }  
    $output = array(  
    "draw" =>     intval($this->input->post("draw")),  
    "recordsTotal"  => $this->Adminmodel->get_all_admindata(),  
    "recordsFiltered" => $this->Adminmodel->get_filtered_admindata(),  
    "data" => $data  
    );  
    echo json_encode($output);
    }

    public function update_admin(){
    $up_data = array( 
    'status' => $this->input->post("status")
    ); 
    $updb = $this->Adminmodel->update_admin($this->input->post("id"), $up_data);   
    if($updb){
    echo json_encode(array('success'=>'Admin Updated successfully'));
    } else {
    echo json_encode(array('error'=>'Fail to Update Admin'));
    }	
 }
/***************************Admin Details Ends Here*****************************/

  
/***************************Category Listing starts Here****************/
    
    public function insert_category(){
        $this->load->view('admin/header');
        $this->load->view('admin/insert_category');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_category(){
    $fetch_data = $this->Adminmodel->fetch_all_category_listing_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){
        // print_r($row);
        // die;
        if($row->status==='1'){
            $st = '<span class="badge badge-pill badge-primary">Active</span>';
            $bt = '<button type="button" name="hide_category_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_category_listing"><i class="fa fa-ban"></i></button>';
        } else {
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            $bt = '<button type="button" name="activate_category_listing" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_category_listing"><i class="fa fa-thumbs-up"></i></button>';
        }

        //Update and Delete Button

        $dt = '<button type="button" name="delete_category_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm delete_category_listing"><i class="fa fa-trash"></i></button>';
        $ut = '<button type="button" name="edit_category_listing"  mainid="'.$row->id.'" class="btn btn-danger btn-sm edit_category_listing"><i class="fa fa-edit"></i></button>';

        
        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->category_name;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->added_at));
        $sub_array[] = $st;  
        $sub_array[] = $bt .$ut .$dt;  
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_category_listing_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_category_listing_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
    public function insert_category_listing_data(){
    if($this->input->post('taction')=="update_product"){
          $updated_data = array(
                'category_name' => $this->input->post("category_name"),
                'category_slug' =>$this->make_slug_of_string($this->input->post("category_name"))
            );
            $result = $this->Adminmodel->update_category_listing_data_model($updated_data, $this->input->post('id'));
            if($result===TRUE)    { 
                echo json_encode(array('success'=>'Details updated successfully')); 
                die;
            } 
            else {
                echo json_encode(array('error'=>'Fail to update Details'));
            } 

        }
        else{
        $insert_data = array( 
                'category_name' => $this->input->post("category_name"),
                'category_slug' =>$this->make_slug_of_string($this->input->post("category_name"))
        ); 
        $insertdb = $this->Adminmodel->insert_category_listing_data_model('tbl_category', $insert_data);   
        if($insertdb){
            echo json_encode(array('success'=>'Data Added successfully'));
        } else {
            echo json_encode(array('error'=>'Fail to Add Data'));
        }
      }
    }

    //fetch_single
    public function fetch_single_category_listing(){
        $output = array();  
        $data = $this->Adminmodel->fetch_single_category_listing_model($this->input->post("id"));  
            if($data){
                $output['category_name'] = $data->category_name;
            }  
                echo json_encode($output); 
         }

    public function hide_category_listing(){  
    $update_data = array(  
        'status' => '2'    
    );  
    $result = $this->Adminmodel->update_category_listing_status($this->input->post("id"), $update_data); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
    }
    }

    public function unhide_category_listing(){  
    $update_data = array(  
        'status' => '1'    
    );  
    $result = $this->Adminmodel->update_category_listing_status($this->input->post("id"), $update_data); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
    }
    }
    
    public function delete_category_listing(){  
    $result = $this->Adminmodel->delete_category_listing_model($this->input->post("id")); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
     }
    }

    
  /***************************************************************************
                        Category Listing Page Ends
  ****************************************************************************/
  
  /***************************artist Listing starts Here****************/
    
    public function artist_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/artist_list');
        $this->load->view('admin/footer');
    }
    public function add_artist($id='',$repage=''){
        if(empty($id)){
            redirect(site_url('admin/artist_listing'));
            exit;
        }
        $pagedata = [];
        $pagedata['id']=$id;
        $pagedata['repage']=$repage;
        if($this->input->post('artist_email') != ''){
            $error = false;
            $email = $this->input->post('artist_email');
            $checkemail = $this->db->get_where('tbl_artist',['artist_email'=>$email,'id!='=>$id]);
            if($checkemail->num_rows()>0){
                $this->session->set_flashdata('error_msg','Email already used by other artist ');
                $error = true;
            }
            if($this->input->post('user_name')){
                $user_name = $this->input->post('user_name');
                $checkemail = $this->db->get_where('tbl_artist',['user_name'=>$user_name,'id!='=>$id]);
                if($checkemail->num_rows()>0){
                    $this->session->set_flashdata('error_msg','Username already used by other artist ');
                    $error = true;
                }
            }
            if(!$error){
                $post = $this->input->post();
                foreach($post as $key=>$val){
                    if($key == 'submit'){
                        continue;
                    }
                    if($key == 'password'){
                        $data[$key]=md5($val);
                    }else{
                        $data[$key]=$val;
                    }
                }
                
                $this->db->update('tbl_artist',$data,['id'=>$id]);
                $this->session->set_flashdata('success_msg','Data has been modified success');
            }
        
        }
        
        if(!empty($id)){
            $artist_data = $this->db->get_where('tbl_artist',['id'=>$id])->row();
            $pagedata['admindata'] = $artist_data;
        }
        $this->load->view('admin/header');
        $this->load->view('admin/add_artist',$pagedata);
        $this->load->view('admin/footer');
    }

    public function fetch_all_artist(){
        $fetch_data = $this->Adminmodel->fetch_all_artist_listing_model();  
        $data = array();
        $sn = 1;  
        foreach($fetch_data as $row){

            if($row->status==='1'){
                $st = '<span class="badge badge-pill badge-primary">Active</span>';
                $bt = '<button type="button" name="hide_artist_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_artist_listing"><i class="fa fa-ban"></i></button>';
            } else {
                $st = '<span class="badge badge-pill badge-danger">InActive</span>';
                $bt = '<button type="button" name="activate_artist_listing" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_artist_listing"><i class="fa fa-thumbs-up"></i></button>';
            }
            
            if($this->session->userdata('user_type') == 1) {
                $bt .= ' | <button type="button" name="delete_artist_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm delete_artist_listing"><i class="fa fa-remove"></i></button>';
            }
            $rating_btn = '<button type="button" title="Manage All Ratings" data-artist="'.$row->id.'" class="btn btn-info btn-sm view_all_ratings"><i class="fa fa-eye"></i></button>';
            
            //Update and Delete Button
            // $dt = '<button type="button" name="delete_artist_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm delete_artist_listing"><i class="fa fa-trash"></i></button>';
            // $ut = '<button type="button" name="edit_artist_listing"  mainid="'.$row->id.'" class="btn btn-danger btn-sm edit_artist_listing"><i class="fa fa-edit"></i></button>';

            $sub_array = array(); 
            $sub_array[] = $sn++;
            $sub_array[] = $row->artist_urn;
            $sub_array[] = $row->artist_name;
            $sub_array[] = $row->artist_email;
            $sub_array[] = $row->artist_contact;
            $sub_array[] = ($row->rating)?$row->rating."&nbsp;&nbsp;".$rating_btn:'<span class="text text-danger">NA</span>';
            $sub_array[] = $row->artist_bio;
            $sub_array[] = $row->artist_price;
            $sub_array[] = $row->artist_travel;
            $sub_array[] = $row->building_number;
            $sub_array[] = $row->street_number;
            $sub_array[] = $row->town;
            $sub_array[] = $row->city;
            $sub_array[] = $row->post_code;
            $sub_array[] = ($row->month_price == null)?'N/A':$row->month_price;
            $sub_array[] = ($row->year_price == null)?'N/A':$row->year_price;
            $sub_array[] = ($row->total_booking_taken == null)?'N/A':$row->total_booking_taken." <a href='".base_url('booking_listing')."?u=a&i=".$row->id."&type=taken"."'>View Booking</a>";
            $sub_array[] = ($row->total_booking_canceled == null)?'N/A':$row->total_booking_canceled." <a href='".base_url('booking_listing')."?u=a&i=".$row->id."&type=canceled"."'>View Booking</a>";

            $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->added_at));
            $sub_array[] = $st;  
            if($this->session->userdata('user_type')==1){
                $sub_array[] = $bt.' | <a class="btn btn-info btn-sm" href="'.site_url('admin/add_artist/'.$row->id).'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';
            }else{
                $sub_array[] = $bt;
            }
            
            $data[] = $sub_array;  
        }  
        $output = array(  
            "draw" =>     intval($this->input->post("draw")),  
            "recordsTotal"  => $this->Adminmodel->get_all_artist_listing_model(),  
            "recordsFiltered" => $this->Adminmodel->get_filtered_artist_listing_model(),  
            "data" => $data  
        );  
        echo json_encode($output);
    }


    public function fetch_ratings(){
        if(isset($_REQUEST['artist']) and $_REQUEST['artist'] != ''){
            $ratings = $this->Adminmodel->get_artist_rating($_REQUEST['artist']);
            $sr = 1;
            $html_tr = "";
            foreach($ratings as $rating){
                if($rating->guest_id !== null){
                    $rate_by = $rating->guest_name." (Guest)";
                }else{
                    $rate_by = $rating->venue_name." (Venue)"; 
                }
                $html_tr .= "<tr>".
                            "<td>".$sr."</td>".
                            "<td>".$rating->booking_id."</td>".
                            "<td>".$rate_by."</td>".
                            "<td>".$rating->comments."</td>".
                            "<td>".$rating->rating."</td>".
                            "<td>".$rating->rating_2."</td>".
                            "<td>".$rating->rating_3."</td>".
                            "<td>".$rating->added_at."</td>".
                            "<td><a data-rating='".$rating->id."' data-artist='".$rating->artist_id."' class='delete_rating' title='Delete Rating' href='javascript:void(0)'><i class='fa fa-trash'></i></a></td>".
                            "</tr>";
                $sr++;
            }
            echo $html_tr;
        }else{
            echo '<tr colspan="6">No ratings available!</tr>';
        }
        
    }

    public function delete_rating(){  
        $result = $this->Adminmodel->delete_artist_rating_model($this->input->post("rating")); 
        if($result){
            $this->Adminmodel->revise_artist_rating_model($this->input->post('artist'));
            echo json_encode(array('error'=> false, 'message'=>'Record deleted sucessfully.'));
        }else{
            echo json_encode(array('error'=> true, 'message'=>'Fail to Update Data.'));
        }
    }

    
    public function hide_artist_listing(){  
    $update_data = array(  
        'status' => '2'    
    );  
    $result = $this->Adminmodel->update_artist_listing_status($this->input->post("id"), $update_data); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
    }
    }

    public function activate_artist_listing(){  
        $update_data = array(  
            'status' => '1'    
        );  
     $result = $this->Adminmodel->update_artist_listing_status($this->input->post("id"), $update_data); 
     if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
     }
     else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
     }
    }
    public function delete_artist_listing(){  
    $result = $this->Adminmodel->delete_artist_listing_model($this->input->post("id")); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
     }
    }
    

    
  /***************************************************************************
                        artist Listing Page Ends
  ****************************************************************************/
  
  /***************************Artist By Rating starts Here****************/
    
    public function artist_by_rating_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/artist_by_rating');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_artist_by_rating(){
    $fetch_data = $this->Adminmodel->fetch_all_artist_by_rating_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){

        if($row->status==='1'){
            $st = '<span class="badge badge-pill badge-primary">Active</span>';
            $bt = '<button type="button" name="hide_artist_by_rating" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_artist_by_rating"><i class="fa fa-ban"></i></button>';
        } else {
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            $bt = '<button type="button" name="activate_artist_by_rating" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_artist_by_rating"><i class="fa fa-thumbs-up"></i></button>';
        }

        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->artist_name;
        $sub_array[] = $row->artist_email;
        $sub_array[] = $row->artist_contact;
        $sub_array[] = $row->rating;
        $sub_array[] = $row->artist_bio;
        $sub_array[] = $row->artist_price;
        $sub_array[] = $row->artist_travel;
        $sub_array[] = $row->artist_address;
        $sub_array[] = $row->building_number;
        $sub_array[] = $row->street_number;
        $sub_array[] = $row->town;
        $sub_array[] = $row->city;
        $sub_array[] = $row->post_code;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->added_at));
		if($this->session->userdata('user_type')==1){
        $sub_array[] = $st.'<a class="btn btn-info btn-sm" href="'.site_url('admin/add_artist/'.$row->id.'/artist_by_rating').'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';  
		}else{
			$sub_array[] = $st;
		}
        $sub_array[] = $bt;  
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_artist_by_rating_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_artist_by_rating_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
    

    
  /***************************************************************************
                        Artist By Rating Page Ends
  ****************************************************************************/
  
  
    /***************************Artist completed performance starts Here****************/
    
    public function artist_completed_performance(){
        $this->load->view('admin/header');
        $this->load->view('admin/artist_completed_performance');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_artist_completed_performance(){
    $fetch_data = $this->Adminmodel->fetch_all_artist_completed_performance_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){
        // echo '<pre>';
        // print_r($row);
        // die;
        
        if($row->booking_status==='5'){
            $st = '<span class="badge badge-pill badge-primary">Completed</span>';
        }
        
        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->booking_id;
        $sub_array[] = $row->booking_date;
        $sub_array[] = $row->artist_urn;
        $sub_array[] = $row->artist_name;
        $sub_array[] = $row->artist_email;
        $sub_array[] = $row->artist_contact;
        $sub_array[] = $row->rating;
        $sub_array[] = $row->artist_bio;
        $sub_array[] = $row->artist_price;
        $sub_array[] = $row->artist_travel;
        $sub_array[] = $row->building_number;
        $sub_array[] = $row->street_number;
        $sub_array[] = $row->town;
        $sub_array[] = $row->city;
        $sub_array[] = $row->post_code;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->c_date));
        $sub_array[] = $st;  
        $data[] = $sub_array;  
    } 
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_artist_completed_performance_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_artist_completed_performance_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
  /***************************************************************************
                        artist completed performance Page Ends
  ****************************************************************************/
  
  
  /***************************artist analysis report  starts Here****************/
    
    public function artist_analysis_report(){
        $this->load->view('admin/header');
        $this->load->view('admin/artist_analysis_report');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_artist_analysis(){
    $fetch_data = $this->Adminmodel->fetch_all_artist_analysis_listing_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){
        $vt = '<button type="button" name="view_artist_analysis" mainid="'.$row->id.'" class="btn btn-danger btn-sm view_artist_analysis"><i class="fa fa-eye"></i></button>';
        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->artist_name;
        $sub_array[] = $row->artist_urn;
        $sub_array[] = $row->artist_email;
        $sub_array[] = $row->artist_contact;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->added_at));
		if($this->session->userdata('user_type')==1){
        $sub_array[] = $vt.'<a class="btn btn-info btn-sm" href="'.site_url('admin/add_artist/'.$row->id.'/artist_analysis_report').'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';  
		}else{
			$sub_array[] = $vt;
		}
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_artist_analysis_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_artist_analysis_model(),  
        "data" => $data  
    );  
     echo json_encode($output);
    }

    public function fetch_single_artist_analysis_report(){
            $output = array();
            $data = $this->Adminmodel->fetch_single_product_listing_model($this->input->post("artist_id")); 
            if($data){
                foreach ($data as $analysis){
                    $total_cancellation = 0;
                    $total_booking = 0;
                    $total_issue= 0;
                    if($analysis->status == '7'){
                        $total_cancellation++;
                    }
                    if($analysis->issue_status == '1' or $analysis->issue_status == '2'){
                        $total_issue++;
                    }
                    if(!empty($analysis->artist_id)){
                        $total_booking++;
                    }
                }
                $output='<div class="card">
                <div class="card-body"><span><strong>Analysis Report: </strong></span>
                   <ul>
                        <li style="font-size: 17px;line-height: 35px;font-weight: 600;">Total Booking:- 
                        <span style="padding-left: 20px;color: #9ada00;font-size: 20px;">'.$total_booking.'</span>
                        </li>
                        <li style="font-size: 17px;line-height: 35px;font-weight: 600;">Total Cancellation:- 
                        <span style="padding-left: 20px;color: red;font-size: 20px;">'.$total_cancellation.'</span>
                        </li>
                        <li style="font-size: 17px;line-height: 35px;font-weight: 600;">Total Issue:- 
                        <span style="padding-left: 20px;color: red;font-size: 20px;">'.$total_issue.'</span>
                        </li>
                     </ul>
                    <hr>
                  </div>
                </div>';
            } 
            else{
                $output = '<div class="card">
                <div class="card-body"><span><strong>Analysis Report: </strong></span>
                     <ul>
                       <li style="font-size:17px;line-height:35px;font-weight:600;">No Data Found</li>
                     </ul>
                    <hr>
                  </div>
                </div>';
            }
       echo json_encode($output); 
    }
    
    

    
  /***************************************************************************
                        artist analysis Page Ends
  ****************************************************************************/
  
  
    /***************************venue Listing starts Here****************/
    
    public function venue_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/venue_list');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_venue(){
    $fetch_data = $this->Adminmodel->fetch_all_venue_listing_model();
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){

        if($row->status==='1'){
            $st = '<span class="badge badge-pill badge-primary">Active</span>';
            $bt = '<button type="button" name="hide_venue_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_venue_listing"><i class="fa fa-ban"></i></button>';
        } else {
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            $bt = '<button type="button" name="activate_venue_listing" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_venue_listing"><i class="fa fa-thumbs-up"></i></button>';
        }
        
        if($this->session->userdata('user_type') == 1) {
            $bt .= ' | <button type="button" name="delete_venue_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm delete_venue_listing"><i class="fa fa-remove"></i></button>';
        }
        //Update and Delete Button
        //$dt = '<button type="button" name="delete_venue_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm delete_venue_listing"><i class="fa fa-trash"></i></button>';
        //$ut = '<button type="button" name="edit_venue_listing"  mainid="'.$row->id.'" class="btn btn-danger btn-sm edit_venue_listing"><i class="fa fa-edit"></i></button>';

        
        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->venue_urn;
        $sub_array[] = $row->venue_name;
        $sub_array[] = $row->email;
        $sub_array[] = $row->contact_no;
        $sub_array[] = ($row->rating)?$row->rating:'<span class="text text-danger">NA</span>';
        $sub_array[] = $row->venue_bio;
        $sub_array[] = $row->venue_manager_name;
        $sub_array[] = $row->manager_contact_no;
        $sub_array[] = $row->city;
        $sub_array[] = $row->building_number;
        $sub_array[] = $row->street_number;
        $sub_array[] = $row->town;
        $sub_array[] = ($row->month_price == null)?'N/A':$row->month_price;
        $sub_array[] = ($row->year_price == null)?'N/A':$row->year_price;
        $sub_array[] = ($row->total_booking_taken == null)?'N/A':$row->total_booking_taken." <a href='".base_url('booking_listing')."?u=v&i=".$row->id."&type=taken"."'>View Bookings</a>";
        $sub_array[] = ($row->total_booking_canceled == null)?'N/A':$row->total_booking_canceled." <a href='".base_url('booking_listing')."?u=v&i=".$row->id."&type=canceled"."'>View Booking</a>";
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->added_at));
        $sub_array[] = $st;  
		if($this->session->userdata('user_type')==1){
        $sub_array[] = $bt.' | <a class="btn btn-info btn-sm" href="'.site_url('admin/add_venue/'.$row->id).'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';  
		}else{
			 $sub_array[] = $bt;
		}
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_venue_listing_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_venue_listing_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
    public function hide_venue_listing(){  
    $update_data = array(  
        'status' => '2'    
    );  
    $result = $this->Adminmodel->update_venue_listing_status($this->input->post("id"), $update_data); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
    }
    }

    public function activate_venue_listing(){  
        $update_data = array(  
            'status' => '1'    
        );  
     $result = $this->Adminmodel->update_venue_listing_status($this->input->post("id"), $update_data); 
     if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
     }
     else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
     }
    }

    
  /***************************************************************************
                        venue Listing Page Ends
  ****************************************************************************/
  
  /***************************Venue Analysis Report starts Here****************/
    
    public function venue_analysis_report(){
        $this->load->view('admin/header');
        $this->load->view('admin/venue_analysis_report');
        $this->load->view('admin/footer');
    }
    
    /*public function fetch_all_venue(){
    $fetch_data = $this->Adminmodel->fetch_all_venue_listing_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){

        if($row->status==='1'){
            $st = '<span class="badge badge-pill badge-primary">Active</span>';
            $bt = '<button type="button" name="hide_venue_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_venue_listing"><i class="fa fa-ban"></i></button>';
        } else {
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            $bt = '<button type="button" name="activate_venue_listing" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_venue_listing"><i class="fa fa-key"></i></button>';
        }

        //Update and Delete Button

         //$dt = '<button type="button" name="delete_venue_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm delete_venue_listing"><i class="fa fa-trash"></i></button>';
         //$ut = '<button type="button" name="edit_venue_listing"  mainid="'.$row->id.'" class="btn btn-danger btn-sm edit_venue_listing"><i class="fa fa-edit"></i></button>';

        
        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->venue_name;
        $sub_array[] = $row->email;
        $sub_array[] = $row->contact_no;
        $sub_array[] = $row->rating;
        $sub_array[] = $row->venue_bio;
        $sub_array[] = $row->venue_manager_name;
        $sub_array[] = $row->manager_contact_no;
        $sub_array[] = $row->city;
        $sub_array[] = $row->building_number;
        $sub_array[] = $row->street_number;
        $sub_array[] = $row->town;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->added_at));
        $sub_array[] = $st;  
        $sub_array[] = $bt;  
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_venue_listing_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_venue_listing_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }*/

    
  /***************************************************************************
                        Venue Analysis Report Page Ends
  ****************************************************************************/
  
  /***************************Venue By Rating starts Here****************/
    
    public function venue_by_rating_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/venue_by_rating');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_venue_by_rating(){
    $fetch_data = $this->Adminmodel->fetch_all_venue_by_rating_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){

        if($row->status==='1'){
            $st = '<span class="badge badge-pill badge-primary">Active</span>';
            $bt = '<button type="button" name="hide_venue_by_rating" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_venue_by_rating"><i class="fa fa-ban"></i></button>';
        } else {
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            $bt = '<button type="button" name="activate_venue_by_rating" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_venue_by_rating"><i class="fa fa-key"></i></button>';
        }

        //Update and Delete Button

         //$dt = '<button type="button" name="delete_venue_by_rating" mainid="'.$row->id.'" class="btn btn-danger btn-sm delete_venue_by_rating"><i class="fa fa-trash"></i></button>';
         //$ut = '<button type="button" name="edit_venue_by_rating"  mainid="'.$row->id.'" class="btn btn-danger btn-sm edit_venue_by_rating"><i class="fa fa-edit"></i></button>';

        
        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->venue_name;
        $sub_array[] = $row->email;
        $sub_array[] = $row->contact_no;
        $sub_array[] = $row->rating;
        $sub_array[] = $row->venue_bio;
        $sub_array[] = $row->venue_manager_name;
        $sub_array[] = $row->manager_contact_no;
        $sub_array[] = $row->city;
        $sub_array[] = $row->building_number;
        $sub_array[] = $row->street_number;
        $sub_array[] = $row->town;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->added_at));
		if($this->session->userdata('user_type')==1){
        $sub_array[] = $st.' | <a class="btn btn-info btn-sm" href="'.site_url('admin/add_venue/'.$row->id.'/venue_by_rating').'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';  
		}else{
			$sub_array[] = $st;
		}
        $sub_array[] = $bt;  
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_venue_by_rating_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_venue_by_rating_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
    public function insert_venue_by_rating_data(){
    if($this->input->post('taction')=="update_product"){
          $updated_data = array(
                'venue_name' => $this->input->post("venue_name"),
                'venue_slug' =>$this->make_slug_of_string($this->input->post("venue_name"))
            );
            $result = $this->Adminmodel->update_venue_by_rating_data_model($updated_data, $this->input->post('id'));
            if($result===TRUE)    { 
                echo json_encode(array('success'=>'Details updated successfully')); 
                die;
            } 
            else {
                echo json_encode(array('error'=>'Fail to update Details'));
            } 

        }
        else{
        $insert_data = array( 
                'venue_name' => $this->input->post("venue_name"),
                'venue_slug' =>$this->make_slug_of_string($this->input->post("venue_name"))
        ); 
        $insertdb = $this->Adminmodel->insert_venue_by_rating_data_model('tbl_venue', $insert_data);   
        if($insertdb){
            echo json_encode(array('success'=>'Data Added successfully'));
        } else {
            echo json_encode(array('error'=>'Fail to Add Data'));
        }
      }
    }

    //fetch_single
    public function fetch_single_venue_by_rating(){
        $output = array();  
        $data = $this->Adminmodel->fetch_single_venue_by_rating_model($this->input->post("id"));  
            if($data){
                $output['venue_name'] = $data->venue_name;
            }  
                echo json_encode($output); 
         }

    public function hide_venue_by_rating(){  
    $update_data = array(  
        'status' => '2'    
    );  
    $result = $this->Adminmodel->update_venue_by_rating_status($this->input->post("id"), $update_data); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
    }
    }

    public function unhide_venue_by_rating(){  
    $update_data = array(  
        'status' => '1'    
    );  
    $result = $this->Adminmodel->update_venue_by_rating_status($this->input->post("id"), $update_data); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
    }
    }
    
    public function delete_venue_by_rating(){  
    $result = $this->Adminmodel->delete_venue_by_rating_model($this->input->post("id")); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
     }
    }
    
  /***************************************************************************
                        Venue By Rating Page Ends
  ****************************************************************************/
  
  /***************************guest Listing starts Here****************/
    
    public function guest_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/guest_list');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_guest(){
    $fetch_data = $this->Adminmodel->fetch_all_guest_listing_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){
    //   echo '<pre>';print_r($row);
    //   die;
        if($row->status==='1'){
            $st = '<span class="badge badge-pill badge-primary">Active</span>';
            $bt = '<button type="button" name="hide_guest_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_guest_listing"><i class="fa fa-ban"></i></button>';
        } else {
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            $bt = '<button type="button" name="activate_guest_listing" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_guest_listing"><i class="fa fa-thumbs-up"></i></button>';
        }
        
        if($this->session->userdata('user_type') == 1) {
            $bt .= ' | <button type="button" name="delete_guest_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm delete_guest_listing"><i class="fa fa-remove"></i></button>';
        }
        //Update and Delete Button

         //$dt = '<button type="button" name="delete_guest_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm delete_guest_listing"><i class="fa fa-trash"></i></button>';
         //$ut = '<button type="button" name="edit_guest_listing"  mainid="'.$row->id.'" class="btn btn-danger btn-sm edit_guest_listing"><i class="fa fa-edit"></i></button>';

        
        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->guest_urn;
        $sub_array[] = $row->username;
        $sub_array[] = $row->manager_contact_email	;
        $sub_array[] = $row->manager_contact_no;
        $sub_array[] = ($row->rating)?$row->rating:'<span class="text text-danger">NA</span>';
        $sub_array[] = $row->guest_bio;
        $sub_array[] = $row->manager_name;
        $sub_array[] = $row->contact_no;
        $sub_array[] = $row->city;
        $sub_array[] = $row->building_number;
        $sub_array[] = $row->street_number;
        $sub_array[] = $row->town;
        $sub_array[] = ($row->month_price == null)?'N/A':$row->month_price;
        $sub_array[] = ($row->year_price == null)?'N/A':$row->year_price;
        $sub_array[] = ($row->total_booking_taken == null)?'N/A':$row->total_booking_taken." <a href='".base_url('booking_listing')."?u=g&i=".$row->id."&type=taken"."'>View Booking</a>";
        $sub_array[] = ($row->total_booking_canceled == null)?'N/A':$row->total_booking_canceled." <a href='".base_url('booking_listing')."?u=g&i=".$row->id."&type=canceled"."'>View Booking</a>";
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->added_at));
        $sub_array[] = $st;  
		if($this->session->userdata('user_type')==1){
        $sub_array[] = $bt.' | <a class="btn btn-info btn-sm" href="'.site_url('admin/add_guest/'.$row->id).'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
';  
		}else{
			$sub_array[] = $bt;
		}
        $data[] = $sub_array;
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_guest_listing_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_guest_listing_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
    public function insert_guest_listing_data(){
    if($this->input->post('taction')=="update_product"){
          $updated_data = array(
                'guest_name' => $this->input->post("guest_name"),
                'guest_slug' =>$this->make_slug_of_string($this->input->post("guest_name"))
            );
            $result = $this->Adminmodel->update_guest_listing_data_model($updated_data, $this->input->post('id'));
            if($result===TRUE)    { 
                echo json_encode(array('success'=>'Details updated successfully')); 
                die;
            } 
            else {
                echo json_encode(array('error'=>'Fail to update Details'));
            } 

        }
        else{
        $insert_data = array( 
                'guest_name' => $this->input->post("guest_name"),
                'guest_slug' =>$this->make_slug_of_string($this->input->post("guest_name"))
        ); 
        $insertdb = $this->Adminmodel->insert_guest_listing_data_model('tbl_guest', $insert_data);   
        if($insertdb){
            echo json_encode(array('success'=>'Data Added successfully'));
        } else {
            echo json_encode(array('error'=>'Fail to Add Data'));
        }
      }
    }

    //fetch_single
    public function fetch_single_guest_listing(){
        $output = array();  
        $data = $this->Adminmodel->fetch_single_guest_listing_model($this->input->post("id"));  
            if($data){
                $output['guest_name'] = $data->guest_name;
            }  
                echo json_encode($output); 
         }

    public function hide_guest_listing(){  
    $update_data = array(  
        'status' => '2'    
    );  
    $result = $this->Adminmodel->update_guest_listing_status($this->input->post("id"), $update_data); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
    }
    }

    public function activate_guest_listing(){  
    $update_data = array(  
        'status' => '1'    
    );  
    $result = $this->Adminmodel->update_guest_listing_status($this->input->post("id"), $update_data); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
    }
    }
    
    public function delete_guest_listing(){  
    $result = $this->Adminmodel->delete_guest_listing_model($this->input->post("id")); 
    if($result){
        echo json_encode(array('success'=>'Data updated successfully'));
    }
    else{
        echo json_encode(array('error'=>'Fail to Update Data.'));
     }
    }
    
    public function delete_venue_listing(){  
        $result = $this->Adminmodel->delete_venue_listing_model($this->input->post("id")); 
        if($result){
            echo json_encode(array('success'=>'Data updated successfully'));
        }
        else{
            echo json_encode(array('error'=>'Fail to Update Data.'));
         }
    }

    
  /***************************************************************************
                        guest Listing Page Ends
  ****************************************************************************/
  
   /***************************booking Listing starts Here****************/
    
    public function booking_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/booking_list');
        $this->load->view('admin/footer');
    }
	public function viewbooking($id){
		$data=[];
		$booking = $this->db->get_where('tbl_booking',['id'=>$id])->row();
		$data['booking'] = $booking;
        $this->load->view('admin/header');
        $this->load->view('admin/booking_view',$data);
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_booking(){
    $fetch_data = $this->Adminmodel->fetch_all_booking_listing_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){
        $status = $row->status;
        switch($status){
            case "0":
            $st = '<span class="badge badge-pill badge-primary">Booking Done</span>';
			
            $bt = '<button type="button" name="hide_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_booking_listing"><i class="fa fa-ban"></i></button>';
            break;
            case "1":
            $st = '<span class="badge badge-pill badge-primary">Quote Sent</span>';
            $bt = '<button type="button" name="hide_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_booking_listing"><i class="fa fa-ban"></i></button>';
            break;
            case "2":
            $st = '<span class="badge badge-pill badge-primary">Counter Offer Sent</span>';
            $bt = '<button type="button" name="hide_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_booking_listing"><i class="fa fa-ban"></i></button>';
            break;
            case "3":
            $st = '<span class="badge badge-pill badge-primary">Accepted</span>';
            $bt = '<button type="button" name="hide_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_booking_listing"><i class="fa fa-ban"></i></button>';
            break;
            case "4":
            $st = '<span class="badge badge-pill badge-danger">Declined</span>';
            $bt = '<button type="button" name="hide_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_booking_listing"><i class="fa fa-ban"></i></button>';
            break;
            case "5":
            $st = '<span class="badge badge-pill badge-primary">Booking Completed</span>';
            $bt = '<button type="button" name="hide_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_booking_listing"><i class="fa fa-ban"></i></button>';
            break;
            case "6":
            $st = '<span class="badge badge-pill badge-primary">Payment Done</span>';
            $bt = '<button type="button" name="hide_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_booking_listing"><i class="fa fa-ban"></i></button>';
            break;
            case "7":
            $st = '<span class="badge badge-pill badge-danger">Booking Canceled</span>';
            $bt = '<button type="button" name="hide_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_booking_listing"><i class="fa fa-ban"></i></button>';
            
            case "8":
            $st = '<span class="badge badge-pill badge-primary">Rating Done</span>';
            $bt = '<button type="button" name="hide_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_booking_listing"><i class="fa fa-ban"></i></button>';
            break;
             default:
             $st = '<span class="badge badge-pill badge-primary">Error</span>';
             $bt = '<span class="badge badge-pill badge-primary">Error</span>';
			 
			 /*sunil kumar*/
			 
			 /*sunil kumar*/
        }
        
        
        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->booking_id;
        if($row->artist_id != ''){
          $sub_array[] =  $this->Adminmodel->getFieldWhere('artist_name','tbl_artist','id',$row->artist_id);
        }
        else{
            $sub_array[] = '';
        }
        
        if($row->venue_id != ''){
           $sub_array[] =  $this->Adminmodel->getFieldWhere('venue_name','tbl_venue','id',$row->venue_id);
        }
        else{
             $sub_array[] = '';
        }
        
        if($row->guest_id != ''){
            $sub_array[] =  $this->Adminmodel->getFieldWhere('username','tbl_guest','id',$row->guest_id);
        }
        else{
             $sub_array[] = '';
        }
        
        // $sub_array[] = $row->venue_id;
        // $sub_array[] = $row->guest_id;
        $sub_array[] = $row->category;
        $sub_array[] = $row->booking_date;
        $sub_array[] = $row->start_time;
        $sub_array[] = $row->end_time;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->c_date));
		if($this->session->userdata('user_type')==1){
        $sub_array[] = $st.' | <a class="btn btn-info btn-sm " href="'.site_url('admin/viewbooking/'.$row->id).'">View </a> | <a class="btn btn-info btn-sm " href="'.site_url('admin/editbooking/'.$row->id).'">Edit </a>';  
		}else{
			$sub_array[] = $st;
		}
		/*new code */
		$artistdata = @$this->db->get_where('tbl_artist',['id'=>$row->artist_id])->row();
		$sub_array[]=@$artistdata->artist_name;
		$sub_array[]=@$artistdata->artist_email;
		$sub_array[]=@$artistdata->artist_contact;
		$sub_array[]=@$artistdata->artist_address.' '.@$artistdata->building_number.' '.@$artistdata->street_number.' '.@$artistdata->town.' '.@$artistdata->city.'-'.@$artistdata->post_code;
		$vanuedata = @$this->db->get_where('tbl_venue',['id'=>$row->venue_id])->row();
		$sub_array[]=empty(@$vanuedata)?'<span class="text text-danger">NA</span>':@$vanuedata->venue_name;
		$sub_array[]=empty(@$vanuedata)?'<span class="text text-danger">NA</span>':@$vanuedata->email;
		$sub_array[]=empty(@$vanuedata)?'<span class="text text-danger">NA</span>':@$vanuedata->contact_no;
		$sub_array[]=empty(@$vanuedata)?'<span class="text text-danger">NA</span>':(@$vanuedata->address.' '.@$vanuedata->building_number.' '.@$vanuedata->street_number.' '.@$vanuedata->town.' '.@$vanuedata->city.'-'.@$vanuedata->post_code);
	
		$guestdata = @$this->db->get_where('tbl_guest',['id'=>$row->guest_id])->row();
		$sub_array[]=empty(@$guestdata)?'<span class="text text-danger">NA</span>':@$guestdata->username;
		$sub_array[]=empty(@$guestdata)?'<span class="text text-danger">NA</span>':@$guestdata->email;
		$sub_array[]=empty(@$guestdata)?'<span class="text text-danger">NA</span>':@$guestdata->contact_no;
		$sub_array[]=empty(@$guestdata)?'<span class="text text-danger">NA</span>':(@$guestdata->building_number.' '.@$guestdata->street_number.' '.@$guestdata->town.' '.@$guestdata->city.'-'.@$guestdata->post_code);
	
	$sub_array[]=$row->quote_price;
	$sub_array[]=$row->booking_date;
	$sub_array[]=$row->c_date;
		if($row->transaction_id!='' && $row->status!=4){
			$sub_array[]='Payment Done';
			
		}else{
			$sub_array[]='<span class="text text-danger">NA</span>';
		}
		/*new code */
		
        //$sub_array[] = $bt;  
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_booking_listing_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_booking_listing_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
  /***************************************************************************
                        booking Listing Page Ends
  ****************************************************************************/
  
  
  /***************************Completed booking Listing starts Here****************/
    
    public function completed_booking_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/completed_booking_list');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_completed_booking(){
    $fetch_data = $this->Adminmodel->fetch_all_completed_booking_listing_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){
        if($row->status >= '5'){
            $st = '<span class="badge badge-pill badge-primary">Completed</span>';
            $bt = '<button type="button" name="hide_completed_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_completed_booking_listing"><i class="fa fa-ban"></i></button>';
        } 
        else{
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            $bt = '<button type="button" name="activate_completed_booking_listing" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_completed_booking_listing"><i class="fa fa-key"></i></button>';
        }

        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->booking_id;
        if($row->artist_id != ''){
          $sub_array[] =  $this->Adminmodel->getFieldWhere('artist_name','tbl_artist','id',$row->artist_id);
        }
        else{
            $sub_array[] = '';
        }
        
        if($row->venue_id != ''){
           $sub_array[] =  $this->Adminmodel->getFieldWhere('venue_name','tbl_venue','id',$row->venue_id);
        }
        else{
             $sub_array[] = '';
        }
        
        if($row->guest_id != ''){
            $sub_array[] =  $this->Adminmodel->getFieldWhere('username','tbl_guest','id',$row->guest_id);
        }
        else{
             $sub_array[] = '';
        }
        
        // $sub_array[] = $row->venue_id;
        // $sub_array[] = $row->guest_id;
        $sub_array[] = $row->category;
        $sub_array[] = $row->booking_date;
        $sub_array[] = $row->start_time;
        $sub_array[] = $row->end_time;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->c_date));
        $sub_array[] = $st;  
        //$sub_array[] = $bt;  
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_completed_booking_listing_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_completed_booking_listing_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
  /***************************************************************************
                        Completed booking Listing Page Ends
  ****************************************************************************/
  /***************************Completed Booking within 24 hours Listing starts Here****************/
    
    public function completed_booking_Wtih24hours_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/completed_booking_with_24hours.php');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_completed_booking_within_24hours(){
    $fetch_data = $this->Adminmodel->fetch_all_completed_booking_within_24hours_listing_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){
        if($row->status >= '5'){
            $st = '<span class="badge badge-pill badge-primary">Completed</span>';
            $bt = '<button type="button" name="hide_completed_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_completed_booking_listing"><i class="fa fa-ban"></i></button>';
        } 
        else{
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            $bt = '<button type="button" name="activate_completed_booking_listing" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_completed_booking_listing"><i class="fa fa-key"></i></button>';
        }

        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->booking_id;
        if($row->artist_id != ''){
          $sub_array[] =  $this->Adminmodel->getFieldWhere('artist_name','tbl_artist','id',$row->artist_id);
        }
        else{
            $sub_array[] = '';
        }
        
        if($row->venue_id != ''){
           $sub_array[] =  $this->Adminmodel->getFieldWhere('venue_name','tbl_venue','id',$row->venue_id);
        }
        else{
             $sub_array[] = '';
        }
        
        if($row->guest_id != ''){
            $sub_array[] =  $this->Adminmodel->getFieldWhere('username','tbl_guest','id',$row->guest_id);
        }
        else{
             $sub_array[] = '';
        }
        
        // $sub_array[] = $row->venue_id;
        // $sub_array[] = $row->guest_id;
        $sub_array[] = $row->category;
        $sub_array[] = $row->booking_date;
        $sub_array[] = $row->start_time;
        $sub_array[] = $row->end_time;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->c_date));
		if($this->session->userdata('user_type')==1){
        $sub_array[] = $st.' | <a class="btn btn-info btn-sm " href="'.site_url('admin/viewbooking/'.$row->id.'/completed_booking_listing').'">View </a> | <a class="btn btn-info btn-sm " href="'.site_url('admin/editbooking/'.$row->id).'">Edit </a>'; 
		}else{
			$sub_array[] = $st;
		}		
        //$sub_array[] = $bt;  
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_completed_booking_within_24hours_listing_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_completed_booking_within_24hours_listing_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
  /***************************************************************************
                        Completed booking with 24 hours Listing Page Ends
  ****************************************************************************/
  
  
  /***************************Allready Paid to artist Listing starts Here****************/
    
    public function already_paid_artist_bookings_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/already_paid_bookings');
        $this->load->view('admin/footer');
    }
    
    public function fetch_already_paid_artist_booking(){
    $fetch_data = $this->Adminmodel->fetch_all_already_paid_artist_listing_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){
        if($row->status==='5'){
            $st = '<span class="badge badge-pill badge-primary">Completed</span>';
            $bt = '<button type="button" name="hide_completed_booking_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_completed_booking_listing"><i class="fa fa-ban"></i></button>';
        } 
        else{
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            $bt = '<button type="button" name="activate_completed_booking_listing" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_completed_booking_listing"><i class="fa fa-key"></i></button>';
        }

        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->booking_id;
        if($row->artist_id != ''){
          $sub_array[] =  $this->Adminmodel->getFieldWhere('artist_name','tbl_artist','id',$row->artist_id);
        }
        else{
            $sub_array[] = '';
        }
        
        if($row->venue_id != ''){
          $sub_array[] =  $this->Adminmodel->getFieldWhere('venue_name','tbl_venue','id',$row->venue_id);
        }
        else{
             $sub_array[] = '';
        }
        
        if($row->guest_id != ''){
            $sub_array[] =  $this->Adminmodel->getFieldWhere('username','tbl_guest','id',$row->guest_id);
        }
        else{
             $sub_array[] = '';
        }
        
        // $sub_array[] = $row->venue_id;
        // $sub_array[] = $row->guest_id;
        $sub_array[] = $row->category;
        $sub_array[] = $row->booking_date;
        $sub_array[] = $row->start_time;
        $sub_array[] = $row->end_time;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->c_date));
		if($this->session->userdata('user_type')==1){
        $sub_array[] = $st.' | <a class="btn btn-info btn-sm " href="'.site_url('admin/viewbooking/'.$row->id.'/already_paid_artist_bookings_listing').'">View </a> | <a class="btn btn-info btn-sm " href="'.site_url('admin/editbooking/'.$row->id).'">Edit </a> '; 
		}else{
			$sub_array[] = $st;
		}		
        //$sub_array[] = $bt;  
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_already_paid_artist_listing_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_already_paid_artist_listing_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
  /***************************************************************************
                        Allready Paid to artist  booking Listing Page Ends
  ****************************************************************************/
  
  
  /***************************venue Without Booking  Listing starts Here****************/
    
    public function venue_without_booking_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/venue_without_booking');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_venue_without_booking(){
    $fetch_data = $this->Adminmodel->fetch_all_venue_without_booking_listing_model();
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){
        if($row->status==='1'){
            $st = '<span class="badge badge-pill badge-primary">Active</span>';
            // $bt = '<button type="button" name="hide_venue_listing" mainid="'.$row->id.'" class="btn btn-danger btn-sm hide_venue_without_booking_listing"><i class="fa fa-ban"></i></button>';
        }
        else{
            $st = '<span class="badge badge-pill badge-danger">InActive</span>';
            // $bt = '<button type="button" name="activate_venue_listing" mainid="'.$row->id.'" class="btn btn-info btn-sm activate_venue_without_booking_listing"><i class="fa fa-key"></i></button>';
        }
        
        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->venue_name;
        $sub_array[] = $row->email;
        $sub_array[] = $row->contact_no;
        $sub_array[] = $row->rating;
        $sub_array[] = $row->venue_bio;
        $sub_array[] = $row->venue_manager_name;
        $sub_array[] = $row->manager_contact_no;
        $sub_array[] = $row->city;
        $sub_array[] = $row->building_number;
        $sub_array[] = $row->street_number;
        $sub_array[] = $row->town;
		if($this->session->userdata('user_type')==1){
        $sub_array[] = $st.'| <a class="btn btn-info btn-sm" href="'.site_url('admin/add_venue/'.$row->id.'/venue_without_booking_listing').'"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>';  
		}else{
			$sub_array[] = $st;
		}
		$sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->added_at));
        // $sub_array[] = $bt;  
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_venue_without_booking_listing_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_venue_without_booking_listing_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
  /***************************************************************************
                        venue Without Booking Listing Page Ends
  ****************************************************************************/
  
  
   /***************************Venue Problem With artist  Listing starts Here****************/
    
    public function venue_problem_with_artist_listing(){
        $this->load->view('admin/header');
        $this->load->view('admin/venue_issue_with_artist');
        $this->load->view('admin/footer');
    }
    
    public function fetch_all_venue_problem_with_artist_booking(){
    $fetch_data = $this->Adminmodel->fetch_all_venue_problem_with_artist_booking_listing_model();  
    $data = array();
    $sn = 1;  
    foreach($fetch_data as $row){
        if($row->issue_status==='1'){
            $st = '<span class="badge badge-pill badge-danger">Resolve</span>';
            $bt = '<button type="button" name="resolve_problem_with_artist" mainid="'.$row->id.'" class="btn btn-info btn-sm resolve_problem_with_artist"><i class="fa fa-key"></i></button>';
        } 
        
        $sub_array = array(); 
        $sub_array[] = $sn++;
        $sub_array[] = $row->booking_id;
        $sub_array[] = $row->artist_name;
        $sub_array[] = $row->artist_email;
        $sub_array[] = $row->artist_contact;
        $sub_array[] = $row->issue_with_artist;
        $sub_array[] = $row->venue_name;
        $sub_array[] = $row->email;
        $sub_array[] = $row->contact_no;
        $sub_array[] = $row->booking_date;
        $sub_array[] = $row->start_time;
        $sub_array[] = $row->end_time;
        $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->c_date));
		if($this->session->userdata('user_type')==1){
        $sub_array[] = $st.' | | <a class="btn btn-info btn-sm " href="'.site_url('admin/viewbooking/'.$row->id.'/venue_problem_with_artist_listing').'">View </a> | <a class="btn btn-info btn-sm " href="'.site_url('admin/editbooking/'.$row->id).'">Edit </a>';  
		}else{
			$sub_array[] = $st;
		}
        $sub_array[] = $bt;  
        $data[] = $sub_array;  
    }  
    $output = array(  
        "draw" =>     intval($this->input->post("draw")),  
        "recordsTotal"  => $this->Adminmodel->get_all_venue_problem_with_artist_listing_model(),  
        "recordsFiltered" => $this->Adminmodel->get_filtered_venue_problem_with_artist_listing_model(),  
        "data" => $data  
    );  
    echo json_encode($output);
    }
    
    //fetch_single
    public function resolve_problem_with_artist_action_taken(){
        $update_data = array(  
            'issue_status' => '2',
            'resolution_action_text'=>$this->input->post('resolution_action_text')
        );  
     $result = $this->Adminmodel->update_venue_problem_with_artist_booking_listing_status($this->input->post("id"), $update_data); 
     if($result){
        echo json_encode(array('success'=>'Issue Resolved Successfully'));
      }
     else{
        echo json_encode(array('error'=>'Fail to Resolve Issue.'));
      }
    }
  
  /***************************************************************************
                        venue Problem With artist Page Ends
  ****************************************************************************/

/***************************Chat Listing  Page starts Here****************/
    
    public function chat_listing_data(){
        $this->load->view('admin/header');
        $this->load->view('admin/chat_listing');
        $this->load->view('admin/footer');
    }

    public function fetch_chat_listing(){
        $factory = (new Factory())->withServiceAccount(__DIR__.'/../../bookme-d5648-firebase-adminsdk-7gh27-e90456d075.json')->withDatabaseUri('https://bookme-d5648.firebaseio.com/');
        $database = $factory->createDatabase();
        if($_POST['search']['value'] != ''){
            $searchData = $database->getReference('chats/'.$_POST['search']['value'])
                    ->getValue();
            $values = ($searchData == '')?[]:[$_POST['search']['value'] => $searchData];
        }else{
            $values = $database->getReference('chats')
                    ->getValue();
        }
        //print_r($values);exit;
        $output = [];
        $sr = 1;
        $data = [];
        foreach($values as $k=>$value){
            $booking = $this->Adminmodel->fetch_booking_details($k);
            $data[] = [
                $sr,
                $booking->booking_id,
                $booking->artist_name,
                $booking->venue_name,
                $booking->username,
                $value['array'][0]['date'],
                '<a title="View Complete Chat" class="view-chat" data-booking="'.$booking->booking_id.'" href="javascript:void(0)"><i class="fa fa-comment"></i></a>',
            ];
            $sr++;
        }

        $output = array(  
            "draw" =>     intval($this->input->post("draw")),  
            "recordsTotal"  => count($values),  
            "recordsFiltered" => count($values),  
            "data" => $data  
        );  
        echo json_encode($output);
    }

    public function fetch_chat_details(){
        if(isset($_REQUEST['booking']) and $_REQUEST['booking'] != ''){
            $factory = (new Factory())->withServiceAccount(__DIR__.'/../../bookme-d5648-firebase-adminsdk-7gh27-e90456d075.json')->withDatabaseUri('https://bookme-d5648.firebaseio.com/');
            $database = $factory->createDatabase();
            $values = $database->getReference('chats/'.$_REQUEST['booking'])
            ->getValue();
            $output = [];
            $sr = 1;
            $html_tr = "";
            foreach($values['array'] as $k=>$value){
                $booking = $this->Adminmodel->fetch_booking_details($_REQUEST['booking']);
                if($value['sent_by'] == 1){
                    $sentBy = $booking->artist_name." (Artist)";
                }else{
                    if($booking->venue_name != ''){
                        $sentBy = $booking->venue_name." (Venue)";
                    }else{
                        $sentBy = $booking->username." (Guest)";
                    }
                }

                if($value['message_type'] == 0){
                    $message = $value['message'];
                }else{
                    $storage = $factory->createStorage();
                    $storageClient = $storage->getStorageClient();
                    $defaultBucket = $storage->getBucket();
                    $expiresAt = new DateTime('tomorrow');
                    $imgLink = $defaultBucket->object('BR202001000069/1')->signedUrl($expiresAt);
                    $message = '<a target="_blank" title="Click to view full image" href="'.$imgLink.'"><img style="width:100px;" src="'.$imgLink.'"></a>';
                }
                
                $receiveBy = 
                $html_tr .= "<tr>".
                            "<td>".$sentBy."</td>".
                            "<td>".$message."</td>".
                            "<td>".$value['date']." ".$value['time']."</td>".
                            "</tr>";
            }
            echo $html_tr;
        }else{
            echo '<tr colspan="3">No chat available!</tr>';
        }
        
    }


    
    // public function fetch_all_venue_problem_with_artist_booking(){
    // $fetch_data = $this->Adminmodel->fetch_all_venue_problem_with_artist_booking_listing_model();  
    // $data = array();
    // $sn = 1;  
    // foreach($fetch_data as $row){
    //     if($row->issue_status==='1'){
    //         $st = '<span class="badge badge-pill badge-danger">Resolve</span>';
    //         $bt = '<button type="button" name="resolve_problem_with_artist" mainid="'.$row->id.'" class="btn btn-info btn-sm resolve_problem_with_artist"><i class="fa fa-key"></i></button>';
    //     } 
        
    //     $sub_array = array(); 
    //     $sub_array[] = $sn++;
    //     $sub_array[] = $row->booking_id;
    //     $sub_array[] = $row->artist_name;
    //     $sub_array[] = $row->artist_email;
    //     $sub_array[] = $row->artist_contact;
    //     $sub_array[] = $row->issue_with_artist;
    //     $sub_array[] = $row->venue_name;
    //     $sub_array[] = $row->email;
    //     $sub_array[] = $row->contact_no;
    //     $sub_array[] = $row->booking_date;
    //     $sub_array[] = $row->start_time;
    //     $sub_array[] = $row->end_time;
    //     $sub_array[] = date('d-M-Y, h:i:s A', strtotime($row->c_date));
    //     $sub_array[] = $st;  
    //     $sub_array[] = $bt;  
    //     $data[] = $sub_array;  
    // }  
    // $output = array(  
    //     "draw" =>     intval($this->input->post("draw")),  
    //     "recordsTotal"  => $this->Adminmodel->get_all_venue_problem_with_artist_listing_model(),  
    //     "recordsFiltered" => $this->Adminmodel->get_filtered_venue_problem_with_artist_listing_model(),  
    //     "data" => $data  
    // );  
    // echo json_encode($output);
    // }
    
    // //fetch_single
    // public function resolve_problem_with_artist_action_taken(){
    //     $update_data = array(  
    //         'issue_status' => '2',
    //         'resolution_action_text'=>$this->input->post('resolution_action_text')
    //     );  
    //  $result = $this->Adminmodel->update_venue_problem_with_artist_booking_listing_status($this->input->post("id"), $update_data); 
    //  if($result){
    //     echo json_encode(array('success'=>'Issue Resolved Successfully'));
    //   }
    //  else{
    //     echo json_encode(array('error'=>'Fail to Resolve Issue.'));
    //   }
    // }
  
  /***************************************************************************
                        Chat Listing  Page Ends
  ****************************************************************************/
public function add_venue($id='',$pageslug=''){
    if(empty($id)){
		redirect(site_url('admin/artist_listing'));
		exit;
	}
    $pagedata = [];
	$pagedata['id']=$id;
	$pagedata['pageslug']=$pageslug;
    if($this->input->post('updatevenue') != ''){
		$error = false;
	/*	$email = $this->input->post('artist_email');
		$checkemail = $this->db->get_where('tbl_artist',['artist_email'=>$email,'id!='=>$id]);
		if($checkemail->num_rows()>0){
			$this->session->set_flashdata('error_msg','Email already used by other artist ');
			$error = true;
		}
		if($this->input->post('user_name')){
			$user_name = $this->input->post('user_name');
			$checkemail = $this->db->get_where('tbl_artist',['user_name'=>$user_name,'id!='=>$id]);
			if($checkemail->num_rows()>0){
				$this->session->set_flashdata('error_msg','Username already used by other artist ');
				$error = true;
			}
		}*/
		if(!$error){
			$post = $this->input->post();
			foreach($post as $key=>$val){
				if($key == 'submit' || $key == 'updatevenue'){
					continue;
				}
				if($key == 'password'){
					$data[$key]=md5($val);
				}else{
					$data[$key]=$val;
				}
			}
			
			$this->db->update('tbl_venue',$data,['id'=>$id]);
			$this->session->set_flashdata('success_msg','Data has been modified success');
		}
    
    }
	
	if(!empty($id)){
		$artist_data = $this->db->get_where('tbl_venue',['id'=>$id])->row();
		$pagedata['admindata'] = $artist_data;
	}
    $this->load->view('admin/header');
    $this->load->view('admin/add_venue',$pagedata);
    $this->load->view('admin/footer');
}
function add_guest($id=''){
	if(empty($id)){
		redirect(site_url('admin/artist_listing'));
		exit;
	}
    $pagedata = [];
	$pagedata['id']=$id;
    if($this->input->post('updatevenue') != ''){
		$error = false;
	/*	$email = $this->input->post('artist_email');
		$checkemail = $this->db->get_where('tbl_artist',['artist_email'=>$email,'id!='=>$id]);
		if($checkemail->num_rows()>0){
			$this->session->set_flashdata('error_msg','Email already used by other artist ');
			$error = true;
		}
		if($this->input->post('user_name')){
			$user_name = $this->input->post('user_name');
			$checkemail = $this->db->get_where('tbl_artist',['user_name'=>$user_name,'id!='=>$id]);
			if($checkemail->num_rows()>0){
				$this->session->set_flashdata('error_msg','Username already used by other artist ');
				$error = true;
			}
		}*/
		if(!$error){
			$post = $this->input->post();
			foreach($post as $key=>$val){
				if($key == 'submit' || $key == 'updatevenue'){
					continue;
				}
				if($key == 'password'){
					$data[$key]=md5($val);
				}else{
					$data[$key]=$val;
				}
			}
			
			$this->db->update('tbl_guest',$data,['id'=>$id]);
			$this->session->set_flashdata('success_msg','Data has been modified success');
		}
    
    }
	
	if(!empty($id)){
		$artist_data = $this->db->get_where('tbl_guest',['id'=>$id])->row();
		$pagedata['admindata'] = $artist_data;
	}
    $this->load->view('admin/header');
    $this->load->view('admin/add_guest',$pagedata);
    $this->load->view('admin/footer');
}
public function editbooking($id='',$repage=''){
    if(empty($id)){
		redirect(site_url('admin/booking_listing'));
		exit;
	}
    $pagedata = [];
	$pagedata['id']=$id;
	$pagedata['repage']=$repage;
    if($this->input->post('booking_id') != ''){
		$error = false;
		if(!$error){
			$post = $this->input->post();
			foreach($post as $key=>$val){
				if($key == 'submit' || $key =='booking_id'){
					continue;
				}
				$data[$key]=$val;
			}
			$this->db->update('tbl_booking',$data,['id'=>$id]);
			$this->session->set_flashdata('success_msg','Data has been modified success');
		}
    }
	
	if(!empty($id)){
		$artist_data = $this->db->get_where('tbl_booking',['id'=>$id])->row();
		$pagedata['admindata'] = $artist_data;
	}
    $this->load->view('admin/header');
    $this->load->view('admin/bookingedit',$pagedata);
    $this->load->view('admin/footer');
}
}
?>