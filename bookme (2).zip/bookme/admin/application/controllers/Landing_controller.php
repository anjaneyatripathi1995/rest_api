<?php 
defined('BASEPATH') or exit('No Direct access allowed');
class Landing_controller extends CI_controller{
    function __construct(){
        parent::__construct();
    }
    
    public function index(){
        echo "welcome";
    }
}
?>