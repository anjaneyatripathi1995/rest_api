<?php include('include/config.php');?>

<style type="text/css"> \

.FaliedArea {

    padding: 0px 0px;

    margin: 65px 0 0 0;

}

#btnOK:hover {
    background: green;
}



.FaliedArea .FailedContent {

    padding: 40px 60px;

    border: 1px solid #eee;

    margin: 0 auto;

    box-shadow: 0 0 5px #EEEEEE;

    border-radius: 3px;

    width: 50%;

    text-align: center;

    background-color: #e85541;

    color: #fff;

}



.FaliedArea .FailedContent img {

    width: 100%;

}



.FaliedArea .FailedContent h2 {

    font-size: 40px;

    margin: 20px 0 10px;

    font-weight: 800;

    color: #fff;

    text-align: center

}



.FaliedArea .FailedContent h5 {

    font-size: 16px;

    margin: 0px 0 20px;

    font-weight: 500;

    color: #fff;

    text-align: center;

    line-height: 27px;

    padding: 0;

}



.FaliedArea .FailedContent p {

    font-size: 23px;

    text-align: center;

    font-weight: 500;

    color: #fff;

    line-height: 27px;

    margin: 0px 0px 15px;

    font-family: Roboto;

}



.FaliedArea .FailedContent ul {

 margin: 0;
 margin-bottom: 23px;
}
}



.FaliedArea .FailedContent ul li {

    display: inline-block;

    padding-right: 5px;

    padding-left: 5px;

    font-weight: 500;

    font-size: 15px;

}



.FaliedArea .FailedContent ul li a {}



@media screen and (max-width: 768px) and (min-width: 200px) {

    .FaliedArea {

        margin: 80px 0 0 0;

    }

    .FaliedArea .FailedContent {

        width: 90%;

        padding: 40px 30px;

    }

    .FaliedArea .FailedContent h2 {

        font-size: 36px;

    }

}

#btnOK{

    font-size: 25px;

    background: #000;

    color: #fff;

    border: none;

    margin-top: 19px;

    padding: 8px 25px 8px 25px;

    cursor: pointer;
    text-decoration: none;

}

</style> 

<div class="FaliedArea">

    <div class="FailedContent">

        <h2>Transaction failed</h2>

        <h5>Sorry,the Sankofa is currently facing issue on the Payment Network. Please try again later</h5>

        <ul>

            <li>

                <i class="fa fa-phone" aria-hidden="true"></i> 858.397.3021

            </li>

            <li>

                <i class="fa fa-envelope-o" aria-hidden="true"></i>customerservice@bookme.com

            </li>

        </ul>

        <a type="button"  href="close://close" value="ok" id="btnOK" onclick=" getValues();ok.performClick(this.value); " >Close</a>

        <div class="clr"></div>

    </div>

    <script>

        function getValues() {

            document.getElementById("btnOK").value = "test";

        }

    </script>

</div>