<?php

if (realpath($_SERVER['SCRIPT_FILENAME']) == realpath(__FILE__)) {
    die('No direct access allowed');
}
session_start();
//error_reporting(0);
//ini_set('max_execution_time', '300000'); //300 seconds = 5 minutes
date_default_timezone_set('Asia/Kolkata');
define('BASE_URL', 'https://api.frcoder.in/bookme/');


    function connect_db(){
    	$dbhost = 'localhost';
    	$dbuser = 'bookme';
    	$dbpass = '+AebQTwb!,#A';
    	$dbname = 'bookme_db';
    	$connect = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
    	$connect->query("SET NAMES 'utf8'");
        if ($connect->connect_error) {
            echo 'Error in db connection'.$connect->connect_error;
        }
        return  $connect;
    	
    }
   $connection= connect_db(); 
$connection->query("SET NAMES 'utf8'"); 

function sanitizeString($var)
{
	global $connection;
	$var = trim($var);
	$var = strip_tags($var);
	$var = htmlentities($var); 
	$var = stripslashes($var);
	return $connection->real_escape_string($var); 
}
function encrypt_decrypt($action, $string) 
{
	$output = false;
	$encrypt_method = "AES-256-CBC";
	$secret_key = 'sdrfg3246576@#%$&$^%gfdf';
	$secret_iv = 'sdrfg3246576@#%$&$^%gfdfsdfgh43567';
	$key = hash('sha256', $secret_key);

	$iv = substr(hash('sha256', $secret_iv), 0, 16);
	if ( $action == 'encrypt' ) {
		$output = openssl_encrypt($string, $encrypt_method, $key, 0, $iv);
		$output = base64_encode($output);
		} else if( $action == 'decrypt' ) {
		$output = openssl_decrypt(base64_decode($string), $encrypt_method, $key, 0, $iv);
	}
	return $output;
}

function getFieldWhere($filed,$tbl,$where,$id){
        $connection = connect_db();
        $statement =  "SELECT $filed AS field FROM $tbl WHERE  $where = '".$id."'";
        $result = $connection->query($statement);
        if($result->num_rows > 0){
            $row = $result->fetch_assoc();
            return (stripslashes($row['field']));   
        }
        else{
            return false;
        }
    }
?>