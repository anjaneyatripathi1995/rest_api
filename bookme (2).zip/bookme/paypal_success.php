    <?php include('include/config.php');
    $statement = "UPDATE tbl_booking SET transaction_id = '".$_POST['txn_id']."',payment_method= 'Paypal' ,transaction_date = '".date('Y:m:d H:i:s')."' WHERE booking_id = '".$_POST['item_number']."'";
    $result = $connection->query($statement);
    ?>
    <div class="" style="text-align:center">
    <style>
    .button {background-color: #4CAF50;border: none;color: white;padding: 15px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer;}
    #btnOK:hover {background: green;}
    #btnOK{font-size: 25px;background: #000;color: #fff;border: none;margin-top: 19px;padding: 8px 25px 8px 25px;cursor: pointer;text-decoration: none;}
    </style>
    
    <h2>Thank You!</h2>
    <h3>Your payment successfully made...</h3>
    <!--<h4>Please check your email for Details & Invoice</h4>-->
    
    <a type="button"  href="close://complete" value="ok" id="btnOK" onclick=" getValues();ok.performClick(this.value); " >Close</a>
    <script>
    function getValues(){
        document.getElementById("btnOK").value = "test";
    }
    
    </script>
    
    </div>