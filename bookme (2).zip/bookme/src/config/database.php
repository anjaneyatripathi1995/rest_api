<?php
    function connect_db(){
    	$dbhost = 'localhost';
    	$dbuser = 'bookme';
    	$dbpass = '+AebQTwb!,#A';
    	$dbname = 'bookme_db';
    	$conn = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
    	$conn->query("SET NAMES 'utf8'");
        if ($conn->connect_error) {
            echo 'Error in db connection'.$conn->connect_error;
        }
        return  $conn;
    	
    }
