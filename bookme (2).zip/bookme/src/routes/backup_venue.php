<?php
error_reporting(-1);
ini_set('display_errors', 1);

/************************************************************************
 * status 
 * 0 = Booking done;
 * 1 = Quote Send;
 * 2 = Counter Offer;
 * 3 = Accepted;
 * 4 = Decline;
 * 5 = Completed;
 * 6 = Payment Done(Not For Now);
**************************************************************************/

// unset cookies
// if (isset($_SERVER['HTTP_COOKIE'])) {
//     $cookies = explode(';', $_SERVER['HTTP_COOKIE']);
//     foreach($cookies as $cookie) {
//         $parts = explode('=', $cookie);
//         $name = trim($parts[0]);
//         setcookie($name, '', time()-1000);
//         setcookie($name, '', time()-1000, '/');
//     }
// }

/********************************************************************************/

$app->get("/venue/artist_details" , function( $request, $response, $args){
  $connection = connect_db();
  $connection->query("SET NAMES 'utf8'");
  $statement = "SELECT id,profile_image,rating,artist_name,artist_bio,artist_price, FROM tbl_artist WHERE status = '1'";
  $result=$connection->query($statement);
  $cat_data = array();
  if($result->num_rows>0){
   while($row = $result->fetch_assoc()){
     $row['profile_image'] = BASE_URL.'uploads/artist_profile/'.$row['profile_image'];
     $cat_data[] = $row;
   }
   $respon = ['success' => true, 'main_category' =>$cat_data];
 }
 else{
   $respon = ['success' => false, 'message' => 'No data found'];
 }

 return $response->withStatus(200)
 ->withHeader("Content-Type", "application/json")
 ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});



/********************************************************************************/

/********************************************************************************/

$app->post("/venue/artist_profile" , function( $request, $response, $args){
  $data = $request->getParsedBody();
  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  $connection->query("SET NAMES 'utf8'");
  $artist_id = $data['artist_id'];
  $statement = "SELECT id,profile_image,rating,artist_name,artist_bio,artist_price,artist_category,artist_equipment FROM tbl_artist WHERE status = '1' and id= $artist_id";
  $result=$connection->query($statement);
  $profile_data = array();
  if($result->num_rows>0){
   while($row = $result->fetch_assoc()){
     $row['profile_image'] = BASE_URL.'uploads/artist_profile/'.$row['profile_image'];
     $profile_data = $row;
   }
   $respon = ['success' => true, 'Profile_data' =>$profile_data];
 }
 else{
   $respon = ['success' => false, 'message' => 'No data found'];
 }

 return $response->withStatus(200)
 ->withHeader("Content-Type", "application/json")
 ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});



/********************************************************************************/

/*******************************************************************************/

$app->post("/venue/fetch_artist_multiple_images" , function( $request, $response, $args){
  $data = $request->getParsedBody();
  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  $connection->query("SET NAMES 'utf8'");
  $artist_id = $data['artist_id'];
  $statement = "SELECT image_path FROM tbl_image WHERE artist_id = $artist_id";
  $result=$connection->query($statement);
  $multiple_images = array();

  if($result->num_rows>0){
   while($row = $result->fetch_assoc()){
     $row['image_path'] = BASE_URL.'uploads/artist_multiple_image/'.$row['image_path'];
     $multiple_images[] = $row['image_path'];
   }
   $respon = ['success' => true, 'multiple_images' =>$multiple_images];
 }

 else{
   $respon = ['success' => false, 'message' => 'No data found'];
 }

 return $response->withStatus(200)
 ->withHeader("Content-Type", "application/json")
 ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/*******************************************************************************/

/********************************************************************************/    
$app->post("/venue/artist_links" , function( $request, $response, $args){
  $data = $request->getParsedBody();
  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  $connection->query("SET NAMES 'utf8'");
  $artist_id = $data['artist_id'];
  $statement = "SELECT artist_video_link FROM tbl_artist WHERE id = $artist_id";
  $result=$connection->query($statement);

  if($result->num_rows>0){
   $row = $result->fetch_assoc();
   $multiple_links = $row['artist_video_link'];
   $respon = ['success' => true, 'links' =>$multiple_links];
 }
 else{
   $respon = ['success' => false, 'message' => 'No data found'];
 }

 return $response->withStatus(200)
 ->withHeader("Content-Type", "application/json")
 ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});


/********************************************************************************/



            $app->post('/venue/signup', function ($request,$response, $args){
              $data = $request->getParsedBody();
              $connection = connect_db();
              $device_type = sanitizeString($data['device_type']);
              $user_name= sanitizeString($data['username']);
              $venue_email = sanitizeString($data['email']);
              $venue_contact = sanitizeString($data['contact_no']);
              $password = md5(sanitizeString($data['password']));
              $venue_name = sanitizeString($data['venue_name']);
            
              $building_number = sanitizeString($data['building_number']);
              $street_number = sanitizeString($data['street_number']);
              $town = sanitizeString($data['town']);
              $city = sanitizeString($data['city']);
              $post_code = sanitizeString($data['post_code']);
            
            
              $venue_bio = sanitizeString(ucwords($data['venue_bio']));
              $manager_name = sanitizeString($data['manager_name']);
              $manager_contact_no = sanitizeString($data['manager_contact_no']);
              $manager_contact_email = sanitizeString($data['manager_contact_email']);
              $alt_manager_name = sanitizeString($data['alt_manager_name']);
              $alt_manager_contact = sanitizeString($data['alt_manager_contact']);
              $alt_manager_contact_email = sanitizeString($data['alt_manager_contact_email']);
              $facilities_available = sanitizeString($data['facilities_available']);
              $size_of_room = sanitizeString($data['size_of_room']);
              $number_of_rooms = sanitizeString($data['number_of_rooms']);
              $device_id = sanitizeString($data['device_id']);
              
                $social_token = sanitizeString($data['social_token']);
                $social_token_type = sanitizeString($data['social_token_type']);
            
              $ip = sanitizeString($request->getServerParam('REMOTE_ADDR'));
            
              $files = $request->getUploadedFiles();
              $directory  =   dirname(__FILE__).'/../../uploads/venue_images/profile_image/';
            
              if(!empty($files)){
                $pic = $files['profile_image'];
                if(!empty($pic) && $pic->getError() === UPLOAD_ERR_OK) {
                 $extension = pathinfo($pic->getClientFilename(), PATHINFO_EXTENSION);
                 $filename = substr(hash('sha256', mt_rand() . microtime()), 0, 20).'_'.'pic'.'.'.strtolower($extension);
                 $v = $directory.$filename;
                 $pic->moveTo($v);
                 $profile_image = '../uploads/venue_images/profile_image/'.$filename;
                 $profile_image = basename($filename);
               }
               else{
                 $respon = ["success" => false, 'message' => "Fail to upload file"];
                 $status = 400;
               }
             }
             else{
              $profile_image ='';
            }
            
                    $statement_urn = $connection->query("SELECT venue_urn FROM tbl_venue ORDER BY id DESC LIMIT 1");
            $urn_result = $statement_urn->fetch_assoc();
            if(empty($urn_result['venue_urn'])){
                $venue_urn = 'V10000';
            }
            else{
                $old_urn = $urn_result['venue_urn'];
                $old_urn++;
                $venue_urn = $old_urn;
            }
        
        $statement = "INSERT INTO tbl_venue(device_type,venue_urn,device_id,username,email,contact_no,password,venue_name,profile_image,building_number,street_number,town,city,post_code,
        venue_manager_name,manager_contact_no,manager_contact_email,venue_bio,alt_manager_name,alt_manager_contact,alt_manager_contact_email,venue_facilities_available,size_of_room,
        ip,number_of_rooms,social_token,social_token_type) 
        VALUES ('$device_type','$venue_urn','$device_id','$user_name','$venue_email','$venue_contact','$password','$venue_name','$profile_image','$building_number','$street_number','$town','$city',
        '$post_code','$manager_name','$manager_contact_no','$manager_contact_email','$venue_bio','$alt_manager_name','$alt_manager_contact','$alt_manager_contact_email',
        '$facilities_available','$size_of_room','$ip','$number_of_rooms','$social_token','$social_token_type')";
        $result = $connection->query($statement);
        if($result == 1){
          $last_id = $connection->insert_id;
          if($last_id){
            $token = generate_token($last_id,$user_name,$venue_email);
            $connection->query("UPDATE tbl_venue SET token = '$token' WHERE id = '$last_id'");
            send_sginup_greeting_mail($venue_email);
            $respon = ['success' => true, 'message' => 'successfully registered','venue_details' =>['venue_id'=>$last_id,'token'=>$token,'name'=>$venue_name,
            'profile_image'=> BASE_URL.'uploads/venue_images/profile_image/'.''.$profile_image]];
          }
          else {
            $respon = ['success' => false, 'message' => 'failed to register a artist'];
          }
        }
        
        else{
          $respon = ['success'=>false,'message'=>'Data could not be inserted'];
        }
        
        return $response->withStatus(200)
        ->withHeader("Content-Type", "application/json")
        ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
        });

/********************************************************************************/

/********************************************************************************/
   $app->post('/venue/socail_login',function ($request , $response ,$args){
       $data = $request->getParsedBody();
       $connection = connect_db();
       $social_token = $data['social_token'];
       $device_type = $data['device_type'];
       $device_id= $data['device_id'];
       if($social_token){
           $statement = "SELECT * FROM tbl_venue WHERE social_token = '".$social_token."'";
           $result = $connection->query($statement);
           if($result->num_rows > 0 ){
                $row = $result->fetch_assoc();
                $token = generate_token($row['id'],$row['username'],$row['email']);
		        $insert_statement = "UPDATE tbl_venue SET token = '$token',device_type='$device_type',device_id = '$device_id' WHERE id= '".$row['id']."'";
		        $insert_query = $connection->query($insert_statement);
		        if($insert_query){
                $respon = ['success'=> true,'message'=>'Login Succesfully','authdata' => ['venue_id'=> $row['id'],'token'=> $token,'name'=> $row['venue_name'], 
                   'email'=> $row['email'],'profile_image'=> BASE_URL.'uploads/venue_images/profile_image/'.''.$row['profile_image']]]; 
		        }
		        else{
		            $respon = ['success'=> false,'message'=>'Some error occurred'];
		        }
           }
           else{
               $respon = ['success'=> false,'message'=>'No data found']; 
           }
       }
       return $response->withStatus(200)
        ->withHeader("Content-Type", "application/json")
       ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
   });

/********************************************************************************/
$app->post('/venue/login',function($request,$response,$args){
  $data = $request->getParsedBody();

  $connection = connect_db();

  $username = $data['username'];
  $password = $data['password'];
  $device_id = $data['device_id'];
  $device_type= $data['device_type'];

  if($username !='' && $password!=''){

    $statement = "SELECT * FROM tbl_venue WHERE username = '".$username."'";
    $result = $connection->query($statement);
    if($result->num_rows > 0){
      $row = $result->fetch_assoc();
      if($row['status']== 1){
        if($row['password'] == md5($password)){
          $token = generate_token($row['id'],$row['username'],$row['email']);
          $insert_statement = "UPDATE tbl_venue SET token = '".$token."',device_type= $device_type,device_id= '".$device_id."' WHERE id= '".$row['id']."'";
          $insert_query = $connection->query($insert_statement);
          if($insert_query == true){
           $respon = ['success'=> true,'message'=>'Login Succesfully','authdata' => ['venue_id'=> $row['id'],'token'=> $token,'name'=> $row['venue_name'], 
           'email'=> $row['email'],'profile_image'=> BASE_URL.'uploads/venue_images/profile_image/'.''.$row['profile_image']]]; 
         }
         else{
          $respon = ['success'=> false,'message'=>'Some error occurred'];
        }
      }

      else{
        $respon = ['success'=> false,'message'=>"Password doesn't match"];
      }
    }
    else{
      $respon=['success'=> false,'message'=>'Your account has been blocked'];  
    }
  }
  else{
    $respon=['success'=> false,'message'=>'This username does not exist'];
  }
}
else{
  $respon=['success'=> false,'message'=>'All fields are required'];
}

return $response->withStatus(200)
->withHeader("Content-Type", "application/json")
->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});



/********************************************************************************/




/********************************************************************************/

$app->post('/venue/check_details', function($request,$response,$args){
  $data = $request->getParsedBody();
  $connection = connect_db();
  $username = sanitizeString($data['username']);
  $email = sanitizeString($data['email']);
  $contact_no = sanitizeString($data['contact_no']);
  if($username != '' || $email != '' || $contact_no != ''){

    $statement = "SELECT * FROM tbl_venue WHERE status = '1'";
    $result = $connection->query($statement);
    if($result->num_rows > 0 ){
      while($row = $result->fetch_assoc()){
        if($row['username'] == $username){
          $respon = ['success'=> false , 'message' => "Username already exist"];
        }
        else if($row['email'] == $email){
          $respon = ['success'=> false , 'message' => "Email already exist"];
        }
        else if( $row['contact_no'] == $contact_no){
          $respon = ['success'=> false , 'message' => "Contact number already exist"];
        }
        else{
          $respon = ['success'=>true, 'message' => "No previous record found"];
        }
      }
    }
    else{
      $respon = ['success' => true, 'message' => "No records exist in database"];
    }
  }
  else{
   $respon = ['success' => false, 'message' => "Fields are required"];
 }

 return $response->withStatus(200)
 ->withHeader("Content-Type", "application/json")
 ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/******************************************************************************/

$app->post("/venue/room_descriptions",function($request,$response,$args){
  $data = $request->getParsedBody();
  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  if($udata){
   $files = $request->getUploadedFiles();
   $directory  =   dirname(__FILE__).'/../../uploads/venue_images/room_detailing_image/';
   if($files['room_image']){
     $room_img = $files['room_image'];
     if(!empty($room_img) && $room_img->getError() === UPLOAD_ERR_OK) {
       $extension = pathinfo($room_img->getClientFilename(), PATHINFO_EXTENSION);
       $filename = substr(hash('sha256', mt_rand() . microtime()), 0, 20).'_'.'room_img'.'.'.strtolower($extension);
       $v = $directory.$filename;
       $room_img->moveTo($v);
       $room_image = '../uploads/venue_images/room_detailing_image/'.$filename;
       $room_image = basename($filename);
     }
     else{
       $respon = ["success" => false, 'message' => "Fail to upload file"];
       $status = 400;
     }
   }
   else{
    $room_image ='';
  }

  $statement = "INSERT INTO tbl_room_detailing(venue_id,room_name,room_size,room_hold,carry_equipment,power,changing_facility,room_image) VALUES('".$udata['id']."',
  '".$data['room_name']."','".$data['room_size']."','".$data['room_hold']."','".$data['carry_equipment']."','".$data['power']."',
  '".$data['changing_facility']."','".$room_image."')";
  $result = $connection->query($statement);

  if($result == 1){

    $respon = ['success'=> true,'message'=> 'Data successfully inserted'];
  }
  else{
    $respon = ['success'=> false,'message'=> 'Data insertion Failed'];
  }
}
else{
 $respon = ['success'=> false,'message'=> 'Authorization refused'];
}
return $response->withStatus(200)
->withHeader("Content-Type", "application/json")
->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/


/******************************************************************************/

$app->get("/venue/fetch_room_descriptions",function($request,$response,$args){
  $data = $request->getParsedBody();
  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  if($udata){
   $a = array();
   $statement = "SELECT id,venue_id,room_image,room_name,room_size,room_hold,carry_equipment,power,changing_facility FROM tbl_room_detailing WHERE venue_id = '".$udata['id']."' and status = 1";
   $result = $connection->query($statement);
   if($result->num_rows > 0){
     while($row = $result->fetch_assoc()){
       $row['room_image'] = BASE_URL.'uploads/venue_images/room_detailing_image/'.$row['room_image'];
       $a[] = $row;
     }
     $respon = ['success'=> true,'message'=>'Data successfully Retrieved','data'=>$a];
   }
   else{
     $respon = ['success'=> false,'message'=> 'NO DATA found'];
   }
 }
 else{
   $respon = ['success'=> false,'message'=> 'Authorization refused'];
 }
 return $response->withStatus(200)
 ->withHeader("Content-Type", "application/json")
 ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/

/******************************************************************************/

$app->post("/venue/delete_room_descriptions",function($request,$response,$args){
  $data = $request->getParsedBody();
  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  if($udata){
    $image_name = $data['image_name'];
    $image_path =   'uploads/venue_images/room_detailing_image/'.$image_name;
    if (file_exists($image_path)){
        $statement = "DELETE FROM tbl_room_detailing WHERE venue_id= '".$udata['id']."' AND room_image = '$image_name'";
        $result = $connection->query($statement);
        unlink($image_path);
         $respon = ['success' => true, 'message' => 'Data has been deleted'];
    }
    else {
         $respon = ['success' => false, 'message' => 'could not delete'];
    }
 }
 else{
   $respon = ['success'=> false,'message'=> 'Authorization refused'];
 }
 return $response->withStatus(200)
 ->withHeader("Content-Type", "application/json")
 ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/


$app->post('/venue/images',function( $request, $response, $args){
  $data = $request->getParsedBody();
  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  $directory  =   'uploads/venue_images/multiple_image/';
  $files = $request->getUploadedFiles();
        // print_r($data); die;
  if($udata){
   $venue_id = $udata['id'];
   $files = $request->getUploadedFiles();
   $error=array();
   $extension=array("jpeg","jpg","png","gif");
   foreach($_FILES["images"]["tmp_name"] as $key=>$tmp_name) {
    $file_name=$_FILES["images"]["name"][$key];
    $file_tmp=$_FILES["images"]["tmp_name"][$key];
    $ext=pathinfo($file_name,PATHINFO_EXTENSION);

    if(in_array($ext,$extension)) {
      $filename=basename($ext);
      $file_name=substr(hash('sha256', mt_rand() . microtime()), 0, 20).'_'.'pic'.'.'.strtolower($filename);
      move_uploaded_file($file_tmp=$_FILES["images"]["tmp_name"][$key],"$directory".$file_name);
      $array_data = $file_name;
      $statement = "INSERT INTO tbl_image (venue_id,image_path) VALUES ('".$venue_id."','".$array_data."')";
      $result = $connection->query($statement);
      if($result == 1){
        $respon = ['success'=> true,'message'=>'successfully inserted'];
      }
      else{
        $respon = ['success'=> true,'message'=>'Error in insertion'];
      }
    }
    else {
      $respon = ['success'=> true,'message'=>'Upload error'];die;
    }
  }
}
else{
 $respon = ['success'=> false,'message'=> 'Authorization refused'];
}

return $response->withStatus(200)
->withHeader("Content-Type", "application/json")
->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/

$app->post('/venue/forgot_password', function( $request , $response ,$args){
  $data = $request->getParsedBody();
  $connection = connect_db();
  $user_email = $data['user_email'];
  if($user_email != ''){
    $statement = "SELECT * FROM tbl_venue where email = '".$user_email."' ";
    $result = $connection->query($statement);
    if($result->num_rows >0 ){
      $row = $result->fetch_assoc();
      if($row['status'] === '1'){
        $token = hashedString();
        $password = randomPassword();
        $converted_password = md5($password);
                //echo $password;
        $statement = "UPDATE tbl_artist SET token = '$token',password = '$converted_password'  WHERE id = '".$row['id']."' AND email = '$user_email'";
        $connection->query($statement);
        //$msg = 'Your Bookme Password is "'.$password.'"';
        $altBody = 'Bookme Password  Reset';
        $mail_send= send_forget_password_mail($user_email, $row['username'], 'Bookme Reset Password', $password, $altBody);
        if($mail_send == true){
          $respon = ['success' => true, 'message' => 'We send a Password on your mail, please check your mail'];
        }
        else{
         $respon = ['success' => true, 'message' => 'Email can not be Sent']; 
       }

     }
     else{
      $respon = ['success' => false, 'message' => 'Your account is blocked'];
    }

  }
  else{
    $respon = ['success'=>false,'message'=>"User email doesn't exist"];
  }

}
else{
  $respon = ['success'=> false,'message'=>'Please fill all data'];
}

return $response->withStatus(200)
->withHeader("Content-Type", "application/json")
->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/

/********************************************************************************/

$app->post('/venue/forgot_username', function( $request , $response ,$args){
  $data = $request->getParsedBody();
  $connection = connect_db();
  $user_email = $data['user_email'];
  if($user_email != ''){
    $statement = "SELECT * FROM tbl_venue where email = '".$user_email."' ";
    $result = $connection->query($statement);
    if($result->num_rows >0 ){
      $row = $result->fetch_assoc();
      //$msg = 'Your Username "'.$row['username'].'"';
      $altBody = 'Your Username';
      $mail_send= send_forget_username_mail($user_email, $row['username'], 'Your Username', $row['username'], $altBody);
      if($mail_send == true){
       $respon = ['success' => true, 'message' => 'We send your username on your mail, please check your mail'];
     }
     else{
       $respon = ['success' => true, 'message' => 'Email can not be Sent']; 
     }
   }
   else{
    $respon = ['success'=>false,'message'=>"User email doesn't exist"];
  }

}
else{
  $respon = ['success'=> false,'message'=>'Please fill all data'];
}

return $response->withStatus(200)
->withHeader("Content-Type", "application/json")
->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/


/********************************************************************************/

$app->get("/venue/venue_profile" , function( $request, $response, $args){
  $data = $request->getParsedBody();
  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  $connection->query("SET NAMES 'utf8'");
  $statement = "SELECT * FROM tbl_venue WHERE id = '".$udata['id']."'";
  $result=$connection->query($statement);
  $profile_data = array();
  if($result->num_rows>0){
   while($row = $result->fetch_assoc()){
     $row['profile_image'] = BASE_URL.'uploads/venue_images/profile_image/'.$row['profile_image'];
     $profile_data = $row;
   }
   $respon = ['success' => true, 'venue_profile' =>$profile_data];
 }
 else{
   $respon = ['success' => false, 'message' => 'No data found'];
 }

 return $response->withStatus(200)
 ->withHeader("Content-Type", "application/json")
 ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/

/********************************************************************************/

$app->post("/venue/filter_data", function($request,$response,$args){
  $data = $request->getParsedBody();

  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  $connection->query("SET NAMES 'utf8'");
   
    $venue_query=$connection->query("SELECT * FROM tbl_venue WHERE id ='".$udata['id']."'");
    if($venue_query->num_rows > 0){
        $venue_data =  $venue_query->fetch_assoc();
        $venue_address = $venue_data['address'].' '.$venue_data['building_number'].' '.$venue_data['street_number'].' '.$venue_data['town'].' '.$venue_data['city'].' '.$venue_data['post_code'];
        $venue_lat_lang= getLatLong($venue_address);
        $venue_distance_data = array();
        $venue_distance_data['venue_lat'] = $venue_lat_lang['latitude'];
        $venue_distance_data['venue_lang'] = $venue_lat_lang['longitude'];
    }
    
    $whr='';
      if(!empty($data['date'])){
        $date = $data['date'];
        $whr.= "AND(tbl_artist_unavailability.unavailability_date IS NULL OR tbl_artist_unavailability.unavailability_date not like '%$date%')";
        //OR tbl_artist_unavailability.unavailability_date is NULL 
    }
      
    if(!empty($data['equipment'])){
          $equipment = $data['equipment'];
           $whr.= "AND tbl_artist.artist_equipment like '%$equipment%'";
           //$whr.= "AND FIND_IN_SET('$equipment',tbl_artist.artist_equipment)";
    }
          
    
    if(!empty($data['artist_name'])){
        $artist_name = $data['artist_name'];
        $whr.= "AND tbl_artist.artist_name like '%$artist_name%' ";
    }
    
    if(!empty($data['category_name'])){
        $category_name = $data['category_name'];
        if($category_name = 'other'){
            $category_id = $data['category_id'];
            $whr.= " AND tbl_artist_categories.category_id like '%$category_id%'";
        }
        else{
          $whr.= " AND tbl_artist_categories.category_name like '%$category_name%'";   
        }
    }
  //AS cat_name
  if($udata){
    $statement ="SELECT tbl_artist.id,tbl_artist.artist_equipment,tbl_artist.artist_travel,tbl_artist.artist_address,tbl_artist.building_number,tbl_artist.street_number,tbl_artist.town,tbl_artist.city,tbl_artist.post_code,
    tbl_artist.profile_image,tbl_artist.rating,tbl_artist.artist_bio,tbl_artist.artist_price,tbl_artist.artist_name,tbl_artist_unavailability.artist_id,tbl_artist_unavailability.unavailability_date,
    tbl_artist_categories.artist_id,tbl_artist_categories.category_id,tbl_artist_categories.category_name AS cat_name
    FROM tbl_artist
    LEFT JOIN tbl_artist_unavailability
    ON tbl_artist_unavailability.artist_id = tbl_artist.id
    LEFT JOIN tbl_artist_categories
    ON tbl_artist_categories.artist_id = tbl_artist_unavailability.artist_id
    WHERE tbl_artist.status = 1 $whr group by tbl_artist.id";
    // echo $statement;
    // die;
    $result = $connection->query($statement);


    $a = array();
    if($result->num_rows > 0 ){
     while($row = $result->fetch_assoc()){
        $statement_new = "SELECT * FROM tbl_booking WHERE artist_id ='".$row['artist_id']."' and ((status = 7 or status = 3) and transaction_id !='NULL') and booking_date = '$date'";
        $result_new = $connection->query($statement_new);
        if($result_new->num_rows > 0){
            $row_new = $result_new->fetch_assoc();
            $booking_unavailability_date = $row_new['booking_date'];
        }
        else{
            $booking_unavailability_date = 'NULL';
        }
        
        $artist_address =  $row['artist_address'].' '.$row['building_number'].' '.$row['street_number'].' '.$row['town'].' '.$row['city'].' '.$row['post_code'];
        $artist_lat_lang = getLatLong($artist_address);
        $artist_distance_data = array();
        $artist_distance_data['artist_lat'] = $artist_lat_lang['latitude'];
        $artist_distance_data['artist_lang'] = $artist_lat_lang['longitude'];
        $row['profile_image'] = BASE_URL.'uploads/artist_profile/'.$row['profile_image'];
        $total_distance = calculate_distance($artist_distance_data['artist_lat'] ,$artist_distance_data['artist_lang'],
        $venue_distance_data['venue_lat'] ,$venue_distance_data['venue_lang'],'M');
                if($total_distance <= $row['artist_travel']){
                    $row['booking_unavailability_date'] = $booking_unavailability_date;
                    $a[] = $row;
                 }
                }
                 $respon = ['success'=>true,'message'=>'Data successfullly retrived','data'=>$a];
               }
               else{
                $respon = ['success'=>true,'message'=>'No data found'];
              }
            }
            else{
             $respon = ['success' => false, 'message' => 'Authorization failed'];
            }

return $response->withStatus(200)
->withHeader("Content-Type", "application/json")
->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/


/********************************************************************************/


$app->get("/venue/fetch_multiple_images" , function( $request, $response, $args){
  $data = $request->getParsedBody();
  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  $connection->query("SET NAMES 'utf8'");
  $statement = "SELECT image_path FROM tbl_image WHERE venue_id = '".$udata['id']."'";
  $result=$connection->query($statement);
  $multiple_images = array();

  if($result->num_rows>0){
   while($row = $result->fetch_assoc()){
     $row['image_path'] = BASE_URL.'uploads/venue_images/multiple_image/'.$row['image_path'];
     $multiple_images[] = $row['image_path'];
   }
   $respon = ['success' => true, 'multiple_images' =>$multiple_images];
 }

 else{
   $respon = ['success' => false, 'message' => 'No data found'];
 }

 return $response->withStatus(200)
 ->withHeader("Content-Type", "application/json")
 ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/

/********************************************************************************/
  $app->post("/venue/delete_multiple_images" , function( $request, $response, $args){
      $data = $request->getParsedBody();
      $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
      $connection = connect_db();
      $connection->query("SET NAMES 'utf8'");
    if($udata){
        $image_name = $data['image_name'];
        $image_path =   'uploads/venue_images/multiple_image/'.$image_name;
        if (file_exists($image_path)){
            $statement = "DELETE FROM tbl_image WHERE venue_id= '".$udata['id']."' AND image_path = '$image_name'";
            $result = $connection->query($statement);
            unlink($image_path);
            $respon = ['success' => true, 'message' => 'File '.$image_path.' has been deleted'];
        }
        else {
         $respon = ['success' => false, 'message' => 'could not delete '.$image_path.', file does not exist'];
        }
    }
    else{
          $respon = ['success'=> false,'message'=> 'Authorization refused'];
    }
    return $response->withStatus(200)
    ->withHeader("Content-Type", "application/json")
    ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
  });
/********************************************************************************/


/********************************************************************************/


$app->post("/venue/update_password" , function( $request, $response, $args){
  $data = $request->getParsedBody();
  $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
  $connection = connect_db();
  $connection->query("SET NAMES 'utf8'");

  $old_password = md5($data['old_pass']);
  $new_password = md5($data['new_pass']);


  $statement = "SELECT * FROM tbl_venue WHERE id = '".$udata['id']."'";
  $result = $connection->query($statement);

  if($result->num_rows > 0){
   $row = $result->fetch_assoc();
   if($row['password'] == $old_password ){
     $statement_new = "UPDATE tbl_venue SET password = '".$new_password."' WHERE id = '".$udata['id']."'";
     $result_new = $connection->query($statement_new);

     if($result_new == 1){
      $respon = ['success'=> true,'message'=> 'Password updated successfully'];
    }
    else{
      $respon = ['success'=> true,'message'=> 'Password can not be updated']; 
    }

  }
  else{
   $respon = ['success'=> false, 'message'=> "Old password doesn't match"];
 }
}

else{
 $respon = ['success' => false, 'message' => 'No data found'];
}

return $response->withStatus(200)
->withHeader("Content-Type", "application/json")
->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/



/********************************************************************************/



$app->post('/venue/booking', function ($request,$response, $args){
      $data = $request->getParsedBody();
      $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
      $connection = connect_db();
        
      $venue_id= $udata['id'];
      $artist_id = sanitizeString($data['artist_id']);
      $category = sanitizeString($data['category']);
      $date = sanitizeString($data['date']);
      $start_time = sanitizeString($data['start_time']);
      $end_time = sanitizeString($data['end_time']);
      $description = sanitizeString($data['description']);
      $equipment = sanitizeString($data['equipment']);
      
      
      $room_id = sanitizeString($data['room_id']);
      $room_name = sanitizeString($data['room_name']);
      
      $status=0;          
      
      $booking_query = "SELECT * FROM tbl_booking where artist_id = '".$artist_id."' and booking_date = '".$date."' and (status ='3' or status ='7')";
      //old $booking_query = "SELECT * FROM tbl_booking where artist_id = '".$artist_id."' and booking_date = '".$date."' and (status ='3' or status ='5' or status ='6')";
      $booking = $connection->query($booking_query);
      if($booking->num_rows > 0){
         $respon = ['success' => false, 'message' => 'Artist is already booked'];
      }
      else{
          $booking_id_query = "SELECT booking_id FROM tbl_booking ORDER BY id DESC LIMIT 1";
          $booking_id_data = $connection->query($booking_id_query);
          $booking_id_previous = $booking_id_data->fetch_assoc();
          $previous_booking = $booking_id_previous['booking_id'];
          $database_month  = substr($booking_id_previous['booking_id'], -8,2);
          $month = date('m');
          if(empty($previous_booking)){
            $booking_id ='BR'.date('Y').date('m').'000001';     
          }
          else{
            if($database_month == date('m')){
              //$new_booking = substr($previous_booking,-6);
              $booking_id_last = $previous_booking;
              $booking_id_last++;
              $booking_id = $booking_id_last;
            }
            else{
                $booking_id ='BR'.date('Y').date('m').'000001';
            }
          }
           //$booking_id ='BR'. strtoupper(substr(uniqid(sha1(time())),0,4)). mt_rand();
      
      $statement = "INSERT INTO tbl_booking set booking_id='$booking_id',venue_id='$venue_id',artist_id='$artist_id',category='$category',booking_date='$date',
      description= '$description',equipment='$equipment',start_time='$start_time',end_time='$end_time',status='$status',room_id='$room_id',room_name = '$room_name'";
      $result = $connection->query($statement);
      $last_id = $connection->insert_id;
      if($result == 1){
         $fetch_statement_booking= "SELECT booking_id FROM tbl_booking WHERE id = '".$last_id."'";
         $result_booking = $connection->query($fetch_statement_booking);
         if($result_booking->num_rows > 0){
             $row_new = $result_booking->fetch_assoc();
         }
         
         $fetch_statement = "SELECT device_id,device_type FROM tbl_artist WHERE id = '".$artist_id."'";
         $result = $connection->query($fetch_statement);
         if($result->num_rows > 0){
           $row = $result->fetch_assoc();
         }
        if($row['device_type'] == 1){
             $body = 'You have a new booking';
             $title =  'Booking';
             $device_id = $row['device_id'];
             push_notification_android_booking($device_id,$body,$title,$row_new['booking_id']);  
        }
        else{
             $body = 'You have a new booking';
             $title =  'Booking';
             $device_id = $row['device_id'];
             push_notification_ios_booking($device_id,$body,$title,$row_new['booking_id']);  
        }
        
        $respon = ['success' => true, 'message' => 'Booking successfully'];
      }
      else{
        $respon = ['success'=>false,'message'=>'Data could not be inserted'];
      }
    }  


  return $response->withStatus(200)
  ->withHeader("Content-Type", "application/json")
  ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/

/********************************************************************************/


    $app->get("/venue/my_booking" , function( $request, $response, $args){
            $data = $request->getParsedBody();
        	$udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
        	$connection = connect_db();
            $connection->query("SET NAMES 'utf8'");
            $statement = "SELECT * FROM tbl_booking WHERE venue_id = '".$udata['id']."' ORDER BY c_date DESC ";
            $result = $connection->query($statement);
            $a = array();
            $image_array = array();
        	if($result->num_rows > 0){
        	    while($row = $result->fetch_assoc()){
        	        $statement_images = "SELECT image_path FROM tbl_image WHERE artist_id = '".$row['artist_id']."'";
        	        $result_images = $connection->query($statement_images);
        	        if($result_images->num_rows > 0){
        	            while($multiple_image = $result_images->fetch_assoc()){
        	              $image_array[] = BASE_URL.'uploads/artist_multiple_image/'.$multiple_image['image_path'];  
        	            }
        	        }
        	        $statement_new = "SELECT artist_name,profile_image FROM tbl_artist WHERE id = '".$row['artist_id']."'";
        	         $result_new = $connection->query($statement_new);
        	         if($result_new->num_rows > 0){
            	         $row_new = $result_new->fetch_assoc();
            	         $row['artist_name'] = $row_new['artist_name'];
            	         $row['profile_image'] = BASE_URL.'uploads/artist_profile/'.$row_new['profile_image'];
            	         $row['multiple_image'] = $image_array;
        	         }
        	         $a[] = $row;
        	    }
        	    $respon = ['success' => true, 'message' => 'Data successfully retrieved','data'=>$a];
        	}
        	
        	else{
        	    $respon = ['success' => false, 'message' => 'No data found'];
        	}
    	
          return $response->withStatus(200)
    	->withHeader("Content-Type", "application/json")
    	->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
      });

/********************************************************************************/

/********************************************************************************/


    $app->post("/venue/accept_decline" , function( $request, $response, $args){
      $data = $request->getParsedBody();
      $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
      $connection = connect_db();
      $connection->query("SET NAMES 'utf8'");
      $booking_id = $data['booking_id'];
      $status  =  $data['status'];
      //$quote_price = $data['quote_price'];
      $quote_price = "NULL";
      $title ="Booking Status";
      $sbuject = "Booking status";
      $artist_id = getFieldWhere('artist_id','tbl_booking','booking_id',$booking_id);
      $booking_date = getFieldWhere('booking_date','tbl_booking','booking_id',$booking_id);
      $venue_name = getFieldWhere('venue_manager_name','tbl_venue','id',$udata['id']);
      
      if($artist_id != ''){
        $artist_name = getFieldWhere('artist_name','tbl_artist','id',$artist_id);
        $artist_device_type = getFieldWhere('device_type','tbl_artist','id',$artist_id);
        $artist_device_id = getFieldWhere('device_id','tbl_artist','id',$artist_id);
        $artist_email = getFieldWhere('artist_email','tbl_artist','id',$artist_id);
        
        if($status==3){
            $body = "Hello $artist_name , Your booking is accepted";
            send_booking_status_email($udata['email'],$venue_name,$artist_name,$booking_date,$sbuject,$booking_id);
            send_booking_status_email($artist_email,$artist_name,$venue_name,$booking_date,$sbuject,$booking_id);
        }
        if($status==4){
         $body = "Hello $artist_name , Your booking is declined from the venue side";  
        }
        
        // if($status==7){
        //   $body = "Hello $venue_name , Your booking is Canceled from the venue side";  
        // }
        
      }
      if($udata){
          if($status){
            $statement = "UPDATE tbl_booking SET status = '".$status."' WHERE booking_id = '".$booking_id."' ";
            $result = $connection->query($statement);
            if($result){
                $respon = ['success'=> true,'message'=> 'Data successfully inserted'];
                gig_counter_nofication($artist_device_id,$artist_device_type,$quote_price,$title,$body,$booking_id); 
            }
            else{
                $respon = ['success'=> false,'message'=> 'Some error occured'];
            }
          }
          
          
        /*  else{
             $statement = "UPDATE tbl_booking SET status = 2 WHERE booking_id = '".$booking_id."'";
             
             if($result){
                $respon = ['success'=> true,'message'=> 'Data successfully inserted'];
            }
            else{
                $respon = ['success'=> false,'message'=> 'Some Error Occured'];
            }
            
          }*/
          
      }
      else{
            $respon = ['success'=> false,'message'=> 'Authorization refused'];
      }
    
     return $response->withStatus(200)
     ->withHeader("Content-Type", "application/json")
     ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
    });

/********************************************************************************/

/********************************************************************************/


    $app->post("/venue/booking_detail" , function( $request, $response, $args){
      $data = $request->getParsedBody();
      $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
      $connection = connect_db();
      $connection->query("SET NAMES 'utf8'");
      $booking_id = $data['booking_id'];
      $a = array();
      if($udata){
          $statement = "SELECT * FROM tbl_booking WHERE booking_id = '".$booking_id."'";
          $result = $connection->query($statement);
          if($result->num_rows > 0){
              $row = $result->fetch_assoc();
              $statement_new = "SELECT artist_name,artist_bio,profile_image FROM tbl_artist WHERE id= '".$row['artist_id']."'";
              $result_new = $connection->query($statement_new);
              $row_new = $result_new->fetch_assoc();
              $row['artist_name'] = $row_new['artist_name'];
              $row['artist_bio'] = $row_new['artist_bio'];
              $row['profile_image'] = BASE_URL.'uploads/artist_profile/'. $row_new['profile_image'];
              
               $detail= "SELECT * FROM tbl_booking_quotation WHERE booking_id = '".$booking_id."'";
               $booking = $connection->query($detail);
               $booking_detail = $booking->fetch_assoc();
               $row['venue_counter_offer']=$booking_detail['venue_counter_offer'];
               $row['artist_quote_offer']=$booking_detail['artist_quote_offer'];
              $a[] = $row;
              $respon = ['success'=> true,'message'=> 'Data successfully retrieved','booking_data'=>$a]; 
          }
          else{
            $respon = ['success'=> false,'message'=> 'No data found'];  
          }
      }
      else{
            $respon = ['success'=> false,'message'=> 'Authorization refused'];
        }
    
     return $response->withStatus(200)
     ->withHeader("Content-Type", "application/json")
     ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
    });

/********************************************************************************/

/********************************************************************************/
  $app->post("/venue/review", function( $request, $response, $args){
          $data = $request->getParsedBody();
          //$udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
          $connection = connect_db();
          $connection->query("SET NAMES 'utf8'");
          
          $venue_id =  $data['venue_id'];
          $guest_id =   $data['guest_id'];
          $artist_id =  $data['artist_id'];
          $booking_id = $data['booking_id'];
          $comments = $data['comments'];
          $rating= $data['rating'];
          $rating_2= $data['rating_2'];
          $rating_3= $data['rating_3'];
          
          if($artist_id){
            if($venue_id != ''){ 
                $statement = "INSERT INTO tbl_artist_reviews SET artist_id='$artist_id',venue_id = '$venue_id',comments = '$comments' ,rating = '$rating',rating_2='$rating_2',
                rating_3='$rating_3',booking_id = '$booking_id'";
                $result = $connection->query($statement);
                
                $statement = "SELECT * FROM tbl_artist_reviews WHERE artist_id = '$artist_id'";
                  $result_rating = $connection->query($statement);
                  if($result_rating->num_rows >0){
                            $total_rating = 0;
                            $ave_rating = 0 ;
                        while($rating_data = $result_rating->fetch_assoc()){
                            $total_rating =  $total_rating + $rating_data['rating']+$rating_data['rating_2']+$rating_data['rating_3'];
                            $ave_rating = $total_rating /($result_rating->num_rows * 3);
                        } 
                    $ave_rating = round($ave_rating,2);
                  }
                   $insert_statement = "UPDATE tbl_artist SET rating ='".$ave_rating."' WHERE id= '$artist_id'";
                   $insert_result = $connection->query($insert_statement);
            }
            if($guest_id !=''){
                $statement = "INSERT INTO tbl_artist_reviews SET artist_id='$artist_id',guest_id = '$guest_id',comments = '$comments' ,rating = '$rating',rating_2='$rating_2',
                rating_3='$rating_3',booking_id = '$booking_id'";
                $result = $connection->query($statement);
                
                $statement = "SELECT * FROM tbl_artist_reviews WHERE artist_id = '$artist_id'";
                  $result_rating = $connection->query($statement);
                  if($result_rating->num_rows >0){
                            $total_rating = 0;
                            $ave_rating = 0 ;
                        while($rating_data = $result_rating->fetch_assoc()){
                            $total_rating =  $total_rating + $rating_data['rating']+$rating_data['rating_2']+$rating_data['rating_3'];
                            $ave_rating = $total_rating /($result_rating->num_rows * 3);
                        } 
                    $ave_rating = round($ave_rating,2);
                  }
                   $insert_statement = "UPDATE tbl_artist SET rating ='".$ave_rating."' WHERE id= '$artist_id'";
                   $insert_result = $connection->query($insert_statement);
                   
            }

            if($result){
                $statement1 = "UPDATE tbl_booking  SET status = '8' WHERE booking_id = '$booking_id'";
                $result_new = $connection->query($statement1);
               $respon = ['success' => true, 'message' => 'Successfully inserted'];
            }
            else{
        	    $respon = ['success' => false, 'message' => 'Error occured'];
        	}
          }
          else{
            $respon = ['success'=> false,'message'=> 'Artist id is empty'];
           }
        
        return $response->withStatus(200)
    	->withHeader("Content-Type", "application/json")
    	->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
  });

/********************************************************************************/

/********************************************************************************/
  $app->get("/venue/get_review", function( $request, $response, $args){
          $data = $request->getParsedBody();
          $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
          $connection = connect_db();
          $connection->query("SET NAMES 'utf8'");
          if($udata){
             $statement = "SELECT * FROM tbl_reviews WHERE venue_id = '".$udata['id']."'";
             $result = $connection->query($statement);
             $a = array();
             if($result->num_rows > 0){
                 while($row = $result->fetch_assoc()){
                    if($row['artist_id'] != ''){
                            $artist_name = getFieldWhere('artist_name','tbl_artist','id',$row['artist_id']);
                            $artist_profile_image = getFieldWhere('profile_image','tbl_artist','id',$row['artist_id']);
                            $row['artist_name'] = $artist_name;
                            //$newDate = date("d/m/y,h:i a", strtotime($row['added_at']));
                            $row['date'] = date("d-m-Y", strtotime($row['added_at']));
                            $row['time'] = date("H:i:s", strtotime($row['added_at']));
                            $row['artist_profile_image'] = BASE_URL.'uploads/artist_profile/'.$artist_profile_image;
                    } 
                    $a[] = $row;  
                 }
                $respon = ['success' => true, 'message' => 'Data retrieved','rating_data'=> $a]; 
            }
             else{
                 $respon = ['success' => true, 'message' => 'No data found']; 
             }
          }
          else{
            $respon = ['success'=> false,'message'=> 'Authorization refused'];
           }
        
        return $response->withStatus(200)
    	->withHeader("Content-Type", "application/json")
    	->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
  });

/********************************************************************************/


/********************************************************************************/


    $app->post("/venue/bookings_by_status" , function( $request, $response, $args){
            $data = $request->getParsedBody();
            $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
            $connection = connect_db();
            $connection->query("SET NAMES 'utf8'");
        	$booking_date = $data['booking_date'];
            $statement = "SELECT * FROM tbl_booking WHERE venue_id = '".$udata['id']."' AND booking_date = '$booking_date' ORDER BY c_date DESC ";
            $result = $connection->query($statement);
            $a = array();
        	if($result->num_rows > 0){
        	    while($row = $result->fetch_assoc()){
        	        $statement_new = "SELECT artist_name,profile_image FROM tbl_artist WHERE id = '".$row['artist_id']."'";
        	         $result_new = $connection->query($statement_new);
        	         if($result_new->num_rows > 0){
            	         $row_new = $result_new->fetch_assoc();
            	         $row['artist_name'] = $row_new['artist_name'];
            	         $row['profile_image'] = BASE_URL.'uploads/artist_profile/'.$row_new['profile_image'];
        	         }
        	         $a[] = $row;
        	    }
        	    $respon = ['success' => true, 'message' => 'Data successfully Retrieved','data'=>$a];
        	}
        	
        	else{
        	    $respon = ['success' => false, 'message' => 'No data found'];
        	}
    	
          return $response->withStatus(200)
    	->withHeader("Content-Type", "application/json")
    	->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
      });

/********************************************************************************/


/********************************************************************************/
       $app->post('/venue/update_profile', function ($request,$response, $args){
            $data = $request->getParsedBody();
            $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
            $connection = connect_db();
            $connection->query("SET NAMES 'utf8'");
            $venue_name = sanitizeString($data['venue_name']);
            $venue_bio = sanitizeString(ucwords($data['venue_bio']));
            $manager_name = sanitizeString($data['manager_name']);
            $manager_contact_no = sanitizeString($data['manager_contact_no']);
            $manager_contact_email = sanitizeString($data['manager_contact_email']);
            $building_number = sanitizeString($data['building_number']);
            $street_number = sanitizeString($data['street_number']);
            $town = sanitizeString($data['town']);
            $city = sanitizeString($data['city']);
            $post_code = sanitizeString($data['post_code']);
            $facilities_available = sanitizeString($data['facilities_available']);
            $venue_email = sanitizeString($data['email']);
            $venue_contact = sanitizeString($data['contact_no']);
            $ip = sanitizeString($request->getServerParam('REMOTE_ADDR'));
            $files = $request->getUploadedFiles();
            $directory  =   dirname(__FILE__).'/../../uploads/venue_images/profile_image/';

            if($udata){
                $statement_venue = "SELECT token,profile_image,username FROM tbl_venue where id='".$udata['id']."'";
                $result_venue = $connection->query($statement_venue);
                if($result_venue->num_rows > 0){
                    $row = $result_venue->fetch_assoc();
                    //print_r($row);die;
                    $image_path  =   BASE_URL.'uploads/venue_images/profile_image/'.$row['profile_image'];
                    $token = $row['token'];
                    $user_name= $row['username'];
                }
                if(!empty($files)){
                $pic = $files['profile_image'];
                if(!empty($pic) && $pic->getError() === UPLOAD_ERR_OK) {
                 $extension = pathinfo($pic->getClientFilename(), PATHINFO_EXTENSION);
                 $filename = substr(hash('sha256', mt_rand() . microtime()), 0, 20).'_'.'pic'.'.'.strtolower($extension);
                 $v = $directory.$filename;
                 $pic->moveTo($v);
                 $profile_image = '../uploads/venue_images/profile_image/'.$filename;
                 $profile_image = basename($filename);
               }
               else{
                 $respon = ["success" => false, 'message' => "Fail to upload file"];
                 $status = 400;
               }
             }
             else{
              $profile_image ='';
            }
            $check_mail_statement = $connection->query("SELECT * FROM tbl_venue WHERE email ='$venue_email' and id != '".$udata['id']."'");
            // echo "SELECT * FROM tbl_venue WHERE email ='$venue_email' and id != '".$udata['id']."'";
            // die;
            if($check_mail_statement->num_rows > 0){
                $respon = ['success'=>false,'message'=>'Email already exist'];
                  return $response->withStatus(200)
                ->withHeader("Content-Type", "application/json")
                ->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
            }
            
            if($profile_image===''){
            $token = generate_token($udata['id'],$user_name,$venue_email);
            $result= $connection->query("UPDATE tbl_venue SET token ='$token',email='$venue_email',contact_no='$venue_contact',venue_name='$venue_name',building_number='$building_number',
               street_number='$street_number',town='$town',city='$city',post_code='$post_code',venue_manager_name='$manager_name',manager_contact_no='$manager_contact_no',
               manager_contact_email='$manager_contact_email',venue_bio='$venue_bio',venue_facilities_available='$facilities_available',ip='$ip' WHERE id='".$udata['id']."'");
            }   
            else{
            $token = generate_token($udata['id'],$user_name,$venue_email);
            $result= $connection->query("UPDATE tbl_venue SET token ='$token',email='$venue_email',contact_no='$venue_contact',venue_name='$venue_name',profile_image='$profile_image',building_number='$building_number',
               street_number='$street_number',town='$town',city='$city',post_code='$post_code',venue_manager_name='$manager_name',manager_contact_no='$manager_contact_no',
               manager_contact_email='$manager_contact_email',venue_bio='$venue_bio',venue_facilities_available='$facilities_available',ip='$ip' WHERE id='".$udata['id']."'");
            }

        //$result = $connection->query($statement); 
       if($result == 1){
           $respon = ['success' => true, 'message' => 'successfully updated','token'=>$token];
        }
        else{
          $respon = ['success'=>false,'message'=>'Data could not be inserted'];
        }
       }
    else{
            $respon = ['success'=> false,'message'=> 'Authorization refused'];
        }

return $response->withStatus(200)
->withHeader("Content-Type", "application/json")
->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
});

/********************************************************************************/

/********************************************************************************/
   
     $app->post("/venue/venue_booking_cancel", function( $request, $response, $args){
        $data = $request->getParsedBody();
        $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
        $connection = connect_db();
        $connection->query("SET NAMES 'utf8'");
        $booking_id = $data['booking_id'];
        $status = $data['status'];
        $reason_of_cancel = $data['reason_of_cancel'];
        $title ="Booking Canceled";
        $artist_id = getFieldWhere('artist_id','tbl_booking','booking_id',$booking_id);
       $booking_date = getFieldWhere('booking_date','tbl_booking','booking_id',$booking_id);
       $venue_name = getFieldWhere('venue_manager_name','tbl_venue','id',$udata['id']);
        if($artist_id != ''){
            $artist_name = getFieldWhere('artist_name','tbl_artist','id',$artist_id);
            $artist_device_type = getFieldWhere('device_type','tbl_artist','id',$artist_id);
            $artist_device_id = getFieldWhere('device_id','tbl_artist','id',$artist_id);
            $artist_email = getFieldWhere('artist_email','tbl_artist','id',$artist_id);
            $body = "Hello $artist_name , Your booking is Canceled";
            send_booking_status_email($artist_email,$artist_name,$venue_name,$booking_date,$reason_of_cancel,$booking_id);
        }
      
        if($udata){
            $statement = "UPDATE tbl_booking SET status = '".$status."',reason_of_cancel='".$reason_of_cancel."' WHERE booking_id = '".$booking_id."' ";
            $result = $connection->query($statement);
            if($result){
                $respon = ['success'=> true,'message'=> 'Data successfully inserted'];
                booking_canceled_nofication($artist_device_id,$artist_device_type,$reason_of_cancel,$title,$body,$booking_id); 
            }
            else{
                $respon = ['success'=> false,'message'=> 'Some error occured'];
            }  
        } 
        return $response->withStatus(200)
    	->withHeader("Content-Type", "application/json")
    	->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
  });
/********************************************************************************/

/********************************************************************************/
   

/********************************************************************************/
   $app->post("/venue/issue_with_artist", function( $request, $response, $args){
        $data = $request->getParsedBody();
        $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
        $connection = connect_db();
        $connection->query("SET NAMES 'utf8'");
        $issue  = $data['issue'];
        $booking_id  = $data['booking_id'];
        $issue_status = $data['issue_status'];
        if($udata){
            $statement = "UPDATE tbl_booking SET issue_with_artist ='".$issue."',issue_status='".$issue_status."' WHERE booking_id = '".$booking_id."'";
            $result = $connection->query($statement);
            if($result){
              $booking_statement = "SELECT artist_id,venue_id,issue_with_artist FROM tbl_booking where booking_id ='".$booking_id."'";
              $booking_result = $connection->query($booking_statement);
              if($booking_result->num_rows > 0){
                $contact_detail = $booking_result->fetch_assoc();
                $artist_name = getFieldWhere('artist_name','tbl_artist','id',$contact_detail['artist_id']);
               
                $artist_email = getFieldWhere('artist_email','tbl_artist','id',$contact_detail['artist_id']);
                $artist_contact = getFieldWhere('artist_contact','tbl_artist','id',$contact_detail['artist_id']);
                
                
                $venue_name = getFieldWhere('venue_name','tbl_venue','id',$contact_detail['venue_id']);
                $venue_email = getFieldWhere('email','tbl_venue','id',$contact_detail['venue_id']);
                $venue_contact = getFieldWhere('contact_no','tbl_venue','id',$contact_detail['venue_id']);
                
                //echo $artist_email;die;
                
                send_email_admin_issue_with_artist($artist_name,$artist_email,$artist_contact,$venue_name,$venue_email,$venue_contact,$contact_detail['issue_with_artist']);
                send_email_artist_issue_with_artist($artist_email,$contact_detail['issue_with_artist'],$artist_name);
              }
              $respon = ['success' => true, 'message' => 'Data updated successfully'];
            }
            else{
        	    $respon = ['success' => false, 'message' => 'No data found'];
        	}
        }
        else{
            $respon = ['success'=> false,'message'=> 'Authorization refused'];
           }
           
        return $response->withStatus(200)
    	->withHeader("Content-Type", "application/json")
    	->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
   });
 
/********************************************************************************/
   $app->post("/venue/apple_pay_payment", function( $request, $response, $args){
        $data = $request->getParsedBody();
        $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
        $connection = connect_db();
        $connection->query("SET NAMES 'utf8'");
        $booking_id  = $data['booking_id'];
        $transaction_id = $data['transaction_id'];
        $payment_method = $data['payment_method'];
        $transaction_date = $data['transaction_date'];
        $status = $data['status'];
        if($udata){
            $statement = "UPDATE tbl_booking SET transaction_id ='".$transaction_id."',payment_method='".$payment_method."',transaction_date='".$transaction_date."',status='".$status."' WHERE booking_id = '".$booking_id."'";
            $result = $connection->query($statement);
            if($result){
              $respon = ['success' => true, 'message' => 'Data updated successfully'];
            }
            else{
        	  $respon = ['success' => false, 'message' => 'No data found'];
        	}
        }
        else{
            $respon = ['success'=> false,'message'=> 'Authorization refused'];
        }
           
        return $response->withStatus(200)
    	->withHeader("Content-Type", "application/json")
    	->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
   });
 

/********************************************************************************/


/********************************************************************************/
  $app->post("/venue/logout", function( $request, $response, $args){
          $data = $request->getParsedBody();
          $udata = validate_venue('tbl_venue',$request->getHeaders("Authorization")['HTTP_AUTHORIZATION'][0]);
          $connection = connect_db();
          $connection->query("SET NAMES 'utf8'");
          
          if($udata){
            $statement = "UPDATE tbl_venue SET device_id ='NULL' WHERE id = '".$udata['id']."'";
            $result = $connection->query($statement);
            if($result){
               $respon = ['success' => true, 'message' => 'successfully Logout'];
            }
            else{
        	    $respon = ['success' => false, 'message' => 'No data found'];
        	}
          }
          else{
            $respon = ['success'=> false,'message'=> 'Authorization refused'];
           }
        
        return $response->withStatus(200)
    	->withHeader("Content-Type", "application/json")
    	->write(json_encode($respon, JSON_UNESCAPED_SLASHES));
  });

/********************************************************************************/

?>