<?php   include('include/config.php');
        require("src/config/PHPMailer/PHPMailerAutoload.php");
        $today_date = date('Y-m-d');
        //$today_date = '2020-01-02';
        $total_booking = 0;
        $total_booking_price = 0;
        $booking_detail = array();
        $statement ="SELECT * FROM tbl_booking WHERE DATE(tbl_booking.c_date)='$today_date'";
        $result = $connection->query($statement);
        if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
                $total_booking = count($row);
                $total_booking_price = $total_booking_price+$row['quote_price'];
                
                /*if($row['artist_id'] != ''){
                    getFieldWhere('artist_name','tbl_artist','id',$row['artist_id']);
                }
                if($row['venue_id'] != ''){
                    getFieldWhere('venue_name','tbl_venue','id',$row['venue_id']);
                }
                $boking_detail['booking_id'] = $row['booking_id'];
                $boking_detail['artist_name'] = $row['artist_name'];
                $boking_detail['venue_name'] = $row['venue_name'];*/
                
            }
        }
    $msg= '<table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-spacing:0;margin:0;padding:0;width:100%" width="100%">
                   <tbody>
                      <tr>
                         <td align="center" bgcolor="#F2F2F2" style="border-collapse:collapse;border-spacing:0;margin:0;padding:0" valign="top">
                            <table align="center" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-spacing:0;padding:0;width: 400px;max-width:600px">
                               <tbody>
                                  <tr>
                                     <td align="center" style="border-collapse:collapse;border-spacing:0;margin:0;padding:0;padding-left:6.25%;padding-right:6.25%;width:87.5%;padding-top:25px;padding-bottom:25px" valign="top">
                                        <div style="display:none;overflow:hidden;opacity:0;font-size:1px;line-height:1px;height:0;max-height:0;max-width:0;color:#f2f2f2"> (Bookme)Daily Report</div>
                                        <a href="'.BASE_URL.'" style="text-decoration:none"><img alt="Logo" border="0" hspace="0" src="'.BASE_URL.'admin/assets/admin/images/logo.png" style="color:#808080;font-size:10px;margin:0;padding:0;outline:none;text-decoration:none;border:none;display:block" title="Infothrive Logo" vspace="0" width="200">
                                        </a>
                                     </td>
                                  </tr>
                               </tbody>
                            </table>
                            <table align="center" bgcolor="#FFFFFF" border="0" cellpadding="0" cellspacing="0" style="border-collapse:collapse;border-spacing:0;padding:0;width: 400px;max-width:600px">
                               <tbody>
                                  <tr>
                                     <td style="border-collapse:collapse;border-spacing:0;margin:0;padding:0;padding-left:4.25%;padding-right:4.25%;width:87.5%;font-size:15px;font-weight:400;line-height:180%;padding-top:25px;padding-bottom:0px;color:#072a5a;font-family:\'Open Sans\',sans-serif" valign="top" align="center">
                                        <h3>Daily Booking Analysis</h3>
                                     </td>
                                  </tr>
                                  <tr>
                                     <td align="center" bgcolor="#FFFFFF" style="border-collapse:collapse;border-spacing:0;margin:0;padding:0;padding-top:5px" valign="top">
                                        <div style="padding:10px 0 10px 0;margin:0">
                                           <a href="javscript:void(0)">
                                              <div style="width: 100%;line-height:0px">
                                                 <span style="color:#000;font-family:\'Open Sans\',sans-serif;font-size: 17px;font-weight: 700;letter-spacing: 0.5px;font-weight:700">Total Bookings :- '.$total_booking.'</span>
                                              </div>
                                           </a>
                                        </div>
                                        <div style="clear:both"></div>
                                     </td>
                                  </tr>
                                  <tr>
                                     <td align="center" bgcolor="#FFFFFF" style="border-collapse:collapse;border-spacing:0;margin:0;padding:0;padding-top:5px" valign="top">
                                        <div style="padding:10px 0 10px 0;margin:0">
                                           <a href="javscript:void(0)">
                                              <div style="width: 100%;padding-bottom:40px">
                                                 <span style="color:#000;font-family:\'Open Sans\',sans-serif;font-size: 17px;font-weight: 700;letter-spacing: 0.5px;font-weight:700">Total Booking Price :- '.$total_booking_price.'</span>
                                              </div>
                                           </a>
                                        </div>
                                        <div style="clear:both"></div>
                                     </td>
                                  </tr>
                               </tbody>
                            </table>
                            <table border="0" cellpadding="0" cellspacing="0" align="center" width="600" style="border-collapse:collapse;border-spacing:0;padding:0;padding-top:25px;width:inherit;max-width:600px">
                               <tbody>
                                  <tr>
                                     <td align="center" valign="top" style="border-collapse:collapse;border-spacing:0;margin:0;padding:0;padding-left:6.25%;padding-right:6.25%;width:87.5%;padding-top:25px"></td>
                                  </tr>
                                  <tr></tr>
                               </tbody>
                            </table>
                         </td>
                      </tr>
                   </tbody>
                </table>';
        $mail=new PHPMailer;
        //$mail->IsSMTP();
        $mail->SMTPAuth=true; // enable SMTP authentication
        $mail->SMTPSecure="ssl";
        $mail->Host="smtp.gmail.com";
        $mail->Port= 465; // set the SMTP port
        $mail->Username="smtp.frcoder@gmail.com";
        $mail->Password="frcoder6581";
        $mail->From="neharika@frcoder.com";
        $mail->FromName="BOOKME";
        $mail->AddAddress('anjaneye.frcoder@gmail.com');
        $mail->Subject= 'Daily Registration Report';
        $mail->Body = $msg;
        $mail->AltBody = $msg;
        if(!$mail->Send()) {
          return false;
        }
        else {
		 return true;
       }
        
?>