<p class="p1"><span class="s1">BookMe Agency Ltd</span></p>
<h1 class="p2"><span class="s1"><strong>BookMe - Privacy Policy</strong></span></h1>
<h2 class="p4"><span class="s1"><strong>Introduction</strong></span></h2>
<p><span class="s1" style="font-size:13px;">BookMe aims to build the world&rsquo;s greatest community of performing artists and host venues.</span></p>
<p><span class="s1">We believe that it all begins with privacy protection. BookMe will do everything in our power to protect the privacy of Performing Artists, Venues and associated Guests.</span></p>
<p class="p5"><span class="s1">This means that we&rsquo;ll protect the personal information of all visitors who access our websites or services through any mobile application, platform or device (collectively, the &ldquo;<strong>Services</strong>&rdquo;).This privacy policy (&ldquo;<strong>Privacy Policy</strong>&rdquo;) explains how BookMe intends to collect,<span class="Apple-converted-space">&nbsp; </span>share, and use your personal information. You&rsquo;ll also find information about how you can exercise your privacy rights. </span></p>
<p class="p6"><span class="s2">By using our Services you agree to BookMe using your personal information as described in this Privacy Policy. The terms &ldquo;we&rdquo;, &ldquo;us&rdquo; or &ldquo;our&rdquo; are each intended as reference to&nbsp;<strong>BookMe </strong>and any terms not defined in this Privacy Policy are defined in our Terms &amp; Conditions.</span></p>
<p class="p4"><span class="s1"><strong>Summary</strong></span></p>
<p class="p7"><span class="s2">We&rsquo;ve summarised the key points of our Privacy Policy below. </span></p>
<p class="p8"><span class="s1"><strong>1. Information we collect from you and why</strong></span></p>
<p class="p7"><span class="s2">Here are the broad categories of personal information that we may collect about you and the reasons why:</span></p>
<p class="p9"><span class="s1">Registration information when you create a BookMe account so we can:</span></p>
<ol class="ol1">
<li class="li10"><span class="s2">Create your account (Artist, Venue or Guest).<br /> </span></li>
<li class="li10"><span class="s2">Identify you when you sign-in to your account.<br /> </span></li>
<li class="li10"><span class="s2">Contact you for your views on our Services; and</span></li>
<li class="li10"><span class="s2">notify you of changes or updates to our Services.</span></li>
</ol>
<p class="p9"><span class="s1">Conversations, Discussions &amp; Transaction Information </span></p>
<ol class="ol1">
<li class="li10"><span class="s2">Process your transaction (Please note, BookMe never stores your credit card information in our systems).</span></li>
<li class="li10"><span class="s2">Communicate bookings made between Artists, Venues and Guest visitors. </span></li>
<li class="li10"><span class="s2">Provide confirmation and status updates.</span></li>
<li class="li10"><span class="s2">Reply to your booking queries, questions &amp; resolve problems.</span></li>
<li class="li10"><span class="s2">To carry out analysis and research to develop and improve our Services.</span></li>
<li class="li10"><span class="s2">To protect our clients and Services by seeking to detect and prevent fraud or other acts in breach of our&nbsp;terms &amp; conditions. </span></li>
</ol>
<p class="p11"><span class="s1">Information regarding your booking preferences so we can:</span></p>
<ol class="ol1">
<li class="li10"><span class="s2">Send you customised information about our products or services.</span></li>
</ol>
<p class="p12">&nbsp;</p>
<p class="p13"><span class="s1">Information that we automatically collect:</span></p>
<ol class="ol1">
<ol class="ol2">
<li class="li10"><span class="s2">Browsing &amp; booking activity so we can:</span></li>
</ol>
<li class="li10"><span class="s2">Provide you with an improved experience.</span></li>
<li class="li10"><span class="s2">Give you access to your booking history and preferences.</span></li>
<li class="li10"><span class="s2">Provide other services at your request.</span></li>
<ol class="ol2">
<li class="li10"><span class="s2">Cookies and similar technologies so we can:</span></li>
</ol>
<li class="li10"><span class="s2">Measure and analyse the use and effectiveness of our Services.</span></li>
<li class="li10"><span class="s2">Provide location services if you choose to share your geo-location.</span></li>
</ol>
<p class="p9"><span class="s1">Information that we obtain from third-party sources</span></p>
<p class="p9"><span class="s1">We process information that you provide voluntarily, information that we collect automatically and information that we obtain from third party sources in order to constantly improve the services provided through BookMe.</span></p>
<p class="p9"><span class="s1">Using this information, we can make it even easier for you to either search, book or receive bookings at anytime, from anywhere and on any device you choose.</span></p>
<p class="p13"><span class="s1"><strong>3. Legal basis for processing personal information</strong></span></p>
<p class="p9"><span class="s1">BookMe will always make sure we have a legal basis to collect and use your personal information. The legal basis we rely on will change depending on the type of information and the context in which we collect it.<br /> Our main reason for collecting and using your personal information is to perform our contract with you (i.e. to make or receive a booking), but we may also process it where it is in our legitimate business interests to do so.<br /> </span></p>
<p class="p13"><span class="s1"><strong>4. International data transfers</strong></span></p>
<p class="p9"><span class="s1">We may transfer your personal information to countries outside the one in which you are resident to other countries where BookMe or our service providers have operations. The data protection laws of these countries may differ from the laws of your country but BookMe takes care to implement appropriate safeguards to protect your personal information in those countries in accordance with this Privacy Policy.</span></p>
<p class="p13"><span class="s1"><strong>5. Data retention</strong></span></p>
<p class="p9"><span class="s1">BookMe will retain your personal information for no longer than is necessary to fulfil the purposes described in this Privacy Policy. We may also retain certain elements of your personal information for a period after you delete or deactivate your account for our legitimate operations such as record keeping and to comply with our legal obligations. Whenever we retain your information we will do so in compliance with applicable laws.<br /> <br /> </span></p>
<p class="p13"><span class="s1"><strong>6. Your data protection rights</strong></span></p>
<p class="p9"><span class="s1">You can access your account at any time to review and update your personal information. You can also contact us to ask us to delete your personal information.</span></p>
<p class="p13"><span class="s1"><strong>7. Updates to this Privacy Policy</strong></span></p>
<p class="p9"><span class="s1">We may update this Privacy Policy from time to time in response to changing legal, technical or business developments. We encourage you to periodically review this page for the latest information on our privacy practices.</span></p>
<p class="p13"><span class="s1"><strong>10. How to contact us</strong></span></p>
<p class="p14"><span class="s1">Should you have any questions or concerns about this Privacy Policy and BookMe's privacy practices, please contact us directly at <a href="mailto:info@bookme.agency"><span class="s3">info@bookme.agency</span></a> <br /> <br /> Contact Information:</span></p>
<p class="p15"><span class="s1"><strong>More information</strong></span></p>
<p class="p13"><span class="s1"><strong>1. Information we collect from you and why</strong></span></p>
<p class="p9"><span class="s1">The personal information that we may collect about you broadly falls into the following categories:</span></p>
<p class="p10"><span class="s1"><strong>A. Information that you provide voluntarily<br /> </strong><br /> Certain parts of our Services may ask you to provide personal information voluntarily.<br /> For instance:</span></p>
<ul class="ul1">
<li class="li10"><span class="s2">Registration information: When you create a BookMe account, sign-up or fill in forms on the Services, we collect information about you including your name, address, telephone number, email address and the password you create.</span></li>
<li class="li10"><span class="s2">Transaction information: We collect information relating to your bookings, including payment information using the secure services of our payment processors. Payment operations are outsourced to our payment processors and we do not store your credit card information in our systems.</span></li>
<li class="li10"><span class="s2">Information regarding your booking preferences: We collect information about your preferences to receive marketing information.</span></li>
<li class="li10"><span class="s2">Feedback: When you post messages and reviews of the Services provided by BookMe or you contact us, for example with a question, problem or comment, we collect information about you including your name and the content of your query. If you contact our customer support team we will record and keep a record of your conversation for quality and training purposes and to aid in the resolution of your queries.</span></li>
</ul>
<p class="p16">&nbsp;</p>
<p class="p10"><span class="s1"><strong>B. Information that we collect automatically<br /> </strong><br /> When you access the BookMe platform, we may collect certain information automatically from your device. In some countries, including countries in Europe, this information may be considered personal information under applicable data protection laws.<br /> For instance:</span></p>
<ul class="ul1">
<li class="li10"><span class="s2">Activity information: We collect information about your usage of the Services and information about you from the content you create and the notifications or messages you post or send.</span></li>
<li class="li10"><span class="s2">Cookies and similar technologies: We use cookies and similar tracking technology to collect and use personal information about you (e.g. your Internet Protocol (IP) address, your device ID, your browser type and when, how often and how long you interact with the Services), including to facilitate interest-based advertising.&nbsp;</span></li>
</ul>
<p class="p10"><span class="s1"><strong>C. Information that we obtain from third party sources.</strong></span></p>
<p class="p9"><span class="s1">From time to time, we may receive personal information from third party sources, including advertising networks but only where we have checked that these third parties either have your consent to process the information or are otherwise legally permitted or required to share your personal information with us. This information may include your likely demographic group.<br /> For instance:</span></p>
<ul class="ul1">
<li class="li10"><span class="s2">Analytics reports and market research surveys: We collect information from our third-party affiliates about the way you respond to and engage with our marketing campaigns so that we can customise our marketing and Services accordingly.</span></li>
<li class="li10"><span class="s2">We may also receive aggregated information in the form of audience segments from third party sources in order to display targeted advertising on digital properties operated by organisations like Fac</span><span class="s6">ebook and Google.</span></li>
</ul>
<p class="p16">&nbsp;</p>
<p class="p9"><span class="s1">Updated: 30</span><span class="s7"><sup>th</sup></span><span class="s1"> October 2019</span></p>

<p class="p5"><span class="s1"></span></p>
<p class="p5"><span class="s1"></span></p>
