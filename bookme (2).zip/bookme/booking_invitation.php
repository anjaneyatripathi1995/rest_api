<?php
    include("include/config.php");
    $booking_id = $_REQUEST['booking_id'];
    
    $statement = "SELECT * FROM tbl_booking where booking_id = '".$booking_id."'";
    $result = $connection->query($statement);
    $address = '';
    if($result->num_rows > 0){
        $row = $result->fetch_assoc();
        
        $artist_name = getFieldWhere('artist_name','tbl_artist','id',$row['artist_id']);
        if(!empty($row['venue_id'])){
           $venue_name = getFieldWhere('venue_name','tbl_venue','id',$row['venue_id']);
           $address = getFieldWhere('address','tbl_venue','id',$row['venue_id']);
           $building_number = getFieldWhere('building_number','tbl_venue','id',$row['venue_id']);
           $street_number = getFieldWhere('street_number','tbl_venue','id',$row['venue_id']);
           $town = getFieldWhere('town','tbl_venue','id',$row['venue_id']);
           $city = getFieldWhere('city','tbl_venue','id',$row['venue_id']);
           $post_code = getFieldWhere('post_code','tbl_venue','id',$row['venue_id']);
           $venue_address = $address.' '.$building_number.', '.$street_number.', '.$town.', '.$city.', '.$post_code;
           
        }
        if(!empty($row['guest_id'])){
            $guest_name = getFieldWhere('username','tbl_guest','id',$row['guest_id']);
            $address = $row['address'].' '.$row['building_number'].', '.$row['street_address'].', '.$row['town'].', '.$row['city'].', '.$row['post_code'];
        }
        
    }
    else{
        echo "NO DATA FOUND";
        die;
    }
    
?>
<!DOCTYPE html>
<html>
<head>
        <meta property="og:title" content="BookMe Invitation" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="http://api.frcoder.in/bookme/booking_invitation.php?booking_id=BMBD7D15094" />
        <meta property="og:description" content="BookMe" />
        <meta property="og:image" content="http://api.frcoder.in/bookme/uploads/logo.png" />
        <meta property="og:image:width" content="600" />
        <meta property="og:image:height" content="600" />
    <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
    <link rel="icon" href="http://api.frcoder.in/bookme/uploads/logo.png" type="image" sizes="16x16">
    <title>Bookme</title>
<style>
    img{
        width:100%;
        height:100%;
        object-fit: fill;
        position:relative;
        top:0;
        left:0;
        right:0;
        bottom:0;
    }
    .book-me{
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom:0;
        text-align: center;
        color: #fff;
        margin-top: 45%;
    }
    body{
        height:100vh;
        
    }
</style>
</head>



<body>

    
    <div>
        <img src="http://api.frcoder.in/bookme/uploads/FINAL-BANNER.jpg">
        <div class="book-me">
            <h3 style="color: #fff;font-size: 40px;text-align:center">With</h3>
	<h3 style="color: #fff;font-size: 40px;"><?php if (!empty($artist_name)){ echo $artist_name ;}?></h3>
	<h3 style="color: #fff;font-size: 40px;"> TIME : <?php if (!empty($row['start_time'])) { echo $row['start_time'] ;}?> To  <?php if (!empty($row['end_time'])) { echo $row['end_time'] ;}?></h3>
	<h3 style="color: #fff;font-size: 40px;"> DATE : <?php if (!empty($row['booking_date'])){ echo $row['booking_date'] ;}?></h3>
	<h3 style="color: #fff;font-size: 40px;"> Venue : <?php if (!empty($venue_name)){ echo $venue_name ;}
	else{ echo $guest_name ;}?></h3>
	<h3 style="color: #fff;font-size: 40px;width: 80%;margin: 0 auto;"><?php if (!empty($venue_address)){ echo $venue_address ;}
	else{ echo $address ;}?></h3>
        </div>
    </div>
    



</body>
</html>