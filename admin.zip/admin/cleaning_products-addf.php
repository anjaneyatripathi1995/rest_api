<?php
session_start();
include("../include/config.php");
include("../include/functions.php"); 
validate_admin();

if($_REQUEST['submitForm']=='yes'){
  $cleaning_products=$obj->escapestring($_POST['cleaning_products']);
  if($_REQUEST['id']==''){
   $obj->query("insert into $tbl_cleaning_products set cleaning_products='$cleaning_products',status=1 ");
   $_SESSION['sess_msg']='Record  added sucessfully';  

 }else{ 
   $obj->query("update $tbl_cleaning_products set cleaning_products='$cleaning_products' where id=".$_REQUEST['id']);
   $_SESSION['sess_msg']='Record updated sucessfully';   
 }
 header("location:cleaning_products-list.php");
 exit();
}      


if($_REQUEST['id']!=''){
  $sql=$obj->query("select * from $tbl_cleaning_products where id=".$_REQUEST['id']);
  $result=$obj->fetchNextObject($sql);
}

?>
<!DOCTYPE html>
<html>
<?php include("head.php"); ?>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    <?php include("header.php"); ?>
    <?php include("menu.php"); ?>
    <div class="content-wrapper">
      <section class="content-header">
        <h1>Update Cleaning Products</h1>
        <ol class="breadcrumb">
          <li><a href="javascript:void(0);"><i class="fa fa-dashboard"></i> Home</a></li>
          <li><a href="cleaning_products-list.php">View Cleaning Products </a></li>
        </ol>
      </section>
      <section class="content">
        <div class="box box-default">
          <form name="frm" method="POST" enctype="multipart/form-data" action="" onsubmit="return validate(this)">
            <input type="hidden" name="submitForm" value="yes" />
            <input type="hidden" name="id" value="<?php echo $_REQUEST['id'];?>" />
            <div class="box-body">
             <div class="row">
              <div class="col-md-6">

                <div class="form-group">
                  <label>Name</label>
                  <input type="text" name="cleaning_products" value="<?php echo stripslashes($result->cleaning_products); ?>" class="form-control">
                </div>
              </div>
            </div>
          </div>
          <div class="box-footer">
            <input type="submit" name="submit" value="Submit"  class="button" border="0"/>&nbsp;&nbsp;
            <input name="Reset" type="reset" id="Reset" value="Reset" class="button" border="0" />
          </div>
        </form>
      </div>
    </section>
  </div>
  <?php include("footer.php"); ?>
  <div class="control-sidebar-bg"></div>
</div>
<script src="js/jquery-2.2.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/app.min.js"></script>
<script src="js/demo.js"></script>
<script type="text/javascript" language="javascript">
  function validate(obj)
  {
    if(obj.cleaning_products_url.value==''){
      alert("Please enter URL");
      obj.cleaning_products_url.focus();
      return false;
    }
  }
</script>
</body>
</html>
