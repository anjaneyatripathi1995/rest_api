  <footer class="main-footer">
    <strong>Copyright &copy; <?php echo date('Y'); ?> <?php echo SITE_TITLE; ?></strong> All rights reserved.
  </footer>