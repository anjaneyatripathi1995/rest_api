<?php
include("../include/config.php");
include("../include/functions.php"); 
include("../include/simpleimage.php");
validate_admin();
if($_REQUEST['roles']!=''){
  $roles=implode(",",$_REQUEST['roles']);  
}

if($_REQUEST['submitForm']=='yes'){
  $obj->query("update $tbl_admin set roles='$roles' where  id='".$_REQUEST['id']."' ");
  $_SESSION['sess_msg']='Roles updated successfully';
  header("location:subadmin-list.php");
  exit();
}      


if($_REQUEST['id']!=''){
  $sql=$obj->query("select * from $tbl_admin where id=".$_REQUEST['id']);
  $result=$obj->fetchNextObject($sql);

}   $empRolesArr='';
if($result->roles!=''){
  $empRoles=$result->roles; 
  $empRolesArr=explode(",",$empRoles);  
}
?>
<!DOCTYPE html>
<html>
<?php include("head.php"); ?>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    <?php include("header.php"); ?>
    <?php include("menu.php"); ?>
    <div class="content-wrapper">
      <section class="content-header">
        <h1>Manage Roles for <?php echo getField('emp_name',$tbl_admin,$_REQUEST['id'])." ".getField('emp_surname',$tbl_admin,$_REQUEST['id']); ?></h1>
        <ol class="breadcrumb">
          <li><a href="javascript:void(0);"><i class="fa fa-dashboard"></i> Home</a></li>
          <li><a href="employee-list.php">Back</a></li>
        </ol>
      </section>
      <section class="content">
        <div class="box box-default">
          <form name="frm" method="POST" enctype="multipart/form-data" action="" onsubmit="return validate(this)">
            <input type="hidden" name="submitForm" value="yes" />
            <input type="hidden" name="id" value="<?php echo $_REQUEST['id'];?>" />
            <div class="box-body">
             <div class="row">
               <div class="col-md-12">
                 <h4 style="color: #3c8dbc">Manage Setting</h4>
               </div>
             </div>
             <div class="row">


               <div class="col-md-3">
                <div class="form-group">
                 <input  type="checkbox" name="roles[]" value="12" <?php if($empRolesArr!='' && in_array(12,$empRolesArr)){?>checked<?php } ?> />
                 <label>Manage Banner</label>
               </div>
             </div>

             <div class="col-md-3">
              <div class="form-group">
               <input  type="checkbox" name="roles[]" value="13"  <?php if($empRolesArr!='' && in_array(13,$empRolesArr)){?>checked<?php } ?>/>
               <label>Manage Social Links</label>
             </div>
           </div>

           <div class="col-md-3">
            <div class="form-group">
             <input  type="checkbox" name="roles[]" value="14" <?php if($empRolesArr!='' && in_array(14,$empRolesArr)){?>checked<?php } ?> />
             <label>Manage Setting</label>
           </div>
         </div>

       </div>







       <div class="row">
         <div class="col-md-12">
           <h4 style="color: #3c8dbc">User</h4>
         </div>
       </div>
       <div class="row">
        <div class="col-md-3">
          <div class="form-group">

           <input  type="checkbox" name="roles[]" value="21" <?php if($empRolesArr!='' && in_array(21,$empRolesArr)){?>checked<?php } ?> />
           <label>Manage User</label>
         </div>
       </div>

       <div class="col-md-3">
        <div class="form-group">

         <input  type="checkbox" name="roles[]" value="22" <?php if($empRolesArr!='' && in_array(22,$empRolesArr)){?>checked<?php } ?> />
         <label>Manage Group</label>
       </div>
     </div>
   </div>



   <div class="row">
     <div class="col-md-12">
       <h4 style="color: #3c8dbc">Manage Category</h4>
     </div>
   </div>
   <div class="row">
    <div class="col-md-3">
      <div class="form-group">

       <input  type="checkbox" name="roles[]" value="31" <?php if($empRolesArr!='' && in_array(31,$empRolesArr)){?>checked<?php } ?> />
       <label>Manage Category</label>
     </div>
   </div>
 </div>

 <div class="row">
   <div class="col-md-12">
     <h4 style="color: #3c8dbc">Manage Notification</h4>
   </div>
 </div>
 <div class="row">
  <div class="col-md-3">
    <div class="form-group">

     <input  type="checkbox" name="roles[]" value="41" <?php if($empRolesArr!='' && in_array(41,$empRolesArr)){?>checked<?php } ?> />
     <label>Manage Notification</label>
   </div>
 </div>

 <div class="col-md-3">
  <div class="form-group">

   <input  type="checkbox" name="roles[]" value="42" <?php if($empRolesArr!='' && in_array(42,$empRolesArr)){?>checked<?php } ?> />
   <label>Draft Notification</label>
 </div>
</div>
</div>














</div>
<div class="box-footer">
  <input type="submit" name="submit" value="Submit"  class="button" border="0"/>&nbsp;&nbsp;
  <input name="Reset" type="reset" id="Reset" value="Reset" class="button" border="0" />
</div>
</form>
</div>
</section>
</div>
<?php include("footer.php"); ?>
<div class="control-sidebar-bg"></div>
</div>
<script src="js/jquery-2.2.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/app.min.js"></script>
<script src="js/demo.js"></script>

</body>
</html>
