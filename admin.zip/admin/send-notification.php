<?php
session_start();
include("../include/config.php");
include("../include/functions.php"); 
include("../include/simpleimage.php");
validate_admin();

if($_REQUEST['submitForm']=='yes'){
 /************* send web notification *************/

$title = $_REQUEST['title'];
$message =substr($_REQUEST['content'],0,100)."...";

if($_FILES['photo']['size']>0 && $_FILES['photo']['error']==''){
    $img=time().$_FILES['photo']['name'];
    move_uploaded_file($_FILES['photo']['tmp_name'],"../upload_images/banner/".$img);
   
}  

$icon = SITE_URL.'upload_images/banner/'.$img;
 
$url =  "https://biolabs.com.co/";

$apiKey = "1462d481fc866096bd3ddc74208eacd6";

$curlUrl = "https://api.pushalert.co/rest/v1/send";

//POST variables
$post_vars = array(
"icon" => 'https://biolabs.com.co/demo/assets/img/logo/favicon.png',
"large_image" => $icon,
"title" => $title,
"message" => $message,
"url" => $url,
);



//print_r($post_vars); die;
$headers = Array();
$headers[] = "Authorization: api_key=".$apiKey;

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $curlUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_vars));
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);

$output = json_decode($result, true);
if($output["success"]) {
// echo $output["id"]; //Sent Notification ID

  $_SESSION['sess_msg']='Notificaci&eacute;n enviada con 	&eacute;xito.';


}
else {
//Others like bad request
  $_SESSION['sess_msg']='No se pudo enviar la Notificaci&Eacute;n.';
}



/************* send web notification *************/

header('Location:send-notification.php');

exit;
}
?>
<!DOCTYPE html>
<html>
<?php include("head.php"); ?>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    <?php include("header.php"); ?>
    <?php include("menu.php"); ?>
    <div class="content-wrapper" style="min-height: 548px;">
      <section class="content-header">
        <h1>Enviar notificación</h1>
        
      </section>
      <section class="content">
        <div class="box box-primary">
          <p style="text-align:center"></p>
          <div class="col-md-9"><p style="text-align:center"><?php if($_SESSION['sess_msg']){ ?><span class="box-title" style="font-size:12px;color:#00b763"><strong><?php echo $_SESSION['sess_msg'];$_SESSION['sess_msg']='';?></strong></span> <?php }?></p></div>
          <form name="frm" id="frm" method="POST" enctype="multipart/form-data" action="" onsubmit="return validate(this)">
            <input type="hidden" name="submitForm" value="yes">
            <input type="hidden" name="id" value="">
            <div class="box-body">
              <div class="row">
                <div class="col-md-6">
                  <div class="form-group">
                    <label>Título</label>
                    <input type="text" name="title" value="" class="required form-control">
                  </div>
                </div>

                <div class="col-md-6">
                  <div class="form-group">
                    <!--<label>Imagen de notificación <spam style="font-size:10px;color: red">(720x480 pixels recommended, 1.5 aspect ratio) </spam></label>-->
                    <label>Imagen de notificación <spam style="font-size:10px;color: red"> </spam></label>
                    <input type="file" name="photo" class="form-control"><br>
                  </div>
                </div>
                <div class="col-md-12">
                  <div class="form-group">
                    <label>Mensaje</label>
                    <textarea name="content" rows="5" id="content" cols="30" class="form-control"></textarea>
                  </div>
                </div>

              </div>
            </div>
          <div class="box-footer">
            <input type="submit" name="submit" value="Enviar" class="button" border="0">&nbsp;&nbsp;
            <input name="Reset" type="reset" id="Reset" value="Reiniciar" class="button" border="0">
          </div>
          </form></div>
        
      </section></div>
    </section>
  </div>
  <?php include("footer.php"); ?>
  <div class="control-sidebar-bg"></div>
</div>
<script src="js/jquery-2.2.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/app.min.js"></script>
<script src="js/demo.js"></script>
<script type="text/javascript" language="javascript">
  function validate(obj)
  {
    if(obj.cosmetics_url.value==''){
      alert("Please enter URL");
      obj.cosmetics_url.focus();
      return false;
    }
  }
</script>
</body>
</html>
