<?php session_start();
include("../include/config.php");
include("../include/functions.php"); 
validate_admin();
if($_REQUEST['id']!=''){
	$password=md5('notification@123');
$obj->query("update $tbl_admin set password='$password' where id='".$_REQUEST['id']."'",$debug=-1);
	$_SESSION['sess_msg']="Password reset successfully.! New password is notification@123";
}
header("location:".$_SERVER['HTTP_REFERER']);
exit();
?>