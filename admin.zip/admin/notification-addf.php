<?php
session_start();
include("../include/config.php");
include("../include/functions.php"); 
include("../include/simpleimage.php");
validate_admin();

if($_REQUEST['submitForm']=='yes'){

  $submit_type=$_POST['submit'];
  if($submit_type=='Save As Draft'){ $type=2; }else{ $type=1; }
  $sess_admin_id=$obj->escapestring($_SESSION['sess_admin_id']);
  $title=$obj->escapestring($_POST['title']);
  $category_id=$obj->escapestring($_POST['category_id']);
  $group_id=$obj->escapestring($_POST['group_id']);
  $user_id=$obj->escapestring($_POST['user_id']);
  $gender=$obj->escapestring($_POST['gender']);
  $start_date=$obj->escapestring($_POST['start_date']);
  $end_date=$obj->escapestring($_POST['end_date']);
  $c_date=$obj->escapestring($_POST['c_date']);
  $content=$obj->escapestring($_POST['content']);

  if ($_SESSION['user_type'] == 'superadmin') {
    $display = 1;
  }
  else {
    $display = 2;
  }



  if($_FILES['photo']['size']>0 && $_FILES['photo']['error']==''){
    $Image=new SimpleImage();
    $img=time().str_replace(" ","_",$_FILES['photo']['name']);
    move_uploaded_file($_FILES['photo']['tmp_name'],"../upload_images/banner/".$img); 
    copy("../upload_images/banner/".$img,"../upload_images/banner/thumb/".$img);
    $Image->load("../upload_images/banner/thumb/".$img);
    $Image->resize(160,160);
    $Image->save("../upload_images/banner/thumb/".$img);

    copy("../upload_images/banner/".$img,"../upload_images/banner/big/".$img);
    $Image->load("../upload_images/banner/big/".$img);
    $Image->resize(1298,683);
    $Image->save("../upload_images/banner/big/".$img);

    copy("../upload_images/banner/".$img,"../upload_images/banner/tiny/".$img);
    $Image->load("../upload_images/banner/tiny/".$img);
    $Image->resize(100,100);
    $Image->save("../upload_images/banner/tiny/".$img);
  }  
  if($_REQUEST['id']==''){
    if($group_id != '')
    {
      $group_member = getFieldWhere('user_id','tbl_group','id',$group_id);
      $group_user = explode(",",$group_member);
      foreach ($group_user as $user) {
        $obj->query("insert into $tbl_notification set display_user='$display',sess_admin_id='$sess_admin_id',title='$title',category_id='$category_id',group_id='$group_id',user_id='$user',gender='$gender',start_date='$start_date',end_date='$end_date',c_date='$c_date',content='$content',photo='$img',status=1,type=$type",$debug=-1);
      }

    } else {
    $obj->query("insert into $tbl_notification set display_user='$display',sess_admin_id='$sess_admin_id',title='$title',category_id='$category_id',group_id='$group_id',user_id='$user_id',gender='$gender',start_date='$start_date',end_date='$end_date',c_date='$c_date',content='$content',photo='$img',status=1,type=$type",$debug=-1);   
    }
    $_SESSION['sess_msg']='Notification added successfully';  
    
    $lastRow = $obj->lastInsertedId();
  }
  else{ 
   $sql="update tbl_notification set sess_admin_id='$sess_admin_id',title='$title',category_id='$category_id',group_id='$group_id',user_id='$user_id',gender='$gender',start_date='$start_date',end_date='$end_date',content='$content',type=$type";
   if($img){
    $imageArr=$obj->query("select photo from tbl_notification where id=".$_REQUEST['id']);
    $resultImage=$obj->fetchNextObject($imageArr);
    @unlink("../upload_images/banner/thumb/".$resultImage->photo);
    @unlink("../upload_images/banner/tiny/".$resultImage->photo);
    @unlink("../upload_images/banner/big/".$resultImage->photo);
    $sql.=" , photo='$img' ";

  }
  $sql.=" where id='".$_REQUEST['id']."'";

  $obj->query($sql,$debug=-1);   



  $_SESSION['sess_msg']='Notification updated successfully';   
  
  $lastRow = $_REQUEST['id'];
}

$sql = $obj->query("select * from tbl_notification where id='$lastRow'",$debug=-1);
$record = $obj->fetchNextObject($sql);
$title = $record->title;
$body = trim(strip_tags($record->content));
$image = SITE_URL."upload_images/banner/".$record->photo;

if($record->user_id != 0){
  $user_query = $obj->query("select device_type, device_id from tbl_users where id ='".$record->user_id."'",$debug=-1);
  $user_device_id = array();
  $user_data = $obj->fetchNextObject($user_query);
  $user_device_id = $user_data->device_id; 
  $user_device_type = $user_data->device_type; 

  


  if($user_device_type == 2){
    push_notification_ios($user_device_id,$title,$body,$image);
  } else {
    push_notification_android($user_device_id,$title,$body,$image);
  }

} elseif($record->group_id != 0){
  $group_query = $obj->query("select user_id from tbl_group where id='".$record->group_id."'",$debug=-1);
  $group_data = $obj->fetchNextObject($group_query);
  $group_user_id = explode(",",$group_data->user_id);

  $user_device_id = array();
  foreach ($group_user_id as $value) {
    $user_id = $value->id;
    $user_query = $obj->query("select device_type, device_id from tbl_users where id  = '".$user_id."'",$debug=-1);
    $user_data = $obj->fetchNextObject($user_query);
    $user_device_id = $user_data->device_id; 
    $user_device_type = $user_data->device_type; 

    if($user_device_type == 2){
      push_notification_ios($user_device_id,$title,$body,$image);
    } else {
      push_notification_android($user_device_id,$title,$body,$image);
    }
  }
  
}

if($type==2){
  header("location:draft-notification-list.php");
}else{
  header("location:notification-list.php");
}
exit();
}      
if($_REQUEST['id']!=''){
  $sql=$obj->query("select * from tbl_notification where id='".$_REQUEST['id']."'");
  $result=$obj->fetchNextObject($sql);
}
?>


<!DOCTYPE html>
<html>
<?php include("head.php"); ?>
<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/themes/mint-choc/jquery-ui.css">
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    <?php include("header.php"); ?>
    <?php include("menu.php"); ?>
    <script type="text/javascript" src="../include/ckeditor/ckeditor.js"></script>
    <div class="content-wrapper">
      <section class="content-header">
        <h1><?php if($_REQUEST['id']==''){?> Create <?php }else{?> Update<?php } ?> Notification</h1>
        <ol class="breadcrumb">
          <li><a href="javascript:void(0);"><i class="fa fa-dashboard"></i> Home</a></li>
          <li><a href="content-list.php">View Notification</a></li>
        </ol>
      </section>
      <section class="content">
        <div class="box box-default">
          <form name="frm" method="POST" enctype="multipart/form-data" action="" onsubmit="return validate(this)">
            <input type="hidden" name="submitForm" value="yes" />
            <input type="hidden" name="id" value="<?php echo $_REQUEST['id'];?>" />
            <div class="box-body">
              <div class="row">

                <div class="col-md-6">
                  <div class="form-group">
                    <label>Title</label>
                    <input type="text" name="title"  class="form-control"s    value="<?php echo $result->title;?>">
                  </div>
                </div>


                <div class="col-md-6">
                  <div class="form-group">
                    <label>Select Category <spam style="font-size:10px;color: red"> </spam></label>
                    <select name="category_id" id="example"  class="form-control">

                     <?php
                     $user_sql=$obj->query("select * from $tbl_category where 1=1  and status=1 order by category_name",$debug=-1);
                     while($line=$obj->fetchNextObject($user_sql)){  ?>
                      <option value="<?php echo $line->id ?>" <?php if($line->id==$result->category_id){ echo "selected"; } ?>><?php echo ucfirst($line->category_name); ?></option>
                    <?php } ?>
                    
                  </select>

                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <label>Select Group <spam style="font-size:10px;color: red"> </spam></label>
                  <select name="group_id" id="example"  class="form-control">
                    <option value="">Select Group</option>
                    <?php
                    $user_sql=$obj->query("select * from $tbl_group where 1=1  and status=1",$debug=-1);
                    while($line=$obj->fetchNextObject($user_sql)){  ?>
                      <option value="<?php echo $line->id ?>" <?php if($line->id==$result->group_id){ echo "selected"; } ?>><?php echo $line->group_name; ?></option>
                    <?php } ?>

                  </select>

                </div>
              </div>

              <div class="col-md-1">
                <div class="form-group">
                  <label>-OR-</label>
                  <p style="font-weight: 600;height: 18px">/</p>
                </div>
              </div>

              <div class="col-md-3">
                <div class="form-group">
                  <label>Select User <spam style="font-size:10px;color: red"> </spam></label>
                  <select name="user_id" id="example"  class="form-control">
                    <option value="">Select User</option>

                    <?php
                    $user_sql=$obj->query("select * from $tbl_user where 1=1  and status=1 and firstname IS NOT NULL order by firstname",$debug=-1);
                    while($line=$obj->fetchNextObject($user_sql)){  ?>
                      <option value="<?php echo $line->id ?>" <?php if($line->id==$result->user_id){ echo "selected"; } ?>><?php echo $line->firstname.' '.$line->lastname.' ('.$line->number.')'; ?></option>
                    <?php } ?>

                  </select>

                </div>
              </div>

              <div class="col-md-4">
               <div class="form-group">
                <label for="email">Gender</label>
                <select name="gender" id="input" class="form-control" required="required">
                  <option value="">Select Gender</option>
                  <option value="male" <?php if($result->gender=='male'){ echo "selected";  } ?>>Male</option>
                  <option value="female" <?php if($result->gender=='female'){ echo "selected";  } ?>>Female</option>
                  <option value="Other" <?php if($result->gender=='Other'){ echo "selected";  } ?>>Other</option>
                </select>
              </div>
            </div>



            <div class="col-md-4">
              <div class="form-group">
                <label>Event Start Date</label>
                <input type="text" name="start_date" id="datepicker" class="form-control" value="<?php echo $result->start_date;?>" placeholder="yyyy-mm-dd">
                
              </div>
            </div>
            <div class="col-md-4">
              <div class="form-group">
                <label>Event End Date</label>
                <input type="text" name="end_date" id="datepicker1" class="form-control" value="<?php echo $result->end_date;?>" placeholder="yyyy-mm-dd">
              </div>
            </div>

            <div class="col-md-4">
              <div class="form-group">
                <label>Create Date</label>
                <input type="text" name="c_date"  class="form-control"    value="<?php if($result->c_date){ echo $result->c_date; }else{ echo date('Y-m-d'); }?>" autocomplete="off" readonly>
              </div>
            </div>

            <div class="col-md-4">
              <div class="form-group">
                <label>Image</label>
                <input type="file" name="photo" class="form-control"></br>
                <?php if(is_file("../upload_images/banner/thumb/".$result->photo)){ ?>
                  <img src="../upload_images/banner/thumb/<?php echo $result->photo; ?>" width="20%" /><?php } ?>
                </div>
              </div>


              <div class="col-md-12">
                <div class="form-group">
                  <label>Content</label>
                  <textarea name="content" rows="10" cols="80" class="form-control ckeditor" id="content"><?php echo stripslashes($result->content);?></textarea>
                </div>
              </div>
            </div>
            <div class="box-footer">
              <input type="submit" class="btn btn-primary" name="submit" value="Save As Draft"  class="button" border="0"/>&nbsp;&nbsp;
              <input type="submit" class="btn btn-success" name="submit" value="Publish"  class="button" border="0"/>&nbsp;&nbsp;
            </div>
          </form>
        </div>
      </section>
    </div>


    <?php include("footer.php"); ?>
    <div class="control-sidebar-bg"></div>
  </div>
  <script src="js/jquery-2.2.3.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/app.min.js"></script>
  <script src="js/demo.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <script type="text/javascript" language="javascript">
    function validate(obj)
    {
      if(obj.title.value==''){
        alert("Please enter title");
        obj.title.focus();
        return false;
      }
      if(obj.video_url.value==''){
        alert("Please enter video url");
        obj.video_url.focus();
        return false;
      }
    }
  </script>


  <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />
  <!--<script>-->
  <!--  $(function() {-->
  <!--    $('#datepicker').daterangepicker({-->
  <!--      opens: 'left'-->
  <!--    }, function(start, end, label) {-->
  <!--      console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));-->
  <!--      $('#start_date').val(start.format('YYYY-MM-DD'));-->
  <!--    });-->
  <!--  });-->
  <!--</script>-->
  <script>
  $( function() {
    $( "#datepicker" ).datepicker({
       minDate: 0,
       dateFormat: 'dd-mm-yy'
    });
  } );
  
   $( function() {
    $( "#datepicker1" ).datepicker({
       minDate: 0,
       dateFormat: 'dd-mm-yy'
    });
  } );
  </script>

</body>
</html>














