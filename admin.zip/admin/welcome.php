<?php


ob_start();
session_start(); 
include('../include/config.php');
include("../include/functions.php");
validate_Admin();


if ($_SESSION['user_type']=='Admin') {
  header("location:welcome-emp.php");
}

?>

<!DOCTYPE html>
<html>
<?php include("head.php"); ?>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">

   <?php include("header.php"); ?>
   <!-- Left side column. contains the logo and sidebar -->
   <?PHP  include("menu.php");?>
   <!-- Content Wrapper. Contains page content -->
   <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Men&uacute; Principal
        <small>Panel de Control</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Men&uacute; Principal</li>
      </ol>
    </section>


    <!-- Main content -->
    <section class="content">
      <!-- Small boxes (Stat box) -->
      <div class="row">
        <div class="col-lg-3 col-xs-6">
          <!-- small box -->
          <div class="small-box bg-aqua" style="background-color: #25233d !important;">
            <div class="inner" style="text-align:center">

             <?php 
             $tempArr=$obj->query("select * from tbl_newsletter",$debug=-1);
             $rows=$obj->numRows($tempArr);
             ?>
             <h3><?php echo $rows; ?></h3>

             <p>Suscriptores</p>
           </div>
           <div class="icon">
            <i class="ion ion-bag"></i>
          </div>
          <a href="send_newsletter.php" class="small-box-footer">M&aacute;s informaci&oacute;n <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-green" style="background-color: #89878b !important;">
          <div class="inner"style="text-align:center">
            <?php 
             $tempArr=$obj->query("select * from  tbl_enquiry ",$debug=-1);
             $rows=$obj->numRows($tempArr);
             ?>
             <h3><?php echo $rows; ?></h3>

            <p>Consulta Recibida</p>
          </div>
          <div class="icon">
            <i class="ion ion-stats-bars"></i>
          </div>
          <a href="enquiry-list.php" class="small-box-footer">M&aacute;s informaci&oacute;n <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-yellow" style="background-color: #E44647 !important;" >
          <div class="inner"style="text-align:center">
           <?php 
             $tempArr=$obj->query("select * from tbl_user where type=2",$debug=-1);
             $rows=$obj->numRows($tempArr);
             ?>
             <h3><?php echo $rows; ?></h3>

            <p>Registros de usuarios</p>
          </div>
          <div class="icon">
            <i class="ion ion-person-add"></i>
          </div>
          <a href="user-list.php" class="small-box-footer">M&aacute;s informaci&oacute;n <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>
      <div class="col-lg-3 col-xs-6">
        <div class="small-box bg-red" style="background-color: #89878b !important;">
          <div class="inner"style="text-align:center">
             <?php 
             $tempArr=$obj->query("select * from tbl_user where type=1",$debug=-1);
             $rows=$obj->numRows($tempArr);
             ?>
             <h3><?php echo $rows; ?></h3>

            <p>Distribuidores</p>
          </div>
          <div class="icon">
            <i class="ion ion-pie-graph"></i>
          </div>
          <a href="distributer-list.php" class="small-box-footer">M&aacute;s informaci&oacute;n <i class="fa fa-arrow-circle-right"></i></a>
        </div>
      </div>
    </div>



  </section>
</div>
<?php include("footer.php"); ?>
<div class="control-sidebar-bg"></div>
</div>
<script src="js/jquery-2.2.3.min.js"></script>
<script src="https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<script>
  $.widget.bridge('uibutton', $.ui.button);
</script>
<script src="js/bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="js/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="js/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="js/demo.js"></script>
</body>
</html>
