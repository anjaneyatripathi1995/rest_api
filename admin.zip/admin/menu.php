<?php
include('../include/config.php');
$sess_user_id=$_SESSION['sess_admin_id'];
$role_query=$obj->query("select roles from $tbl_admin where id='$sess_user_id'",-1);
$rolles=$obj->fetchNextObject($role_query);
$rolls=explode(',',$rolles->roles); ?>

<aside class="main-sidebar">
  <!-- sidebar: style can be found in sidebar.less -->
  <section class="sidebar">
    <!-- Sidebar user panel -->
    <div class="user-panel">
      <div class="pull-left image">
        <img src="images/logo.png" class="img-circle" alt="User Image">
      </div>
      <div class="pull-left info">
        <p><?php echo ucfirst($_SESSION['sess_admin_username']); ?></p>
        <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
      </div>
    </div>
    <!-- sidebar menu: : style can be found in sidebar.less -->
    <ul class="sidebar-menu">
      <li class="header">Navigation Menu</li>

    <?php if(in_array(12,$rolls) || in_array(13,$rolls) || in_array(14,$rolls) ){ ?>
      <li class="treeview <?php echo  (basename($_SERVER['SCRIPT_NAME'])=='banner-list.php' || basename($_SERVER['SCRIPT_NAME'])=='banner-addf.php' || basename($_SERVER['SCRIPT_NAME'])=='social-list.php' || basename($_SERVER['SCRIPT_NAME'])=='social-addf.php' || basename($_SERVER['SCRIPT_NAME'])=='update-setting.php' )?'active' :'' ?>">
        <a href="javascript:void(0);">

          <i class="fa fa-cogs"></i><span>Manage Admin</span>
          <span class="pull-right-container">
            <i class="fa fa-angle-left pull-right"></i>
          </span>
        </a>
        <ul class="treeview-menu">
      <?php if(in_array(12,$rolls)){ ?>
          <li class="<?php echo (basename($_SERVER['SCRIPT_NAME'])=='banner-list.php' || basename($_SERVER['SCRIPT_NAME'])=='banner-addf.php')?'active' :'' ?>"><a href="banner-list.php"><i class="fa fa-circle-o"></i>Manage Banners</a></li>
      <?php } ?>

      <?php if(in_array(13,$rolls)){ ?>
          <li class="<?php echo (basename($_SERVER['SCRIPT_NAME'])=='social-list.php' || basename($_SERVER['SCRIPT_NAME'])=='social-addf.php')?'active' :'' ?>"><a href="social-list.php"><i class="fa fa-circle-o"></i>Manage Social Links</a></li>
      <?php } ?>

      <?php if(in_array(14,$rolls)){ ?>
          <li class="<?php echo (basename($_SERVER['SCRIPT_NAME'])=='update-setting.php')?'active' :'' ?>"><a href="update-setting.php"><i class="fa fa-circle-o"></i>Update setting</a></li>
      <?php } ?>
        </ul>
      </li>

    <?php } ?>





<?php if(in_array(21,$rolls) || in_array(22,$rolls) ){ ?>
<li class="treeview <?php echo (basename($_SERVER['SCRIPT_NAME'])=='group-list.php' || basename($_SERVER['SCRIPT_NAME'])=='group-addf.php' || basename($_SERVER['SCRIPT_NAME'])=='user-list.php' || basename($_SERVER['SCRIPT_NAME'])=='user-addf.php')?'active' :'' ?>">
  <a href="javascript:void(0);">
    <i class="fa fa-files-o"></i>
    <span>Manage User</span>
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>
  </a>
  <ul class="treeview-menu">
<?php if(in_array(21,$rolls)){ ?>
    <li class="<?php echo (basename($_SERVER['SCRIPT_NAME'])=='user-list.php' || basename($_SERVER['SCRIPT_NAME'])=='user-addf.php')?'active' :'' ?>"><a href="user-list.php"><i class="fa fa-circle-o"></i>Manage User</a></li>
  <?php } ?>
  <?php if(in_array(22,$rolls)){ ?>
    <li class="<?php echo (basename($_SERVER['SCRIPT_NAME'])=='group-list.php' || basename($_SERVER['SCRIPT_NAME'])=='group-addf.php')?'active' :'' ?>"><a href="group-list.php"><i class="fa fa-circle-o"></i>Group List</a></li>
<?php } ?>
  </ul>
</li>

<?php } ?>

<?php if(in_array(31,$rolls) || in_array(32,$rolls) ){ ?>
<li class="treeview <?php echo (basename($_SERVER['SCRIPT_NAME'])=='distributer-list.php' || basename($_SERVER['SCRIPT_NAME'])=='distributer-addf.php' || basename($_SERVER['SCRIPT_NAME'])=='category-list.php' || basename($_SERVER['SCRIPT_NAME'])=='category-addf.php')?'active' :'' ?>">
  <a href="javascript:void(0);">
    <i class="fa fa-files-o"></i>
    <span>Manage category</span>
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>
  </a>
  <ul class="treeview-menu">
  <?php if(in_array(31,$rolls)){ ?>
    <li class="<?php echo (basename($_SERVER['SCRIPT_NAME'])=='category-list.php' || basename($_SERVER['SCRIPT_NAME'])=='category-addf.php')?'active' :'' ?>"><a href="category-list.php"><i class="fa fa-circle-o"></i>Manage Category</a></li>

  <?php } ?>

  </ul>
</li>

<?php } ?>
<?php if(in_array(41,$rolls) || in_array(42,$rolls) ){ ?>
<li class="treeview <?php echo (basename($_SERVER['SCRIPT_NAME'])=='notification-list.php' || basename($_SERVER['SCRIPT_NAME'])=='notification-addf.php' || basename($_SERVER['SCRIPT_NAME'])=='draft-notification-list.php')?'active' :'' ?>">
  <a href="javascript:void(0);">
    <i class="fa fa-files-o"></i>
    <span>Manage Notification</span>
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>
  </a>
  <ul class="treeview-menu">

    <?php if(in_array(41,$rolls)){ ?>
    <li class="<?php echo (basename($_SERVER['SCRIPT_NAME'])=='notification-list.php' || basename($_SERVER['SCRIPT_NAME'])=='notification-addf.php')?'active' :'' ?>"><a href="notification-list.php"><i class="fa fa-circle-o"></i>Published Notification</a></li>
  <?php } ?>

  <?php if(in_array(42,$rolls)){ ?>
    <li class="<?php echo (basename($_SERVER['SCRIPT_NAME'])=='draft-notification-list.php')?'active' :'' ?>"><a href="draft-notification-list.php"><i class="fa fa-circle-o"></i>Draft Notification</a></li>

  <?php } ?>
    
  </ul>
</li>

<?php } ?>


<?php if($_SESSION['user_type']=='superadmin'){ ?>

<li class="treeview <?php echo (basename($_SERVER['SCRIPT_NAME'])=='subadmin-list.php' || basename($_SERVER['SCRIPT_NAME'])=='subadmin-addf.php')?'active' :'' ?>">
  <a href="javascript:void(0);">
    <i class="fa fa-files-o"></i>
    <span>Manage SubAdmin</span>
    <span class="pull-right-container">
      <i class="fa fa-angle-left pull-right"></i>
    </span>
  </a>
  <ul class="treeview-menu">
    <li class="<?php echo (basename($_SERVER['SCRIPT_NAME'])=='subadmin-list.php' || basename($_SERVER['SCRIPT_NAME'])=='subadmin-addf.php')?'active' :'' ?>"><a href="subadmin-list.php"><i class="fa fa-circle-o"></i>Manage Subadmin</a></li>
    
  </ul>
</li>
<?php } ?>


</ul>
</section>
<style type="text-css">
  .skin-blue .wrapper, .skin-blue .main-sidebar, .skin-blue .left-side {
  background-color:#89878b;
}
</style>
<!-- /.sidebar -->
</aside>


