<?php
session_start();
include("../include/config.php");
include("../include/functions.php"); 
include("../include/simpleimage.php");
 validate_admin();

  if($_REQUEST['submitForm']=='yes'){
  $title=$obj->escapestring($_POST['title']);
  $content=$obj->escapestring($_POST['content']);
  //$type=$obj->escapestring($_POST['type']);

if($_FILES['photo']['size']>0 && $_FILES['photo']['error']==''){
$Image=new SimpleImage();
$img=time().$_FILES['photo']['name'];
//echo $img; die;
move_uploaded_file($_FILES['photo']['tmp_name'],"../upload/banner/".$img); 
copy("../upload/banner/".$img,"../upload/banner/thumb/".$img);
$Image->load("../upload/banner/thumb/".$img);
$Image->resize(160,160);
$Image->save("../upload/banner/thumb".$img);

copy("../upload/banner/".$img,"../upload/banner/big/".$img);
$Image->load("../upload/banner/big/".$img);
$Image->resize(1298,683);
$Image->save("../upload/banner/big/".$img);

copy("../upload/banner/".$img,"../upload/banner/tiny/".$img);
$Image->load("../upload/banner/tiny/".$img);
$Image->resize(100,100);
$Image->save("../upload/banner/tiny/".$img);
}  
if($_REQUEST['id']==''){
    $obj->query("insert into $tbl_content set title='$title',content='$content',photo='$img',status=1",$debug=-1);    //die;
    $_SESSION['sess_msg']='Content added successfully';  
  }
  else{ 
   $sql="update tbl_content set title='$title',content='$content'";
    if($img){
    $imageArr=$obj->query("select photo from tbl_content where id=".$_REQUEST['id']);
    $resultImage=$obj->fetchNextObject($imageArr);
    @unlink("../upload/banner/thumb".$resultImage->photo);
    @unlink("../upload/banner/tiny/".$resultImage->photo);
    @unlink("../upload/banner/big/".$resultImage->photo);
    $sql.=" , photo='$img' ";
    }
$sql.=" where id='".$_REQUEST['id']."'";

$obj->query($sql,$debug=-1);   
//die;

$obj->query($sql,$debug=-1);   
$_SESSION['sess_msg']='Content updated successfully';   
  
  }
  header("location:content-list.php");
   exit();
  }      
if($_REQUEST['id']!=''){
$sql=$obj->query("select * from tbl_content where id='".$_REQUEST['id']."'");
$result=$obj->fetchNextObject($sql);
}
?>
  

<!DOCTYPE html>
<html>
<?php include("head.php"); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">
  <?php include("header.php"); ?>
   <?php include("menu.php"); ?>
    <script type="text/javascript" src="../include/ckeditor/ckeditor.js"></script>
  <div class="content-wrapper">
    <section class="content-header">
      <h1><?php if($_REQUEST['id']==''){?> Add <?php }else{?> Update<?php } ?> Page</h1>
      <ol class="breadcrumb">
        <li><a href="javascript:void(0);"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="content-list.php">View Pages</a></li>
      </ol>
    </section>
    <section class="content">
      <div class="box box-default">
    <form name="frm" method="POST" enctype="multipart/form-data" action="" onsubmit="return validate(this)">
    <input type="hidden" name="submitForm" value="yes" />
    <input type="hidden" name="id" value="<?php echo $_REQUEST['id'];?>" />
        <div class="box-body">
        <div class="row">
            
        <div class="col-md-6">
        <div class="form-group">
                <label>Title</label>
                <input type="text" name="title"  class="form-control"s    value="<?php echo $result->title;?>">
            </div>
        </div>
        
        <div class="col-md-6">
        <div class="form-group">
              <label>Image</label>
                <input type="file" name="photo" class="form-control"></br>
                <?php if(is_file("../upload/banner/tiny/".$result->photo)){ ?>
                  <img src="../upload/banner/tiny/<?php echo $result->photo; ?>" /><?php } ?>
             </div>
             </div>
             
        <div class="col-md-12">
        <div class="form-group">
                <label>Content</label>
                <textarea name="content" rows="10" cols="80" class="form-control ckeditor" id="content"><?php echo stripslashes($result->content);?></textarea>
            </div>
            </div>
            </div>
    <div class="box-footer">
    <input type="submit" name="submit" value="Submit"  class="button" border="0"/>&nbsp;&nbsp;
    <input name="Reset" type="reset" id="Reset" value="Reset" class="button" border="0"/>
    </div>
    </form>
      </div>
    </section>
  </div>
  <?php include("footer.php"); ?>
  <div class="control-sidebar-bg"></div>
</div>
<script src="js/jquery-2.2.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/app.min.js"></script>
<script src="js/demo.js"></script>

<script type="text/javascript" language="javascript">
function validate(obj)
{
  if(obj.title.value==''){
    alert("Please enter title");
    obj.title.focus();
    return false;
  }
  if(obj.video_url.value==''){
    alert("Please enter video url");
    obj.video_url.focus();
    return false;
  }
}
</script>


</body>
</html>














