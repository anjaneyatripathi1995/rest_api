<?php
session_start();
include("../include/config.php");
include("../include/functions.php"); 

validate_admin();
$name = $obj->escapestring($_POST['name']);
$email = $obj->escapestring($_POST['email']);
$password = md5($obj->escapestring($_POST['password']));
$type='admin';
if($_REQUEST['submitForm']=='yes'){

  if($_REQUEST['id']==''){

    $sql=$obj->query("select * from $tbl_admin where email='$email'",-1);
    $rows=$obj->numRows($sql);
    if($rows<1){

      $obj->query("insert into $tbl_admin set name='$name',email='$email',password='$password',type='$type',status=1,indate=now()",-1); //die;

      $_SESSION['sess_msg']='Record Register successfully';  
    }else{

      $_SESSION['sess_msg']='Record Already Registered';  
    }
    
  }else{ 

   $sql="update $tbl_admin set  name='$name'";    
   $sql.=" where id='".$_REQUEST['id']."'";
   // echo $sql; die;
   $obj->query($sql);
   $_SESSION['sess_msg']='Record updated successfully';   
 }
 header("location:subadmin-list.php");
 exit();
}      


if($_REQUEST['id']!=''){
  $sql=$obj->query("select * from $tbl_admin where id=".$_REQUEST['id']);
  $result=$obj->fetchNextObject($sql);
}


?>
<!DOCTYPE html>
<html>
<?php include("head.php"); ?>
<body class="hold-transition skin-blue sidebar-mini">
  <div class="wrapper">
    <?php include("header.php"); ?>
    <?php include("menu.php"); ?>
    <div class="content-wrapper">
      <section class="content-header">
        <h1><?php if($_REQUEST['id']!=''){?>Update <?php }else{?> Add <?php }?> subadmin</h1>
        <ol class="breadcrumb">
          <li><a href="javascript:void(0);"><i class="fa fa-dashboard"></i> Home</a></li>
          <li><a href="subadmin-list.php">View subadmin</a></li>
        </ol>
      </section>
      <section class="content">
        <div class="box box-primary">
          <form name="frm" id="frm" method="POST" enctype="multipart/form-data" action="" onsubmit="return validate(this)">
            <input type="hidden" name="submitForm" value="yes" />
            <input type="hidden" name="id" value="<?php echo $_REQUEST['id'];?>" />
            <div class="box-body">
             <div class="row">
              <div class="col-md-6">
                <label for="name">Name</label>
                <input type="text" name="name" class="form-control" required="" value="<?php echo $result->name ?>">
              </div>

              <div class="col-md-6">
                <label for="email">Email</label>
                <input type="email" name="email" class="form-control" required="" value="<?php echo $result->email ?>">
              </div>

              
           
            <?php if($_REQUEST['id']==''){ ?>
              <div class="col-md-6">
                <label for="name">Password</label>
                <input  type="password" name="password" class="form-control password" required="">
              </div>

              <div class="col-md-6">
                <label for="name">Confirm Password <span id="pwd" style="font-size: 10px;color: red;"></span></label>
                <input  type="password" name="conf_password" class="form-control password" required="">
              </div>

            <?php } ?>
            
            </div>
          </div>
          <div class="box-footer">
            <input type="submit" name="submit" value="Submit"  id="submit" class="button" border="0"/>&nbsp;&nbsp;
            <input name="Reset" type="reset" id="Reset" value="Reset" class="button" border="0" />
          </div>
        </form>
      </div>
    </section>
  </div>
  <?php include("footer.php"); ?>
  <div class="control-sidebar-bg"></div>
</div>
<script src="js/jquery-2.2.3.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/app.min.js"></script>
<script src="js/demo.js"></script>
<script src="js/jquery.validate.min.js"></script>
<script type="text/javascript" language="javascript">
  $(document).ready(function(){
    $("#frm").validate();
  })
</script>

<script type="text/javascript">
  $('.password').keyup(function(){

    var password=$("input[name=password]").val();
    var conf_password=$("input[name=conf_password]").val();

    if(password==conf_password && conf_password!=null){

      $('#submit').prop('disabled', false);
      $('#pwd').html('');

    }else{

      $('#submit').prop('disabled', true);
      $('#pwd').html('Both password not same');
    }

  });
</script>
</body>
</html>
