<?php 

// ob_start();

session_start(); 
// print_r($_SESSION); die;
include '../include/config.php';

require '../include/functions.php';

// validate_admin();





$sql = $obj->query("SELECT * from tbl_notification where id='".$_REQUEST['id']."'",$debug=-1);

$record = $obj->fetchNextObject($sql);

?>

<!DOCTYPE html>

<html>

<?php include("head.php"); ?>

<link rel="stylesheet" type="text/css" href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/themes/mint-choc/jquery-ui.css">

<body class="hold-transition skin-blue sidebar-mini">

  <div class="wrapper">

    <?php include("header.php"); ?>

    <?php include("menu.php"); ?>

    <script type="text/javascript" src="../include/ckeditor/ckeditor.js"></script>

    <div class="content-wrapper">

      <section class="content-header">

        <h1><?php if($_REQUEST['id']==''){?> Create <?php }else{?> Update<?php } ?> Notification</h1>

        <ol class="breadcrumb">

          <li><a href="javascript:void(0);"><i class="fa fa-dashboard"></i> Home</a></li>

          <li><a href="content-list.php">View Notification</a></li>

        </ol>

      </section>

      <section class="content">

        <div class="box box-default">

            <div class="box-body">

              <div class="row">

                <div class="col-md-6">

                  <div class="form-group">

                    <label>Title</label>
                    <span><?php echo $record->title; ?></span>

                  </div>

                </div>

                <div class="col-md-6">

                  <div class="form-group">

                    <label>Category</label>
                    <span><?php echo getFieldWhere('category_name','tbl_category','id',$record->category_id); ?></span>

                </div>

              </div>



              <div class="col-md-3">

                <div class="form-group">

                  <label>Group </label>
                      <?php if(!empty($record->group_id)){ echo getFieldWhere('group_name','tbl_category','id',$record->group_id); } else { echo "N/A";} ?>
                  </select>



                </div>

              </div>

              <div class="col-md-3">

                <div class="form-group">

                  <label>User</label>
                      <?php if(!empty($record->user_id)){ echo getFieldWhere('firstname','tbl_users','id',$record->group_id); } else { echo "N/A";} ?>

                </div>

              </div>



              <div class="col-md-4">

               <div class="form-group">

                <label for="email">Gender</label>

                  <?php echo ucfirst($record->gender); ?>
              </div>

            </div>


            <div class="col-md-4">

              <div class="form-group">

                <label>Start Date</label>
      
                  <?php echo date("d M Y",strtotime($record->start_date)); ?>
              </div>

            </div>

            <div class="col-md-4">

              <div class="form-group">

                <label>End Date</label>
      
                  <?php echo date("d M Y",strtotime($record->end_date)); ?>
              </div>

            </div>



            <div class="col-md-4">

              <div class="form-group">

                <label>Create Date</label>
                  <?php echo date("d M Y",strtotime($record->c_date)); ?>
              </div>

            </div>



            <div class="col-md-4">

              <div class="form-group">

                <label>Image</label>

                <?php if(is_file("../upload_images/banner/".$record->photo)){ ?>

                  <img src="../upload_images/banner/thumb/<?php echo $record->photo; ?>" width="20%" /><?php } ?>

                </div>

              </div>





              <div class="col-md-12">

                <div class="form-group">

                  <label>Content</label>
                  <?php echo $record->content; ?>

                </div>

              </div>

            </div>

          </form>

        </div>

      </section>

    </div>





    <?php include("footer.php"); ?>

    <div class="control-sidebar-bg"></div>

  </div>

  <script src="js/jquery-2.2.3.min.js"></script>

  <script src="js/bootstrap.min.js"></script>

  <script src="js/app.min.js"></script>

  <script src="js/demo.js"></script>

  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

  <script type="text/javascript" language="javascript">

    function validate(obj)

    {

      if(obj.title.value==''){

        alert("Please enter title");

        obj.title.focus();

        return false;

      }

      if(obj.video_url.value==''){

        alert("Please enter video url");

        obj.video_url.focus();

        return false;

      }

    }

  </script>





  <script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>

  <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>

  <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />

  <script>

    $(function() {

      $('input[name="event_date"]').daterangepicker({

        opens: 'left'

      }, function(start, end, label) {

        console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));

      });

    });

  </script>



</body>

</html>

