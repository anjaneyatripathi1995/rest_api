<?php 
include '../include/config.php';
include '../include/function.php';

$sql = $obj->query("update tbl_notification set display_user ='1' where id='".$obj->escapestring($_REQUEST['id'])."'",$debug=-1);

if($sql)
{
	echo 1;
 }
 else {
 	echo 0;
 }
?>