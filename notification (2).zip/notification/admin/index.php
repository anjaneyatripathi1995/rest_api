<?php 
ob_start();	
session_start();
include('../include/config.php');
include("../include/functions.php");
if($_SESSION['sess_admin_id']!=''){
header("location:welcome.php");	
exit();	
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title><?php echo SITE_TITLE; ?> | Notification Administrator</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="css/AdminLTE.min.css">
  <link rel="stylesheet" href="css/blue.css">

  <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
  <!--[if lt IE 9]>
  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>
<script language="javascript" type="text/javascript" src="js/admin.js"></script>
<script>
function LoginValidate(obj)
{
if(obj.username.value=='')
{
alert("Por favor ingrese nombre de usuario.");
obj.username.focus();
return false;
}
else if(obj.password.value=='')
{
alert("Por favor, ingrese contraseña.");
obj.password.focus();
return false;
}
}
</script>
<body class="hold-transition login-page" >
<div class="login-box">
  <div class="login-logo">
    <img src="images/logo.png" width="40%">
  </div>
  <!-- /.login-logo -->
  <div class="login-box-body">
    <p class="login-box-msg">ADMINISTRATOR</p>
    <p style="color: red;"><?php if($_SESSION['sess_msg']!=''){ echo $_SESSION['sess_msg']; $_SESSION['sess_msg']=''; } ?></p>

    <form name="loginform" method="post" action="login.php" onsubmit="return LoginValidate(this);">
	<input type="hidden" name="logged" value="yes" />
      <div class="form-group has-feedback">
		<input name="username" type="text" value="" class="form-control" id="username" Placeholder="Enter username" style="padding-left: 22px;" />  
      </div>
      <div class="form-group has-feedback">
		<input  name="password" id="userpass" type="password" value="" class="form-control" Placeholder="password" style="padding-left: 22px;" />
      </div>
      <div class="row">
        
        <!-- /.col -->
        <div class="col-xs-12" style="margin-left: 102px;">
          <button type="submit" class="btn btn-medium btn-wide btn-skin-red btn-circle" >Log In</button>
        </div>
        <div class="col-xs-12">
     <!--     <p class="login-admin-msg">Ingrese un nombre de usuario y contraseña válidos para obtener acceso a la consola de administración.</p> -->
        </div>

        <!-- /.col -->
      </div>
    </form>
  
  </div>
  <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<!-- jQuery 2.2.3 -->
<script src="js/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="js/bootstrap.min.js"></script>
<!-- iCheck -->
<script src="js/icheck.min.js"></script>
<script>
  $(function () {
    $('input').iCheck({
      checkboxClass: 'icheckbox_square-blue',
      radioClass: 'iradio_square-blue',
      increaseArea: '20%' // optional
    });
  });
</script>
</body>
</html>


<style type="text/css">
.login-admin-msg{
      padding: 40px 5px 5px;
    text-align: center
}
.has-feedback {
    position: relative;
    margin-bottom: 30px;
}
body {
   
    font-weight: 400;
    overflow-x: hidden;
    overflow-y: hidden;
    background-image: url('images/BACKGROUND.jpg');
}  
.login-box-body, .register-box-body {
        background: #fff0;
        border-radius: 11px;
}
.login-box-msg, .register-box-msg {
        color: #ffffff;
    font-weight: 700;
    font-family: "Play",sans-serif;
}
.dark-wrapper .btn-skin-red, .dark-wrapper .btn-skin-blue, .dark-wrapper .btn-skin-green, .dark-wrapper .btn-skin-purple, .dark-wrapper .btn-skin-yellow, .dark-wrapper .btn-skin-dark {
    color: #f5f5f5;
}
.btn-wide.btn-medium {
    padding: 8px 40px;
}
.btn-skin-red {
    background-color: #E44647;
    border-color: rgb(230, 51, 96);
    color: #fff;
}
.btn-circle {
    border-radius: 60px;
}

element.style {
}
.dark-wrapper .btn-skin-red, .dark-wrapper .btn-skin-blue, .dark-wrapper .btn-skin-green, .dark-wrapper .btn-skin-purple, .dark-wrapper .btn-skin-yellow, .dark-wrapper .btn-skin-dark {
    color: #f5f5f5;
}
.btn-wide.btn-medium {
    padding: 12px 50px;
}
.dark-wrapper .btn {
}
.page-contents *:last-child, #footer *:last-child {
    margin-bottom: 0 !important;
}
.dark-wrapper a {
    color: #B6B6B6;
    background-color: #FFf;
}
.btn-skin-red {
    background-color: #E44647;
    border-color: rgb(230, 51, 96);
    color: #fff;
}
.btn-wide {
}
.btn-circle {
    border-radius: 60px;
}
.btn-medium {
    padding: 12px 30px;
    font-size: 14px;
}
.btn {
    display: inline-block;
    font-family: "Play",sans-serif, sans-serif;
    transition: all 0.25s ease;
    text-transform: uppercase;
    padding: 15px 30px;
    font-size: 14px;
    font-weight: bold;
    background-color: #E44647;
    border: 1px solid #E44647;
    color: #fff;
}
.btn.focus, .btn:focus, .btn:hover {
    color: #333;
    text-decoration: none;
    background-color: #f5f0f1;
    border: 1px solid #FFF;
}
.form-control {
    border-radius: 36px;
    background-color: #fff0;}

.login-box-body input#username {
    color: #fff;
}
</style>


