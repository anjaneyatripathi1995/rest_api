



  $(document).on('keypress','.chkchr',function(event){
    var element=$(this);
    var charpattern = /^[A-Za-z\s]+$/i ;          
    var field_value=String.fromCharCode(event.which); 

    if(event.which == 0 || event.which == 8 || event.which == 9 || event.which == 39 || event.which == 45 ||  charpattern.test(field_value))
    {     
      $(element).css('border','');
      return true;
    }else{
      $(element).css('border','1px solid red');
      return false;
    }

  });
  
  $(document).on('keypress','.chknumber',function(event){
    var element=$(this);
    var charpattern = /^[0-9]+$/i ;          
    var field_value=String.fromCharCode(event.which); 

    if(event.which == 0 || event.which == 8 || event.which == 9 || event.which == 39 || charpattern.test(field_value))
    {     
      $(element).css('border','');
      return true;
    }else{
      $(element).css('border','1px solid red');
      return false;
    }

  });
  $(document).on('keyup','.validateemail',function(e){
   var element=$(this);
   var email = $(this).val();
   var filter = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;

   if (filter.test(email)) {
    $(element).css('border','');

    //document.getElementById('Submit').disabled = false;
    return true;

  }else{
    $(element).css('border','1px solid red');
    //document.getElementById('Submit').disabled = true;
    return false;
  }
             // e.preventDefault();
           });


  /*==========  on blur   =======*/  

  $(document).on('blur','.chksame',function(){

    var element= $(this);
    var value= (element).val() ;
// alert();
$('.chksame').each(function(k,v){ 
  current_input=$(this);
  current_val= $('#password').val();
  conf_val= $('.chksame').val();

  if(current_val!=conf_val)
  {
    $(current_input).css('border','1px solid red');
    document.getElementById('Submit').disabled = true;
    return false;
  }else{
    $(current_input).css('border','');
    document.getElementById('Submit').disabled = false;
    return true;
  }
})
}) 

  $(document).on('blur','.same_email',function(){

    var element= $(this);
    var value= (element).val() ;

    $('.same_email').each(function(k,v){ 
      current_input=$(this);
      current_val= $(this).val();
      if(current_val!=value)
      {
        $(current_input).css('border','1px solid red');
      }else{
        $(current_input).css('border','');
      }
    })
  })
