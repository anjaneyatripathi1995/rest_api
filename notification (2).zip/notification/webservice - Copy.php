<?php 

include('include/config.php');
include('include/functions.php');
include('include/simpleimage.php');

$url="http://localhost/notification/webservice.php";

// ===================Customer APIs Start==============================
if($_REQUEST['otpVerification']==1){
	$mode='otpVerification';
}

if($_REQUEST['user_register']==1){
	$mode='user_register';
}

if($_REQUEST['update_profile']==1){
	$mode='update_profile';
}
if($_REQUEST['banner_list']==1){
	$mode='banner_list';
}

if($_REQUEST['category_list']==1){
	$mode='category_list';
}



switch($mode){

################# OTP Verification Login #####################################

	case "otpVerification":

	$phone_number = $obj->escapestring($_REQUEST['phone_number']);
	$otp=SendSMS($phone_number);
	if($otp){
		$data['success']=1;
		$data['otp']=$otp;
		$data['message']="Otp Sent Successfully";
	}else{
		$data['success']=0;
		$data['message']="OTP not sent! Sever issue";
	}

	echo json_encode($data);
	break;
#################### Verification End ############################

#################### User Registration ############################

	case "user_register":
	$number = $obj->escapestring($_REQUEST['number']);
	$gender = $obj->escapestring($_REQUEST['gender']);
	$firstname = $obj->escapestring($_REQUEST['firstname']);
	$lastname = $obj->escapestring($_REQUEST['lastname']);
	$category = $obj->escapestring($_REQUEST['category']);
	$dob = $obj->escapestring($_REQUEST['dob']);
	$email = $obj->escapestring($_REQUEST['email']);
	$address = $obj->escapestring($_REQUEST['address']);
	$complete_status = $obj->escapestring($_REQUEST['complete_status']);
	
	$uArr=$obj->query("select * from $tbl_user where number='$number' and complete_status=1",-1);
	if($obj->numRows($uArr)<1){
		$uArr=$obj->query("select * from $tbl_user where number='$number'",-1);
		if($obj->numRows($uArr)<1){
			$obj->query("insert into $tbl_user set number='$number',gender='$gender',firstname='$firstname',lastname='$lastname',category='$category',dob='$dob',email='$email',address='$address',complete_status=$complete_status",-1);
			$resultUser=$obj->fetchNextObject($uArr);
			$resultUser->image=SITE_URL.'/upload_images/user/thumb/'.$resultUser->image;
			$data['success']=1;
			$data['user_details']=$resultUser;
			$data['message']="User Successfully Registered";

		}else{
			$obj->query("Update $tbl_user set gender='$gender',firstname='$firstname',lastname='$lastname',category='$category',dob='$dob',email='$email',address='$address',complete_status=$complete_status where number='$number'",-1);

			$resultUser=$obj->fetchNextObject($uArr);
			$resultUser->image=SITE_URL.'/upload_images/user/thumb/'.$resultUser->image;
			$data['success']=1;
			$data['user_details']=$resultUser;
			$data['message']="User Successfully Updated";
		}

	}else{
		
		$resultUser=$obj->fetchNextObject($uArr);
		$resultUser->image=SITE_URL.'/upload_images/user/thumb/'.$resultUser->image;
		$data['success']=1;
		$data['user_details']=$resultUser;
		$data['message']="User already registered";
	}
	echo json_encode($data);
	break;

#################### End Registration #############################

#################### Update Profile ############################

	case "update_profile":

	$number = $obj->escapestring($_REQUEST['number']);
	$gender = $obj->escapestring($_REQUEST['gender']);
	$firstname = $obj->escapestring($_REQUEST['firstname']);
	$lastname = $obj->escapestring($_REQUEST['lastname']);
	$dob = $obj->escapestring($_REQUEST['dob']);
	$email = $obj->escapestring($_REQUEST['email']);
	$address = $obj->escapestring($_REQUEST['address']);

	if($number)
	{	
		if($_FILES['user_img']['size']>0 && $_FILES['user_img']['error']=='')
		{
			$img=time().$_FILES['user_img']['name'];
			move_uploaded_file($_FILES['user_img']['tmp_name'],"upload_images/user/thumb/".$img);
		} 
		$queryTest = $obj->query("Update $tbl_user set gender='$gender',firstname='$firstname',lastname='$lastname',dob='$dob',email='$email',address='$address',image=$img where number='$number'",$debug=-1);

		$data['success']	=1;
		$data['user_img']= SITE_URL."/upload_images/user/thumb/".$img;
		$data['message']	="User Profile updated successfully!";

	}
	else{
		$data['success']	=0;
		$data['message']	="Please fill required fields !";
	}

	echo json_encode($data); 
	break;

	break;

#################### End Update Profile ############################

###################### Slider List ################################

case "banner_list";
$whr='';

if($_REQUEST['category_id']){
	$whr.=' and cat_id='.$_REQUEST['category_id'];
}

$uArr=$obj->query("select * from $tbl_banner where status=1 ".$whr,$debug=-1);
if($obj->numRows($uArr)>0){
	while($resultUser=$obj->fetchNextObject($uArr)){

		$data1['id']		=stripslashes($resultUser->id);
		$data1['title']		=stripslashes($resultUser->title);
		if($resultUser->photo!=''){
			$data1['logo']	=SITE_URL."upload_images/banner/big/".$resultUser->photo;
		}else{
			$data1['logo']	="No Available";
		}	
		$data1['status']	=stripslashes($resultUser->status);	
		$data['success']	=1;
		$data['data'][] 	= $data1;     
	} 
}else{
	$data['success']=0;
	$data['message']="No record found!";
}
echo json_encode($data); 
break;


######################### End Slider List #################################################


###################### Category List ################################

case "category_list";
$whr='';

if($_REQUEST['category_id']){
	$whr.=' and cat_id='.$_REQUEST['category_id'];
}

$uArr=$obj->query("select * from $tbl_category where status=1 ".$whr,$debug=-1);
if($obj->numRows($uArr)>0){
	while($resultUser=$obj->fetchNextObject($uArr)){

		$data1['id']		=stripslashes($resultUser->id);
		$data1['category_name']		=stripslashes($resultUser->category_name);
		if($resultUser->image!=''){
			$data1['logo']	=SITE_URL."upload_images/category/thumb/".$resultUser->image;
		}else{
			$data1['logo']	="No Available";
		}	
		$data1['status']	=stripslashes($resultUser->status);	
		$data['success']	=1;
		$data['data'][] 	= $data1;     
	} 
}else{
	$data['success']=0;
	$data['message']="No record found!";
}
echo json_encode($data); 
break;


######################### End Category List #################################################




















}