<?php
$tbl_admin='tbl_admin';
$tbl_user='tbl_users';
$tbl_category='tbl_category';
$tbl_city='tbl_city';
$tbl_content='tbl_content';
$tbl_banner='tbl_banner';
$tbl_group='tbl_group';
$tbl_notification='tbl_notification';
$tbl_setting='tbl_setting';





ini_set("date.timezone","Asia/Calcutta");
?>