<?php   
ob_start();
@session_start();
error_reporting(0);
//error_reporting(E_ALL);
$hostname = 'localhost';

// $username = 'root';
$username = 'ntsft';
// $password ='';
$password ='_w0P3mF!8EkJ';
$db_name = 'notification';

global $obj;
		
ini_set('date.timezone', 'Asia/Kolkata');
require_once("db.class.php");
require_once("variable.php");
$obj = new DB($hostname, $username, $password, $db_name); 
// @define('SITE_URL',"http://localhost/notification/");
@define('SITE_URL',"http://php.frcoder.in/notification/");
@define('SITE_TITLE',"Notification");
$website_currency_code='<i class="fa fa-inr"></i>';
$website_currency_symbol="₹";

?>
